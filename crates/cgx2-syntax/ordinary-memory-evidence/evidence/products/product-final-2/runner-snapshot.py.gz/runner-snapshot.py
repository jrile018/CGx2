#!/usr/bin/env python3
"""Bounded ordinary-memory product checks; each invocation preserves a new attempt."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import shlex
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(HERE.parent / "owned-result-runner-evidence"))
from supervisor import supervise, evidence


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normal(record, expected=0):
    return record["reason"] == "exit" and record["exit"] == expected and record.get("signal") is None


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (4 * 1024**3, 4 * 1024**3))
    resource.setrlimit(resource.RLIMIT_CPU, (120, 120))
    resource.setrlimit(resource.RLIMIT_FSIZE, (512 * 1024**2, 512 * 1024**2))


def observed(record):
    prefix = "CGX2_MEMORY_EVIDENCE "
    rows = [line[len(prefix):] for line in record["stderr"].splitlines() if line.startswith(prefix)]
    if len(rows) != 1:
        return None
    try:
        return json.loads(rows[0])
    except json.JSONDecodeError:
        return None


def stable(value):
    if isinstance(value, dict):
        return {k: stable(v) for k, v in value.items() if k != "pause"}
    if isinstance(value, list):
        return [stable(v) for v in value]
    return value


def rejection(record, code, start, end):
    if not normal(record, 1):
        return False
    try:
        data = json.loads(record.get("stdout") or record.get("stderr", ""))
    except (json.JSONDecodeError, TypeError):
        return False
    rows = data if isinstance(data, list) else data.get("diagnostics", [data] if "code" in data else [])
    return len(rows) == 1 and rows[0].get("code") == code and rows[0].get("span") == {"start": start, "end": end}


def suite_limits():
    resource.setrlimit(resource.RLIMIT_AS, (4 * 1024**3, 4 * 1024**3))
    resource.setrlimit(resource.RLIMIT_FSIZE, (512 * 1024**2, 512 * 1024**2))
    resource.setrlimit(resource.RLIMIT_CPU, (1800, 1800))


def historical_shadow_failure(report):
    failures=[r for r in report.get("commands",[]) if r.get("passed") is False]
    return report.get("passed")==523 and report.get("failed")==1 and len(failures)==1 and failures[0].get("label")=="shadow-builtin:reject" and normal(failures[0],0)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--regressions", action="store_true")
    args = parser.parse_args()
    binary = args.binary_dir.resolve()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=False)
    runner_source=Path(__file__).read_bytes()
    (output / "runner-snapshot.py").write_bytes(runner_source)
    outside = output / "outside"
    outside.mkdir()
    wrapper = output / "rustc-two-threads"
    wrapper.write_text('#!/bin/sh\nexec rustc -C link-arg=-Wl,--threads=2 "$@"\n')
    wrapper.chmod(0o700)
    env = dict(os.environ, RUSTUP_TOOLCHAIN="1.98.1", PYTHONDONTWRITEBYTECODE="1", CGX2_MEMORY_EVIDENCE="1")
    records = []
    assertions = []
    artifact_paths = sorted(p for p in binary.iterdir() if p.is_file())
    before = {p.name: digest(p) for p in artifact_paths}

    def run(name, argv, cwd=ROOT, extra=None, suite=False):
        result = supervise([str(a) for a in argv], cwd=str(cwd), env=dict(env, **(extra or {})), limits=suite_limits if suite else limits, cap=2 * 1024**2, timeout=3600 if suite else 180)
        record = dict(name=name, **evidence(result))
        records.append(record)
        return record

    def check(name, condition):
        assertions.append({"name": name, "passed": bool(condition)})

    manifest_path=binary.parent / "frozen.json"
    if manifest_path.is_file():
        manifest=json.loads(manifest_path.read_text())
        expected=dict(manifest["binary_sha256"],**manifest["probe_library_sha256"])
        check("frozen-manifest-matches-input",all(before.get(k)==v for k,v in expected.items()))
    else:
        check("frozen-manifest-matches-input",False)

    for fixture, expected in [("region", "2\n"), ("session", "42\n"), ("guard", "42\n"), ("copy-cycle", "42\n"), ("nested-guards", "42\n")]:
        source = HERE / "fixtures" / (fixture + ".cg")
        checked = run(fixture + "-check", [binary / "cgx2", "check", source])
        check(fixture + "-check", normal(checked))
        interpreted = run(fixture + "-interpreter", [binary / "cgx2", "run", source])
        check(fixture + "-value", normal(interpreted) and interpreted["stdout"] == expected)
        observation = observed(interpreted)
        check(fixture + "-roots", observation is not None and observation.get("baseline_roots") == observation.get("final_roots") == 0 and observation.get("cleanup_failures") == 0)
        for mode in ["debug", "release", "standalone"]:
            artifact = output / (fixture + "-" + mode)
            if mode == "standalone":
                rust = outside / (fixture + ".rs")
                emitted = run(fixture + "-emit", [binary / "cgx2c", "emit-rust", source, "--out", rust])
                check(fixture + "-emit", normal(emitted))
                built = run(fixture + "-standalone-build", [wrapper, "--edition=2021", rust, "-o", artifact], cwd=outside)
            else:
                command = [binary / "cgx2c", "build", source, "--out", artifact, "--rustc", wrapper]
                if mode == "release":
                    command.append("--release")
                built = run(fixture + "-" + mode + "-build", command)
            check(fixture + "-" + mode + "-build", normal(built))
            if normal(built):
                actual = run(fixture + "-" + mode, [artifact], cwd=outside)
                check(fixture + "-" + mode + "-value", normal(actual) and actual["stdout"] == expected)
                check(fixture + "-" + mode + "-memory", observation is not None and observed(actual) is not None and stable(observed(actual)) == stable(observation))
        sentinel = output / (fixture + ".py")
        sentinel.write_bytes(b"original artifact\n")
        original = digest(sentinel)
        rejected = run(fixture + "-python", [binary / "cgx2c", "emit-python", source, "--out", sentinel, "--force"])
        check(fixture + "-python-code", normal(rejected, 1) and "CGE006" in rejected["stderr"])
        check(fixture + "-python-artifact", digest(sentinel) == original)

    source = HERE / "fixtures" / "cross-region.cg"
    text = source.read_text()
    start = text.index("xs):")
    rejected = run("cross-region-check", [binary / "cgx2", "--diagnostic-format=json", "check", source])
    check("cross-region-exact-diagnostic", rejection(rejected, "CGT095", start, start + 2))
    sentinel = output / "cross-region-native"
    sentinel.write_bytes(b"original native artifact\n")
    original = digest(sentinel)
    rejected = run("cross-region-build", [binary / "cgx2c", "build", source, "--out", sentinel, "--force"])
    check("cross-region-build-rejected", normal(rejected, 1) and "CGT095" in rejected["stderr"])
    check("cross-region-build-preserved", digest(sentinel) == original)

    session = HERE / "fixtures" / "session.cg"
    probe_source=output / "entry-probe.rs"
    probe_source.write_text('extern crate cgx2_cli; fn main(){let source=std::fs::read_to_string(std::env::args().nth(1).unwrap()).unwrap();match cgx2_cli::run_checked_source_with_failure_at_reserve(&source,&[],1){Ok((result,_))=>println!("{}",result.value),Err(errors)=>{for failure in errors {eprintln!("{}: {} {:?}",failure.error.code,failure.error.message,failure.error.span);}std::process::exit(1)}}}')
    probe=output / "entry-probe"
    built=run("session-entry-probe-build",[wrapper,"--edition=2021",probe_source,"--extern",f"cgx2_cli={binary / 'libcgx2_cli.rlib'}","-L",f"dependency={binary / 'deps'}","-o",probe])
    check("session-entry-probe-build",normal(built))
    interpreted = run("session-entry-fault", [probe, session])
    check("session-entry-fault-value", normal(interpreted) and interpreted["stdout"] == "-10\n")
    check("session-entry-fault-unavailable-metrics", observed(interpreted) == {"session_entered": False, "metrics": None})
    for mode in ["debug", "release", "standalone"]:
        artifact = output / ("session-entry-fault-" + mode)
        command = [binary / "cgx2c", "build", session, "--out", artifact, "--test-fail-reserve", "1", "--rustc", wrapper]
        if mode == "release":
            command.append("--release")
        if mode=="standalone":
            command=[wrapper,"--edition=2021",'--cfg=feature="fault-injection"',outside / "session.rs","-o",artifact]
        built = run("session-entry-fault-" + mode + "-build", command,extra={"CGX2_TEST_FAIL_RESERVE":"1"} if mode=="standalone" else None)
        check("session-entry-fault-" + mode + "-build", normal(built))
        if normal(built):
            actual = run("session-entry-fault-" + mode, [artifact], cwd=outside)
            check("session-entry-fault-" + mode + "-value", normal(actual) and actual["stdout"] == "-10\n")
            check("session-entry-fault-" + mode + "-memory", observed(actual) == observed(interpreted))

    if args.regressions:
        regression_root = output / "regressions"
        regression_root.mkdir()
        specification = json.loads((ROOT / "plans/release-completion/s2b-ordinary-memory/regressions.json").read_text())
        for row in specification["checks"]:
            argv = [a.replace("${SOURCE_ROOT}", str(ROOT)).replace("${BINARY_DIR}", str(binary)).replace("${OUTPUT_DIR}", str(regression_root)) for a in row["argv"]]
            record = run("regression-" + row["name"], argv, suite=True)
            check("regression-" + row["name"], normal(record, row["expected_exit"]))
            if row["name"]=="owned-result-original":
                report_path=regression_root / "owned-result-original/owned-result-original.json"
                try:
                    original=json.loads(report_path.read_text())
                except (OSError,json.JSONDecodeError):
                    original={}
                check("historical-failure-is-only-the-unchanged-shadow-negative",historical_shadow_failure(original))
    after = {p.name: digest(p) for p in artifact_paths}
    check("frozen-artifacts-unchanged", before == after)
    report = {"schema_version": 1, "runner_sha256": hashlib.sha256(runner_source).hexdigest(), "ordinary_memory_complete": False,
              "passed": sum(c["passed"] for c in assertions), "failed": sum(not c["passed"] for c in assertions),
              "checks": assertions, "commands": records, "frozen_before": before, "frozen_after": after,
              "fixture_sha256": {p.name: digest(p) for p in (HERE / "fixtures").glob("*.cg")},
              "limits": "180s wall / 120s CPU / 4GiB address space / 512MiB files / 2MiB per output stream; process-group cleanup",
              "missing_required_rows": ["general aggregate ownership source lowering and v3 authentication", "source copy_owned/promote and failed-owner continuation", "checked packages and public memory signatures", "complete source/package fault, cleanup, and parity acceptance", "external leak-enabled assurance and independent audit"]}
    (output / "product.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"passed": report["passed"], "failed": report["failed"], "ordinary_memory_complete": False}))
    return int(report["failed"] != 0)

if __name__ == "__main__":
    raise SystemExit(main())
