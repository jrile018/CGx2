existing Python artifact
