import sys,json,re
from pathlib import Path
lane=Path('crates/cgx2-syntax/ordinary-parity-repair-evidence').resolve();sys.path.insert(0,str(lane))
from common import Journal,normal,digest,ROOT
from integrity import audit
from validation import inventory_errors
from finalization_audit import retained_inventory
scratch=ROOT/'target/ordinary-harness-finalization';run=scratch/'run-3'
j=Journal(scratch/'independent-final-audit-2')
(j.output/'audit.py').write_text(sys.orig_argv[-1])
j.report['audit_script_sha256']=digest(j.output/'audit.py')
try:
 candidate=json.loads((run/'freeze/candidate.json').read_text())
 j.report['build_source_commit']=candidate['build']['source_commit']
 j.report['harness_snapshot_sha256']=candidate['observing_harness']['harness_snapshot_sha256']
 audit(j,run/'freeze/frozen','independent-final')
 expected={'audit':(12,0),'freeze':(6,0),'matrix':(964,1),'auto':(34,0),'package':(45,0),'review':(21,0),'historical':(10,1),'quality':(11,0),'driver':(8,2)}
 reports={}
 for name,counts in expected.items():
  path=run/name/'report.json';r=json.loads(path.read_text());reports[name]=r
  inventory=r.get('required_inventory',{})
  errors=inventory_errors(r,set(inventory.get('commands',[])),set(inventory.get('checks',[])))
  j.check(name+'-complete-inventory',r['complete'] is True and not r['exceptions'] and not errors,errors=errors)
  j.check(name+'-exact-counts',(r['passed'],r['failed'])==counts,passed_count=r['passed'],failed_count=r['failed'])
  j.check(name+'-same-harness',r['source_identity']['harness_snapshot_sha256']==j.report['harness_snapshot_sha256'])
  if name in ('matrix','auto','package','review','historical'):
   phases=r.get('input_audits',{})
   j.check(name+'-before-after-inputs',set(phases)=={'before','after'} and all(not p['errors'] for p in phases.values()))
 j.report['raw_results']={n:{'passed':r['passed'],'failed':r['failed'],'failed_checks':[c['name']for c in r['checks']if c['passed'] is False]}for n,r in reports.items()}
 old=json.loads((run/'audit/retained-evidence.json').read_text())
 j.check('all-766-prior-files-unchanged',old==retained_inventory() and len(old)==766)
 row=j.run('prior-files-git-diff',['git','diff','--quiet','9f0804feac1a3c549ed879a8738e0152b370ed4a','--',lane/'evidence',lane/'hardening-evidence'])
 j.check('prior-files-match-reviewed-base',normal(row))
 from provenance import git
 old_tests=[lane/'test_harness.py',lane/'hardening-evidence/explicit_scenarios.py',lane.parent/'ordinary-memory-evidence/test_run.py']
 j.check('all-58-existing-test-sources-unchanged',all(p.read_bytes()==git('show','9f0804feac1a3c549ed879a8738e0152b370ed4a:'+str(p.relative_to(ROOT)))for p in old_tests))
 quality=reports['quality'];counts={'primary-selftests':48,'supplemental-selftests':2,'historical-selftests':8,'adversarial-selftests':19}
 for name,count in counts.items():
  row=next(r for r in quality['commands']if r['name']==name);match=re.search(r'Ran ([0-9]+) tests?',row.get('stderr',''))
  j.check(name+'-actual-count',normal(row) and match is not None and int(match[1])==count,expected=count,actual=int(match[1])if match else None)
 artifacts={};sources={};outside=set();standalone_commands=[]
 for name in ('matrix','auto','package'):
  r=reports[name]
  for key in ('native_artifacts','standalone_artifacts','artifacts'):
   for value in r.get(key,{}).values():
    path=value.get('binary',value.get('path'));sha=value.get('binary_sha256',value.get('sha256'))
    if path and sha:artifacts[path]=sha
    if value.get('source') and value.get('source_sha256'):sources[value['source']]=value['source_sha256']
  for row in r['commands']:
   if 'standalone' in row['name'] and row['name'].endswith(('-build','-run')):
    outside.add(row['cwd']);standalone_commands.append({'name':row['name'],'cwd':row['cwd']})
 j.check('105-modern-program-hashes',len(artifacts)==105 and all(digest(p)==sha for p,sha in artifacts.items()),count=len(artifacts))
 j.check('35-emitted-standalone-source-hashes',len(sources)==35 and all(digest(p)==sha for p,sha in sources.items()),count=len(sources))
 for index,directory in enumerate(sorted(outside)):
  row=j.run('actual-external-cwd-'+str(index),['git','rev-parse','--is-inside-work-tree'],cwd=directory)
  j.check('actual-external-cwd-'+str(index),normal(row,128),resolved=str(Path(directory).resolve()))
 j.check('all-70-modern-standalone-build-run-commands',len(standalone_commands)==70,count=len(standalone_commands))
 j.report['standalone_commands']=standalone_commands
 j.report['modern_program_sha256']=artifacts;j.report['emitted_source_sha256']=sources
 product=json.loads((run/'historical/product/product.json').read_text())
 specification=json.loads((ROOT/'plans/release-completion/s2b-ordinary-memory/regressions.json').read_text())
 required={'regression-'+r['name']for r in specification['checks']}
 actual=[r for r in product['commands']if r['name'].startswith('regression-')]
 j.check('all-18-unchanged-regressions-observed',len(actual)==18 and {r['name']for r in actual}==required)
 j.report['regression_outcomes']=[{k:r.get(k)for k in ('name','reason','exit','signal')}for r in actual]
 j.report['historical_raw']={k:product[k]for k in ('passed','failed')}
 j.report['historical_failed_checks']=[r for r in product['checks']if not r['passed']]
 original=json.loads((run/'historical/product/regressions/owned-result-original/owned-result-original.json').read_text())
 j.report['nested_original_raw']={k:original[k]for k in ('passed','failed')}
 managed=json.loads((run/'historical/product/regressions/managed-product/managed-product/repair/repair.json').read_text())
 j.report['nested_managed_raw']={k:managed[k]for k in ('passed','failed')}
 j.check('historical-raw-failures-retained',(product['passed'],product['failed'],managed['passed'],managed['failed'],original['passed'],original['failed'])==(135,1,670,8,523,1))
 argv_rows=[];cargo=[]
 def walk(value):
  if isinstance(value,dict):
   argv=value.get('argv')
   if isinstance(argv,list) and argv and isinstance(argv[0],str):
    argv_rows.append(argv)
    if Path(argv[0]).name=='cargo':cargo.append(argv)
   for child in value.values():walk(child)
  elif isinstance(value,list):
   for child in value:walk(child)
 for path in run.rglob('*.json'):
  try:walk(json.loads(path.read_text()))
  except (ValueError,UnicodeError):pass
 j.check('no-Cargo-in-frozen-verification',not cargo,cargo_commands=cargo,retained_argv_records=len(argv_rows))
 row=j.run('diff-check',['git','diff','--check']);j.check('diff-check',normal(row))
except Exception:
 j.exception()
status=j.finish();print(json.dumps({'exit':status,'passed':j.report['passed'],'failed':j.report['failed'],'complete':j.report['complete'],'exceptions':j.report['exceptions']}));raise SystemExit(status)
