import ast,json,os,sys
from pathlib import Path
root=Path.cwd();lane=root/'crates/cgx2-syntax/ordinary-parity-repair-evidence'
sys.path.insert(0,str(lane))
from common import Journal,digest,normal
scratch=Path(os.environ['TMPDIR'])
j=Journal(scratch/'preflight-1')
old={str(p.relative_to(lane/'evidence')):digest(p) for p in (lane/'evidence').rglob('*') if p.is_file()}
(j.output/'historical-evidence-before.json').write_text(json.dumps(old,indent=2)+'\n')
j.report['original_evidence_inventory_sha256']=digest(j.output/'historical-evidence-before.json')
j.report['early_branch_attempt']={'argv':['git','switch','-c','riley/ordinary-harness-hardening'],'exit':128,'stderr':"fatal: cannot lock ref 'refs/heads/riley/ordinary-harness-hardening': Unable to create '/home/john-riley/projects/lang/.git/refs/heads/riley/ordinary-harness-hardening.lock': Read-only file system\n",'resolution':'Authorized sandbox escalation created the local task branch; no source changed.'}
j.report['first_selftests']={'path':str(scratch/'selftests-1.log'),'sha256':digest(scratch/'selftests-1.log'),'actual':'47 tests; OK'}
(j.output/'selftests-1.log').write_bytes((scratch/'selftests-1.log').read_bytes())
for name,cmd in [('base',['git','rev-parse','HEAD']),('dirty',['git','status','--short']),('diff',['git','diff','--']),('new-selftests',[sys.executable,lane/'test_harness.py']),('historical-selftests',[sys.executable,lane.parent/'ordinary-memory-evidence/test_run.py']),('diff-check',['git','diff','--check'])]:
 row=j.run(name,cmd);j.check(name,normal(row))
for path in lane.glob('*.py'):ast.parse(path.read_text(),filename=str(path))
j.check('python-syntax',True)
coord=root/'plans/release-completion/s2b-ordinary-memory-review/evidence/combined-reviewed'
j.report['coordinator_evidence']={str(p.relative_to(root)):digest(p) for p in coord.rglob('*') if p.is_file()}
j.report['coordinator_identity_note']='Acceptance source0acc3278a3ba6dbf9d36e39e7a6dffc553ab2632; assigned combined base89464a76c9bd84a3b090ec58a14ca6be0043c6ea. Fresh workspace checks run locally, no source-incompatible pass reuse.'
sys.exit(j.finish())
