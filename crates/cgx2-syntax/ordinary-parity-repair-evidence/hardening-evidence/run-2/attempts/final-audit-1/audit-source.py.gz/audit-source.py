import hashlib,json,re,sys
from pathlib import Path
root=Path.cwd();lane=root/'crates/cgx2-syntax/ordinary-parity-repair-evidence'
sys.path.insert(0,str(lane))
from common import Journal,digest,normal
from integrity import audit
from validation import matrix_inventory,direct_inventory
scratch=root/'target/tmp-ordinary-harness-hardening'
j=Journal(scratch/'final-audit-1')
(j.output/'audit-source.py').write_bytes(Path(__file__).read_bytes())
j.report['audit_source_sha256']=digest(__file__)
reports={}
for name in ('matrix-1','auto-2','package-1','replay-2','review-1','quality-1','explicit-selftests-1'):
    path=scratch/name/'report.json';r=json.loads(path.read_text());reports[name]=r
    j.report.setdefault('report_references',{})[name]={'sha256':digest(path),'passed':r['passed'],'failed':r['failed'],'complete':r['complete']}
    j.check(name+'-required-coverage',r.get('complete') is True and not r.get('coverage_errors') and not r.get('exceptions'))
audit(j,scratch/'freeze-1/frozen','after-every-product')
matrix=reports['matrix-1'];bound=matrix['source_reserve_bound']['last_failure']
commands,checks=matrix_inventory(bound)
j.check('matrix-declared-inventory-independent',set(matrix['required_inventory']['commands'])==commands and set(matrix['required_inventory']['checks'])==checks)
source=[r['name'] for r in matrix['commands'] if re.fullmatch(r'source-reserve-\d+',r['name'])]
j.check('all-64-source-indices',len(source)==64 and set(source)=={f'source-reserve-{i}' for i in range(1,65)})
compiled=[r['name'] for r in matrix['commands'] if re.fullmatch(r'source-fault-\d+-(debug|release|standalone)-run',r['name'])]
expected={f'source-fault-{i}-{mode}-run' for i in range(1,bound+2) for mode in ('debug','release','standalone')}
j.check('all-compiled-reserve-routes-through-control',len(compiled)==len(expected) and set(compiled)==expected)
direct=matrix['direct_inventory'];names=[r['name'] for r in direct['rows']]
j.check('complete-direct-inventory',not direct['errors'] and len(names)==len(direct_inventory(direct['bound'])) and set(names)==direct_inventory(direct['bound']))
j.report['direct_count']=len(names);j.report['direct_bound']=direct['bound'];j.report['compiled_fault_run_count']=len(compiled)
j.report['matrix_failures']=[r for r in matrix['checks'] if r['passed'] is False]
old=json.loads((scratch/'preflight-1/historical-evidence-before.json').read_text())
now={str(p.relative_to(lane/'evidence')):digest(p) for p in (lane/'evidence').rglob('*') if p.is_file()}
j.check('all-original-evidence-identical',old==now,files=len(old))
sentinels=[scratch/'matrix-1'/f'{name}-{operation}-sentinel' for name in ('cross-region','cross-region-utf8','fallback-resource','dependency') for operation in ('build','emit-rust','emit-python')]
sentinels += [scratch/'package-1'/(name+'.py') for name in ('package-value','package-error')]
j.check('all-14-sentinels-still-exact',all(p.is_file() and p.read_bytes()==b'prior artifact\n' for p in sentinels))
counts={}
for label,r,name in [('main',reports['quality-1'],'new-selftests'),('historical',reports['quality-1'],'historical-selftests'),('supplemental',reports['explicit-selftests-1'],'explicit-adversarial-selftests')]:
    row=next(c for c in r['commands'] if c['name']==name)
    match=re.search(r'Ran (\d+) tests?',row.get('stderr',''))
    counts[label]=int(match[1]) if match and normal(row) else None
j.report['selftest_counts']=counts
j.check('all-58-selftests',counts=={'main':48,'historical':8,'supplemental':2})
j.check('explicit-selftest-source-retained',digest(lane/'hardening-evidence/explicit_scenarios.py')==reports['explicit-selftests-1']['selftest_source_sha256'])
j.report['unchanged_historical_product']=reports['replay-2']['product_summary']
j.check('historical-136-assertions-present',sum(reports['replay-2']['product_summary'].values())==136)
j.check('historical-runner-unchanged',digest(lane.parent/'ordinary-memory-evidence/run.py')==reports['replay-2']['historical_runner_sha256'])
pairs=0;bad=[]
for path in sorted(scratch.glob('*/report.json')):
    r=json.loads(path.read_text())
    for row in r.get('commands',[]):
        for stream in ('stdout','stderr'):
            if stream+'_sha256' not in row:continue
            content=row.get(stream,'').encode()
            pairs+=1
            if hashlib.sha256(content).hexdigest()!=row[stream+'_sha256']:bad.append([str(path),row['name'],stream])
j.check('owned-command-stream-hashes',not bad,pairs=pairs,bad=bad)
for name in ('matrix-1','auto-2','package-1','replay-2','review-1'):
    j.check(name+'-no-Cargo',all(Path(r['argv'][0]).name!='cargo' for r in reports[name]['commands']))
j.report['ordinary_memory_accepted']=False
j.report['release_accepted']=False
sys.exit(j.finish())
