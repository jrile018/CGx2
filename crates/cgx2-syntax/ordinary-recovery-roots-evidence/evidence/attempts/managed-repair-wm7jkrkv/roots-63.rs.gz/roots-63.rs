// CGx2 default managed v1; provenance: source-v1; inputs sha256: bb77ba5e0ef13d3bf2810da231722511d4847b05244b6b4ee75d98e93b9f931f; original source sha256: 97509217dbc75a8da92381470228af0cc4e809ed1dae0e34b17304e1613da056; model/root/effects/callee sha256: 1fd0490f4f424cc4c48aa63bf93e287303fd412ad124ee9663d848330fb447a5
#[allow(dead_code,unused_imports)] mod cgx2_runtime {
//! Standalone, single-threaded CGx2 byte-object tracing kernel.
#![forbid(unsafe_code)]

mod budget {
use std::ops::{Deref, DerefMut};

use crate::cgx2_runtime::{AllocationError, Session};

#[derive(Clone, Copy)]
pub(crate) struct Budget {
    pub limit: usize,
    pub spent: usize,
}

/// Suppresses collection for the whole session until dropped.
/// Nested guards charge each successful allocation to every active budget.
pub struct NoGcGuard<'a> {
    pub(crate) session: &'a mut Session,
}

impl Deref for NoGcGuard<'_> {
    type Target = Session;

    fn deref(&self) -> &Self::Target {
        self.session
    }
}

impl DerefMut for NoGcGuard<'_> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.session
    }
}

impl Drop for NoGcGuard<'_> {
    fn drop(&mut self) {
        self.session.budgets.pop();
    }
}

impl Session {
    pub(crate) fn check_budgets(&self, bytes: usize) -> Result<(), AllocationError> {
        for budget in &self.budgets {
            if bytes > budget.limit.saturating_sub(budget.spent) {
                return Err(AllocationError::BudgetExceeded);
            }
        }
        Ok(())
    }

    pub(crate) fn charge_budgets(&mut self, bytes: usize) {
        self.charged_bytes_v2 = self.charged_bytes_v2.saturating_add(bytes as u128);
        for budget in &mut self.budgets {
            budget.spent += bytes;
        }
    }
}

}
mod fault {
//! Deterministic failure of the runtime's fallible host reserve calls.

/// The fallible host reserve reached by an allocation attempt.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ReserveSite {
    RegionTable,
    ManagedBytes,
    ObjectPayload,
    ObjectReferences,
    SlotTable,
    OwnedBytes,
    ManagedToOwned,
    Edges,
}

/// Additive reserve audit for fallible entry and scoped lifetime APIs.
/// The original `ReserveSite` remains exhaustive and unchanged.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ReserveSiteV2 {
    Existing(ReserveSite),
    SessionRegions,
    GuardBudgets,
    ScopedRoots,
}

#[derive(Default)]
pub(crate) struct FaultInjection {
    #[cfg(feature = "fault-injection")]
    pub(crate) attempts: usize,
    #[cfg(feature = "fault-injection")]
    fail_at: Option<usize>,
    #[cfg(feature = "fault-injection")]
    pub(crate) failed_site: Option<ReserveSite>,
    #[cfg(feature = "fault-injection")]
    pub(crate) failed_site_v2: Option<ReserveSiteV2>,
}

impl FaultInjection {
    pub(crate) fn before_reserve(&mut self, site: ReserveSite) -> Result<(), ()> {
        self.before_reserve_v2(ReserveSiteV2::Existing(site))
    }

    pub(crate) fn before_reserve_v2(&mut self, site: ReserveSiteV2) -> Result<(), ()> {
        #[cfg(feature = "fault-injection")]
        {
            self.attempts += 1;
            if self.fail_at == Some(self.attempts) {
                self.fail_at = None;
                self.failed_site = match site {
                    ReserveSiteV2::Existing(legacy) => Some(legacy),
                    _ => None,
                };
                self.failed_site_v2 = Some(site);
                return Err(());
            }
        }
        #[cfg(not(feature = "fault-injection"))]
        let _ = site;
        Ok(())
    }

    #[cfg(feature = "fault-injection")]
    pub(crate) fn arm(&mut self, index: usize) {
        assert!(index > 0, "reserve index is one-based");
        self.attempts = 0;
        self.fail_at = Some(index);
        self.failed_site = None;
        self.failed_site_v2 = None;
    }

    #[cfg(feature = "fault-injection")]
    pub(crate) fn disable(&mut self) {
        self.fail_at = None;
    }
}

}
mod graph {
//! Checked payloads and bounded, traced chunk storage. No host object table.
use crate::cgx2_runtime::{
    AllocationError, Handle, MemoryError, RegionId, Session, MAX_OBJECT_PAYLOAD_BYTES,
    MAX_OBJECT_REFERENCE_SLOTS,
};

pub const MAX_GRAPH_REFERENCES: usize = 65_536;
pub const MAX_GRAPH_PAYLOAD_BYTES: usize = 1_048_576;
const HEADER: usize = 24;
const CHILDREN: usize = MAX_OBJECT_REFERENCE_SLOTS - 1;
const PAYLOAD: usize = MAX_OBJECT_PAYLOAD_BYTES - HEADER;
const MAGIC: &[u8; 4] = b"CGG1";

/// Additive error envelope; existing exhaustive MemoryError stays unchanged.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PayloadError {
    Memory(MemoryError),
    OutOfBounds,
}

impl From<MemoryError> for PayloadError {
    fn from(value: MemoryError) -> Self {
        Self::Memory(value)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum GraphError {
    Memory(MemoryError),
    ShapeLimit,
    InvalidLayout,
    OutOfBounds,
}

impl From<MemoryError> for GraphError {
    fn from(value: MemoryError) -> Self {
        Self::Memory(value)
    }
}

impl From<AllocationError> for GraphError {
    fn from(value: AllocationError) -> Self {
        Self::Memory(MemoryError::Allocation(value))
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct GraphShape {
    pub payload_bytes: usize,
    pub references: usize,
}

impl Session {
    /// Overwrites an existing byte range without allocation or collection.
    /// All validation precedes mutation, including checked offset arithmetic.
    pub fn write_bytes(
        &mut self,
        handle: Handle,
        offset: usize,
        bytes: &[u8],
    ) -> Result<(), PayloadError> {
        let object = self.object_mut(handle)?;
        let end = offset
            .checked_add(bytes.len())
            .ok_or(PayloadError::OutOfBounds)?;
        let target = object
            .bytes
            .get_mut(offset..end)
            .ok_or(PayloadError::OutOfBounds)?;
        target.copy_from_slice(bytes);
        Ok(())
    }

    /// Initializes an ordinary object with evaluated payload and children.
    /// Children are validated and rooted before allocation can collect.
    /// The returned handle is unrooted, following alloc_object's contract.
    pub fn alloc_initialized_object(
        &mut self,
        region: RegionId,
        payload: &[u8],
        references: &[Option<Handle>],
    ) -> Result<Handle, GraphError> {
        self.mode(region)?;
        if payload.len() > MAX_OBJECT_PAYLOAD_BYTES || references.len() > MAX_OBJECT_REFERENCE_SLOTS
        {
            return Err(GraphError::ShapeLimit);
        }
        self.validate_children(region, references)?;
        let mut roots = self.scoped_roots();
        roots.root_many(references)?;
        let result = (|| {
            let handle = roots.alloc_object(region, payload.len(), references.len())?;
            // Allocation has established exactly this payload and slot layout.
            roots.object_mut(handle)?.bytes.copy_from_slice(payload);
            for (index, child) in references.iter().enumerate() {
                roots.set_reference(handle, index, *child)?;
            }
            Ok(handle)
        })();
        let outcome = roots.finish(result);
        match (outcome.result, outcome.cleanup.first_error) {
            (Err(error), _) => Err(error),
            (Ok(_), Some(error)) => Err(error.into()),
            (Ok(handle), None) => Ok(handle),
        }
    }

    fn validate_children(
        &self,
        region: RegionId,
        references: &[Option<Handle>],
    ) -> Result<(), GraphError> {
        for child in references.iter().flatten() {
            self.read_bytes(*child)?;
            if child.region() != region {
                return Err(MemoryError::CrossRegionEdge.into());
            }
        }
        Ok(())
    }

    /// Constructs a traced chain with up to 65,536 logical reference slots and
    /// 1 MiB logical bytes. Each chunk respects alloc_object's existing bounds.
    /// Slot zero links chunks; remaining slots hold logical graph children.
    /// Header fields are fixed little-endian u32 values, never host pointers.
    /// Earlier successful allocations are not rolled back on failure.
    pub fn alloc_graph(
        &mut self,
        region: RegionId,
        payload: &[u8],
        references: &[Option<Handle>],
    ) -> Result<Handle, GraphError> {
        self.alloc_graph_layout(
            region,
            payload.len(),
            references.len(),
            Some(payload),
            references,
        )
    }

    /// Zero-initialized graph storage without temporary host buffers.
    pub fn alloc_zeroed_graph(
        &mut self,
        region: RegionId,
        payload_bytes: usize,
        references: usize,
    ) -> Result<Handle, GraphError> {
        self.alloc_graph_layout(region, payload_bytes, references, None, &[])
    }

    fn alloc_graph_layout(
        &mut self,
        region: RegionId,
        payload_len: usize,
        reference_len: usize,
        payload: Option<&[u8]>,
        references: &[Option<Handle>],
    ) -> Result<Handle, GraphError> {
        self.mode(region)?;
        if payload_len > MAX_GRAPH_PAYLOAD_BYTES || reference_len > MAX_GRAPH_REFERENCES {
            return Err(GraphError::ShapeLimit);
        }
        self.validate_children(region, references)?;
        let mut roots = self.scoped_roots();
        roots.root_many(references)?;
        let result = (|| {
            let chunks = reference_len
                .div_ceil(CHILDREN)
                .max(payload_len.div_ceil(PAYLOAD))
                .max(1);
            let mut next = None;
            for chunk in (0..chunks).rev() {
                let ref_start = (chunk * CHILDREN).min(reference_len);
                let ref_end = (ref_start + CHILDREN).min(reference_len);
                let byte_start = (chunk * PAYLOAD).min(payload_len);
                let byte_end = (byte_start + PAYLOAD).min(payload_len);
                let handle = roots.alloc_object(
                    region,
                    HEADER + byte_end - byte_start,
                    1 + ref_end - ref_start,
                )?;
                roots.root(handle)?;
                let bytes = &mut roots.object_mut(handle)?.bytes;
                bytes[..4].copy_from_slice(MAGIC);
                for (offset, value) in [
                    reference_len,
                    payload_len,
                    ref_end - ref_start,
                    byte_end - byte_start,
                ]
                .into_iter()
                .enumerate()
                {
                    bytes[4 + offset * 4..8 + offset * 4]
                        .copy_from_slice(&(value as u32).to_le_bytes());
                }
                if let Some(payload) = payload {
                    bytes[HEADER..].copy_from_slice(&payload[byte_start..byte_end]);
                }
                roots.set_reference(handle, 0, next)?;
                if !references.is_empty() {
                    for (index, child) in references[ref_start..ref_end].iter().enumerate() {
                        roots.set_reference(handle, index + 1, *child)?;
                    }
                }
                next = Some(handle);
            }
            Ok(next.expect("at least one chunk"))
        })();
        let outcome = roots.finish(result);
        match (outcome.result, outcome.cleanup.first_error) {
            (Err(error), _) => Err(error),
            (Ok(_), Some(error)) => Err(error.into()),
            (Ok(handle), None) => Ok(handle),
        }
    }

    fn chunk_shape(&self, handle: Handle) -> Result<(GraphShape, usize, usize), GraphError> {
        let bytes = self.read_bytes(handle)?;
        if bytes.len() < HEADER || &bytes[..4] != MAGIC || bytes[20..HEADER] != [0; 4] {
            return Err(GraphError::InvalidLayout);
        }
        let field = |index| {
            u32::from_le_bytes(bytes[index..index + 4].try_into().expect("header field")) as usize
        };
        let shape = GraphShape {
            references: field(4),
            payload_bytes: field(8),
        };
        let refs = field(12);
        let payload = field(16);
        if shape.references > MAX_GRAPH_REFERENCES
            || shape.payload_bytes > MAX_GRAPH_PAYLOAD_BYTES
            || refs > CHILDREN
            || payload > PAYLOAD
            || bytes.len() != HEADER + payload
            || self.region(handle.region())?.slots[handle.slot]
                .object
                .as_ref()
                .and_then(|object| object.references.as_ref())
                .map(Vec::len)
                != Some(1 + refs)
        {
            return Err(GraphError::InvalidLayout);
        }
        Ok((shape, refs, payload))
    }

    /// Validates the entire bounded chain, including shape, length and links.
    pub fn graph_shape(&self, handle: Handle) -> Result<GraphShape, GraphError> {
        let shape = self.chunk_shape(handle)?.0;
        let chunks = shape
            .references
            .div_ceil(CHILDREN)
            .max(shape.payload_bytes.div_ceil(PAYLOAD))
            .max(1);
        let mut next = Some(handle);
        for index in 0..chunks {
            let current = next.ok_or(GraphError::InvalidLayout)?;
            let (actual, refs, bytes) = self.chunk_shape(current)?;
            if actual != shape
                || refs
                    != shape
                        .references
                        .saturating_sub(index * CHILDREN)
                        .min(CHILDREN)
                || bytes
                    != shape
                        .payload_bytes
                        .saturating_sub(index * PAYLOAD)
                        .min(PAYLOAD)
            {
                return Err(GraphError::InvalidLayout);
            }
            next = self.reference(current, 0)?;
        }
        if next.is_some() {
            return Err(GraphError::InvalidLayout);
        }
        Ok(shape)
    }

    fn graph_slot(&self, handle: Handle, index: usize) -> Result<(Handle, usize), GraphError> {
        if index >= self.graph_shape(handle)?.references {
            return Err(GraphError::OutOfBounds);
        }
        let mut chunk = handle;
        for _ in 0..index / CHILDREN {
            chunk = self.reference(chunk, 0)?.ok_or(GraphError::InvalidLayout)?;
        }
        Ok((chunk, 1 + index % CHILDREN))
    }

    pub fn graph_reference(
        &self,
        handle: Handle,
        index: usize,
    ) -> Result<Option<Handle>, GraphError> {
        let (chunk, slot) = self.graph_slot(handle, index)?;
        Ok(self.reference(chunk, slot)?)
    }

    /// Visits logical child slots in source order after validating the whole
    /// chain. Callback storage belongs to the caller; this never allocates.
    pub fn visit_graph_references(
        &self,
        handle: Handle,
        mut visit: impl FnMut(usize, Option<Handle>),
    ) -> Result<(), GraphError> {
        let shape = self.graph_shape(handle)?;
        let mut chunk = handle;
        let mut index = 0;
        while index < shape.references {
            let count = (shape.references - index).min(CHILDREN);
            for slot in 0..count {
                visit(index + slot, self.reference(chunk, slot + 1)?);
            }
            index += count;
            if index < shape.references {
                chunk = self.reference(chunk, 0)?.ok_or(GraphError::InvalidLayout)?;
            }
        }
        Ok(())
    }

    /// In-place checked edge update; supports same-region aliases and cycles.
    pub fn set_graph_reference(
        &mut self,
        handle: Handle,
        index: usize,
        child: Option<Handle>,
    ) -> Result<(), GraphError> {
        let (chunk, slot) = self.graph_slot(handle, index)?;
        Ok(self.set_reference(chunk, slot, child)?)
    }

    /// Copies a logical byte range into caller-owned storage without allocation.
    /// Layout and complete range validation precede the first output write.
    pub fn read_graph_bytes(
        &self,
        handle: Handle,
        offset: usize,
        output: &mut [u8],
    ) -> Result<(), GraphError> {
        let shape = self.graph_shape(handle)?;
        if offset
            .checked_add(output.len())
            .is_none_or(|end| end > shape.payload_bytes)
        {
            return Err(GraphError::OutOfBounds);
        }
        let mut chunk = handle;
        let mut remaining_offset = offset;
        let mut written = 0;
        while written < output.len() {
            let bytes = &self.read_bytes(chunk)?[HEADER..];
            if remaining_offset < bytes.len() {
                let count = (bytes.len() - remaining_offset).min(output.len() - written);
                output[written..written + count]
                    .copy_from_slice(&bytes[remaining_offset..remaining_offset + count]);
                written += count;
                remaining_offset = 0;
            } else {
                remaining_offset -= bytes.len();
            }
            if written < output.len() {
                chunk = self.reference(chunk, 0)?.ok_or(GraphError::InvalidLayout)?;
            }
        }
        Ok(())
    }
    /// Writes logical payload bytes after validating the complete layout/range.
    /// Rejected writes leave the graph unchanged; no reserve or collection occurs.
    pub fn write_graph_bytes(
        &mut self,
        handle: Handle,
        offset: usize,
        input: &[u8],
    ) -> Result<(), GraphError> {
        let shape = self.graph_shape(handle)?;
        if offset
            .checked_add(input.len())
            .is_none_or(|end| end > shape.payload_bytes)
        {
            return Err(GraphError::OutOfBounds);
        }
        let mut chunk = handle;
        let mut remaining_offset = offset;
        let mut written = 0;
        while written < input.len() {
            let bytes = &mut self.object_mut(chunk)?.bytes[HEADER..];
            if remaining_offset < bytes.len() {
                let count = (bytes.len() - remaining_offset).min(input.len() - written);
                bytes[remaining_offset..remaining_offset + count]
                    .copy_from_slice(&input[written..written + count]);
                written += count;
                remaining_offset = 0;
            } else {
                remaining_offset -= bytes.len();
            }
            if written < input.len() {
                chunk = self.reference(chunk, 0)?.ok_or(GraphError::InvalidLayout)?;
            }
        }
        Ok(())
    }
}

/// Additive source-managed model. Kept in the frozen nine-file runtime inventory
/// so previously emitted standalone programs still stage a complete runtime.
pub mod default_managed {
    pub mod model {
        //! Additive closed execution model; compiler authentication is separate from runtime validation.
        #[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
        pub struct Loc {
            pub start: usize,
            pub end: usize,
        }
        #[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
        pub struct MemoryEffectsV1 {
            pub may_allocate_managed: bool,
            pub may_auto_collect_at_allocation: bool,
            pub may_explicitly_collect: bool,
            pub may_allocate_root_bookkeeping: bool,
        }
        impl MemoryEffectsV1 {
            pub fn union(self, other: Self) -> Self {
                Self {
                    may_allocate_managed: self.may_allocate_managed || other.may_allocate_managed,
                    may_auto_collect_at_allocation: self.may_auto_collect_at_allocation
                        || other.may_auto_collect_at_allocation,
                    may_explicitly_collect: self.may_explicitly_collect
                        || other.may_explicitly_collect,
                    may_allocate_root_bookkeeping: self.may_allocate_root_bookkeeping
                        || other.may_allocate_root_bookkeeping,
                }
            }
        }
        #[derive(Clone, Debug, PartialEq, Eq)]
        pub enum Shape {
            KInt,
            KBool,
            KUnit,
            KString,
            KError,
            KList(usize),
            KArray(usize),
            KRef(usize),
            KRecord(Vec<(usize, usize)>),
            KVariant(Vec<(usize, Vec<usize>)>),
        }
        #[derive(Clone, Debug, PartialEq, Eq)]
        pub struct Layout {
            pub name: usize,
            pub shape: Shape,
        }
        #[derive(Clone, Debug, PartialEq, Eq)]
        pub enum Op {
            EInt(i64),
            EBool(bool),
            EUnit,
            EString(usize),
            ELocal(usize),
            EField(usize, usize),
            EBinary(usize, usize, usize),
            ERecord(Vec<(usize, usize)>),
            ECall(usize, Vec<usize>),
            EConstruct(usize, Vec<usize>),
            EData(usize, Vec<usize>),
            ETry(usize),
            ERef(usize),
            EGet(usize),
            ESet(usize, usize),
            ECollect,
        }
        #[derive(Clone, Debug, PartialEq, Eq)]
        pub struct Expression {
            pub ty: usize,
            pub loc: Loc,
            pub op: Op,
        }
        #[derive(Clone, Debug, PartialEq, Eq)]
        pub struct Arm {
            pub case: Option<usize>,
            pub bindings: Vec<usize>,
            pub body: Vec<Statement>,
        }
        #[derive(Clone, Debug, PartialEq, Eq)]
        pub enum Statement {
            SLet(usize, usize),
            SAssign(usize, usize, usize),
            SExpr(usize),
            SReturn(Option<usize>),
            SIf(usize, Vec<Statement>, Vec<Statement>),
            SMatch(usize, Vec<Arm>),
            SRange(usize, usize, usize, Vec<Statement>),
            SFor(usize, usize, Vec<Statement>),
            SGuard(usize, Loc, Vec<Statement>),
        }
        #[derive(Clone, Debug, PartialEq, Eq)]
        pub struct Function {
            pub name: usize,
            pub parameters: Vec<usize>,
            pub parameter_types: Vec<usize>,
            pub result: usize,
            pub behavioral_effects: Vec<usize>,
            pub capabilities: Vec<usize>,
            pub requires: Vec<usize>,
            pub ensures: Vec<usize>,
            pub result_name: usize,
            pub body: Vec<Statement>,
            pub effects: MemoryEffectsV1,
            pub loc: Loc,
        }
        #[derive(Clone, Debug, PartialEq, Eq)]
        pub struct RootMapV1 {
            pub expression: usize,
            pub operands: Vec<usize>,
            pub may_allocate_managed: bool,
            pub root_result: bool,
        }
        #[derive(Clone, Debug, PartialEq, Eq)]
        pub struct Program {
            pub root_maps: Vec<RootMapV1>,
            pub strings: Vec<String>,
            pub layouts: Vec<Layout>,
            pub expressions: Vec<Expression>,
            pub functions: Vec<Function>,
            pub entry: usize,
            pub schema_version: u32,
            pub output_loc: Loc,
        }
        impl Program {
            /// All non-string vectors contain closed, numeric model data. Debug is valid
            /// Rust after adding Vec constructors; string pool is quoted independently.
            pub fn rust(&self) -> String {
                if self.expressions.len() > 2048 {
                    let hex = self
                        .wire_v1()
                        .iter()
                        .map(|b| format!("{b:02x}"))
                        .collect::<String>();
                    return format!("Program::decode_hex_v1({hex:?}).unwrap_or_else(|error|{{eprintln!(\"CGR090: managed model initialization failed: {{error}} at {}..{}\");std::process::exit(1)}})",self.output_loc.start,self.output_loc.end);
                }
                fn data<T: std::fmt::Debug>(value: &T) -> String {
                    format!("{value:?}").replace('[', "vec![")
                }
                format!("Program{{strings:vec![{}],layouts:{},expressions:{},functions:{},entry:{},schema_version:{},root_maps:{},output_loc:{:?}}}",
            self.strings.iter().map(|s|format!("{s:?}.into()")).collect::<Vec<_>>().join(","),
            data(&self.layouts),data(&self.expressions),data(&self.functions),self.entry,self.schema_version,data(&self.root_maps),self.output_loc)
            }
        }
    }
    /// Closed versioned metadata encoding, not an execution acceptance flag.
    /// Large generated programs use one hex literal rather than hundreds of
    /// thousands of Rust struct literals. All executable source is checked first.
    mod wire {
        use super::model::*;
        type Result<T> = std::result::Result<T, &'static str>;
        struct Writer(Vec<u8>);
        impl Writer {
            fn n(&mut self, mut n: u64) {
                while n >= 128 {
                    self.0.push((n as u8 & 127) | 128);
                    n >>= 7;
                }
                self.0.push(n as u8);
            }
            fn u(&mut self, n: usize) {
                self.n(n as u64)
            }
            fn b(&mut self, b: bool) {
                self.0.push(u8::from(b))
            }
            fn ids(&mut self, v: &[usize]) {
                self.u(v.len());
                for x in v {
                    self.u(*x);
                }
            }
            fn loc(&mut self, l: Loc) {
                self.u(l.start);
                self.u(l.end);
            }
            fn effects(&mut self, e: MemoryEffectsV1) {
                self.b(e.may_allocate_managed);
                self.b(e.may_auto_collect_at_allocation);
                self.b(e.may_explicitly_collect);
                self.b(e.may_allocate_root_bookkeeping);
            }
            fn option(&mut self, v: Option<usize>) {
                self.b(v.is_some());
                if let Some(v) = v {
                    self.u(v);
                }
            }
            fn shape(&mut self, s: &Shape) {
                match s {
                    Shape::KInt => self.u(0),
                    Shape::KBool => self.u(1),
                    Shape::KUnit => self.u(2),
                    Shape::KString => self.u(3),
                    Shape::KError => self.u(4),
                    Shape::KList(t) => {
                        self.u(5);
                        self.u(*t)
                    }
                    Shape::KArray(t) => {
                        self.u(6);
                        self.u(*t)
                    }
                    Shape::KRef(t) => {
                        self.u(7);
                        self.u(*t)
                    }
                    Shape::KRecord(fs) => {
                        self.u(8);
                        self.u(fs.len());
                        for (n, t) in fs {
                            self.u(*n);
                            self.u(*t);
                        }
                    }
                    Shape::KVariant(cs) => {
                        self.u(9);
                        self.u(cs.len());
                        for (n, ts) in cs {
                            self.u(*n);
                            self.ids(ts);
                        }
                    }
                }
            }
            fn op(&mut self, op: &Op) {
                match op {
                    Op::EInt(n) => {
                        self.u(0);
                        self.n(((*n as u64) << 1) ^ ((*n >> 63) as u64));
                    }
                    Op::EBool(b) => {
                        self.u(1);
                        self.b(*b)
                    }
                    Op::EUnit => self.u(2),
                    Op::EString(n) => {
                        self.u(3);
                        self.u(*n)
                    }
                    Op::ELocal(n) => {
                        self.u(4);
                        self.u(*n)
                    }
                    Op::EField(e, f) => {
                        self.u(5);
                        self.u(*e);
                        self.u(*f)
                    }
                    Op::EBinary(a, o, b) => {
                        self.u(6);
                        self.u(*a);
                        self.u(*o);
                        self.u(*b)
                    }
                    Op::ECall(f, es) => {
                        self.u(7);
                        self.u(*f);
                        self.ids(es)
                    }
                    Op::EConstruct(c, es) => {
                        self.u(8);
                        self.u(*c);
                        self.ids(es)
                    }
                    Op::EData(o, es) => {
                        self.u(9);
                        self.u(*o);
                        self.ids(es)
                    }
                    Op::ETry(e) => {
                        self.u(10);
                        self.u(*e)
                    }
                    Op::ERef(e) => {
                        self.u(11);
                        self.u(*e)
                    }
                    Op::EGet(e) => {
                        self.u(12);
                        self.u(*e)
                    }
                    Op::ESet(a, b) => {
                        self.u(13);
                        self.u(*a);
                        self.u(*b)
                    }
                    Op::ECollect => self.u(14),
                    Op::ERecord(fs) => {
                        self.u(15);
                        self.u(fs.len());
                        for (f, e) in fs {
                            self.u(*f);
                            self.u(*e);
                        }
                    }
                }
            }
            fn body(&mut self, body: &[Statement]) {
                self.u(body.len());
                for s in body {
                    match s {
                        Statement::SLet(n, e) => {
                            self.u(0);
                            self.u(*n);
                            self.u(*e)
                        }
                        Statement::SAssign(n, o, e) => {
                            self.u(1);
                            self.u(*n);
                            self.u(*o);
                            self.u(*e)
                        }
                        Statement::SExpr(e) => {
                            self.u(2);
                            self.u(*e)
                        }
                        Statement::SReturn(e) => {
                            self.u(3);
                            self.option(*e)
                        }
                        Statement::SIf(e, a, b) => {
                            self.u(4);
                            self.u(*e);
                            self.body(a);
                            self.body(b)
                        }
                        Statement::SMatch(e, arms) => {
                            self.u(5);
                            self.u(*e);
                            self.u(arms.len());
                            for a in arms {
                                self.option(a.case);
                                self.ids(&a.bindings);
                                self.body(&a.body)
                            }
                        }
                        Statement::SFor(n, e, b) => {
                            self.u(6);
                            self.u(*n);
                            self.u(*e);
                            self.body(b)
                        }
                        Statement::SGuard(n, l, b) => {
                            self.u(7);
                            self.u(*n);
                            self.loc(*l);
                            self.body(b)
                        }
                        Statement::SRange(n, a, b, body) => {
                            self.u(8);
                            self.u(*n);
                            self.u(*a);
                            self.u(*b);
                            self.body(body)
                        }
                    }
                }
            }
        }
        struct Reader<'a> {
            bytes: &'a [u8],
            at: usize,
        }
        impl Reader<'_> {
            fn byte(&mut self) -> Result<u8> {
                let b = *self.bytes.get(self.at).ok_or("truncated model")?;
                self.at += 1;
                Ok(b)
            }
            fn n(&mut self) -> Result<u64> {
                let mut n = 0u64;
                for shift in (0..=63).step_by(7) {
                    let b = self.byte()?;
                    if shift == 63 && b > 1 {
                        return Err("model integer overflow");
                    }
                    n |= u64::from(b & 127) << shift;
                    if b & 128 == 0 {
                        return Ok(n);
                    }
                }
                Err("model integer overflow")
            }
            fn u(&mut self) -> Result<usize> {
                usize::try_from(self.n()?).map_err(|_| "model target integer overflow")
            }
            fn b(&mut self) -> Result<bool> {
                match self.byte()? {
                    0 => Ok(false),
                    1 => Ok(true),
                    _ => Err("invalid model boolean"),
                }
            }
            fn vec<T>(&mut self, mut read: impl FnMut(&mut Self) -> Result<T>) -> Result<Vec<T>> {
                let n = self.u()?;
                if n > self.bytes.len().saturating_sub(self.at) {
                    return Err("model vector envelope");
                }
                let mut v = Vec::new();
                v.try_reserve_exact(n)
                    .map_err(|_| "model host allocation failed")?;
                for _ in 0..n {
                    v.push(read(self)?);
                }
                Ok(v)
            }
            fn ids(&mut self) -> Result<Vec<usize>> {
                self.vec(Self::u)
            }
            fn loc(&mut self) -> Result<Loc> {
                let loc = Loc {
                    start: self.u()?,
                    end: self.u()?,
                };
                if loc.start > loc.end {
                    return Err("invalid model source span");
                }
                Ok(loc)
            }
            fn effects(&mut self) -> Result<MemoryEffectsV1> {
                Ok(MemoryEffectsV1 {
                    may_allocate_managed: self.b()?,
                    may_auto_collect_at_allocation: self.b()?,
                    may_explicitly_collect: self.b()?,
                    may_allocate_root_bookkeeping: self.b()?,
                })
            }
            fn option(&mut self) -> Result<Option<usize>> {
                if self.b()? {
                    Ok(Some(self.u()?))
                } else {
                    Ok(None)
                }
            }
            fn shape(&mut self) -> Result<Shape> {
                Ok(match self.u()? {
                    0 => Shape::KInt,
                    1 => Shape::KBool,
                    2 => Shape::KUnit,
                    3 => Shape::KString,
                    4 => Shape::KError,
                    5 => Shape::KList(self.u()?),
                    6 => Shape::KArray(self.u()?),
                    7 => Shape::KRef(self.u()?),
                    8 => Shape::KRecord(self.vec(|r| Ok((r.u()?, r.u()?)))?),
                    9 => Shape::KVariant(self.vec(|r| Ok((r.u()?, r.ids()?)))?),
                    _ => return Err("unknown model shape"),
                })
            }
            fn op(&mut self) -> Result<Op> {
                Ok(match self.u()? {
                    0 => {
                        let n = self.n()?;
                        Op::EInt(((n >> 1) as i64) ^ (-((n & 1) as i64)))
                    }
                    1 => Op::EBool(self.b()?),
                    2 => Op::EUnit,
                    3 => Op::EString(self.u()?),
                    4 => Op::ELocal(self.u()?),
                    5 => Op::EField(self.u()?, self.u()?),
                    6 => Op::EBinary(self.u()?, self.u()?, self.u()?),
                    7 => Op::ECall(self.u()?, self.ids()?),
                    8 => Op::EConstruct(self.u()?, self.ids()?),
                    9 => Op::EData(self.u()?, self.ids()?),
                    10 => Op::ETry(self.u()?),
                    11 => Op::ERef(self.u()?),
                    12 => Op::EGet(self.u()?),
                    13 => Op::ESet(self.u()?, self.u()?),
                    14 => Op::ECollect,
                    15 => Op::ERecord(self.vec(|r| Ok((r.u()?, r.u()?)))?),
                    _ => return Err("unknown model operation"),
                })
            }
            fn body(&mut self, depth: usize) -> Result<Vec<Statement>> {
                if depth > 256 {
                    return Err("model statement depth exceeds 256");
                }
                self.vec(|r| {
                    Ok(match r.u()? {
                        0 => Statement::SLet(r.u()?, r.u()?),
                        1 => Statement::SAssign(r.u()?, r.u()?, r.u()?),
                        2 => Statement::SExpr(r.u()?),
                        3 => Statement::SReturn(r.option()?),
                        4 => Statement::SIf(r.u()?, r.body(depth + 1)?, r.body(depth + 1)?),
                        5 => Statement::SMatch(
                            r.u()?,
                            r.vec(|r| {
                                Ok(Arm {
                                    case: r.option()?,
                                    bindings: r.ids()?,
                                    body: r.body(depth + 1)?,
                                })
                            })?,
                        ),
                        6 => Statement::SFor(r.u()?, r.u()?, r.body(depth + 1)?),
                        7 => Statement::SGuard(r.u()?, r.loc()?, r.body(depth + 1)?),
                        8 => Statement::SRange(r.u()?, r.u()?, r.u()?, r.body(depth + 1)?),
                        _ => return Err("unknown model statement"),
                    })
                })
            }
        }
        impl Program {
            pub fn wire_v1(&self) -> Vec<u8> {
                let mut w = Writer(b"CGMD\x01".to_vec());
                w.u(self.schema_version as usize);
                w.u(self.strings.len());
                for s in &self.strings {
                    w.u(s.len());
                    w.0.extend_from_slice(s.as_bytes());
                }
                w.u(self.layouts.len());
                for l in &self.layouts {
                    w.u(l.name);
                    w.shape(&l.shape);
                }
                w.u(self.expressions.len());
                for e in &self.expressions {
                    w.u(e.ty);
                    w.loc(e.loc);
                    w.op(&e.op);
                }
                w.u(self.functions.len());
                for f in &self.functions {
                    w.u(f.name);
                    w.ids(&f.parameters);
                    w.ids(&f.parameter_types);
                    w.u(f.result);
                    w.ids(&f.behavioral_effects);
                    w.ids(&f.capabilities);
                    w.ids(&f.requires);
                    w.ids(&f.ensures);
                    w.u(f.result_name);
                    w.body(&f.body);
                    w.effects(f.effects);
                    w.loc(f.loc);
                }
                w.u(self.entry);
                w.loc(self.output_loc);
                w.u(self.root_maps.len());
                for r in &self.root_maps {
                    w.u(r.expression);
                    w.ids(&r.operands);
                    w.b(r.may_allocate_managed);
                    w.b(r.root_result);
                }
                w.0
            }
            pub fn decode_hex_v1(hex: &str) -> Result<Self> {
                if hex.len() > 64 * 1024 * 1024 || !hex.len().is_multiple_of(2) {
                    return Err("model hex envelope");
                }
                fn digit(b: u8) -> Result<u8> {
                    match b {
                        b'0'..=b'9' => Ok(b - b'0'),
                        b'a'..=b'f' => Ok(b - b'a' + 10),
                        _ => Err("invalid model hex digit"),
                    }
                }
                let mut bytes = Vec::new();
                bytes
                    .try_reserve_exact(hex.len() / 2)
                    .map_err(|_| "model host allocation failed")?;
                for pair in hex.as_bytes().as_chunks::<2>().0 {
                    bytes.push((digit(pair[0])? << 4) | digit(pair[1])?);
                }
                Self::decode_wire_v1(&bytes)
            }
            pub fn decode_wire_v1(bytes: &[u8]) -> Result<Self> {
                if bytes.len() > 32 * 1024 * 1024 || !bytes.starts_with(b"CGMD\x01") {
                    return Err("model wire envelope");
                }
                let mut r = Reader { bytes, at: 5 };
                let schema_version = u32::try_from(r.u()?).map_err(|_| "model schema overflow")?;
                if schema_version != 1 {
                    return Err("unknown model schema");
                }
                let strings = r.vec(|r| {
                    let n = r.u()?;
                    let end = r.at.checked_add(n).ok_or("model string overflow")?;
                    let bytes = r.bytes.get(r.at..end).ok_or("truncated model string")?;
                    r.at = end;
                    let text = std::str::from_utf8(bytes).map_err(|_| "invalid model UTF-8")?;
                    let mut s = String::new();
                    s.try_reserve_exact(n)
                        .map_err(|_| "model host allocation failed")?;
                    s.push_str(text);
                    Ok(s)
                })?;
                let layouts = r.vec(|r| {
                    Ok(Layout {
                        name: r.u()?,
                        shape: r.shape()?,
                    })
                })?;
                if layouts.len() > 4096 {
                    return Err("model layout envelope");
                }
                let expressions = r.vec(|r| {
                    Ok(Expression {
                        ty: r.u()?,
                        loc: r.loc()?,
                        op: r.op()?,
                    })
                })?;
                if expressions.len() > 1_000_000 {
                    return Err("model expression envelope");
                }
                let functions = r.vec(|r| {
                    Ok(Function {
                        name: r.u()?,
                        parameters: r.ids()?,
                        parameter_types: r.ids()?,
                        result: r.u()?,
                        behavioral_effects: r.ids()?,
                        capabilities: r.ids()?,
                        requires: r.ids()?,
                        ensures: r.ids()?,
                        result_name: r.u()?,
                        body: r.body(0)?,
                        effects: r.effects()?,
                        loc: r.loc()?,
                    })
                })?;
                if functions.len() > 256 {
                    return Err("model function envelope");
                }
                let entry = r.u()?;
                let output_loc = r.loc()?;
                let root_maps = r.vec(|r| {
                    Ok(RootMapV1 {
                        expression: r.u()?,
                        operands: r.ids()?,
                        may_allocate_managed: r.b()?,
                        root_result: r.b()?,
                    })
                })?;
                if r.at != bytes.len() {
                    return Err("trailing model bytes");
                }
                Ok(Self {
                    strings,
                    layouts,
                    expressions,
                    functions,
                    entry,
                    schema_version,
                    output_loc,
                    root_maps,
                })
            }
        }
    }
    pub(crate) mod engine {
        use super::model::*;
        use crate::cgx2_runtime::{
            AllocationError, CleanupReport, GraphError, Handle, MemoryError, MemoryReport,
            RegionId, ScopedRoots, Session,
        };
        use std::collections::{HashMap, HashSet};
        use std::fmt;

        const STEPS: usize = 1_000_000;
        const NODES: usize = 65_537;
        const ELEMENTS: usize = 65_536;
        const BYTES: usize = 1_048_576;
        const WRAPPERS: usize = 32;
        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        enum Atom {
            Int(i64),
            Bool(bool),
            Unit,
            Heap(Handle),
            Error(u8),
            Region(RegionId),
        }
        #[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
        struct Carrier {
            ty: usize,
            case: usize,
        }
        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        struct Value {
            ty: usize,
            atom: Atom,
            carriers: [Carrier; WRAPPERS],
            depth: usize,
        }
        impl Value {
            fn new(ty: usize, atom: Atom) -> Self {
                Self {
                    ty,
                    atom,
                    carriers: [Carrier::default(); WRAPPERS],
                    depth: 0,
                }
            }
            fn handle(self) -> Option<Handle> {
                if let Atom::Heap(h) = self.atom {
                    Some(h)
                } else {
                    None
                }
            }
            fn wrap(mut self, ty: usize, case: usize) -> Result<Self, Fault> {
                if self.depth == WRAPPERS {
                    return Err(Fault::allocation(AllocationError::ShapeLimit));
                }
                self.carriers[self.depth] = Carrier { ty: self.ty, case };
                self.depth += 1;
                self.ty = ty;
                Ok(self)
            }
            fn unwrap(mut self) -> (usize, Self) {
                self.depth -= 1;
                let c = self.carriers[self.depth];
                self.ty = c.ty;
                (c.case, self)
            }
        }
        #[derive(Clone, Debug, PartialEq, Eq)]
        pub enum Snapshot {
            Integer(i64),
            Boolean(bool),
            Text(String),
            Unit,
            Record(String, Vec<(String, Snapshot)>),
            Variant(String, String, Vec<Snapshot>),
            Sequence(bool, Vec<Snapshot>),
        }
        impl fmt::Display for Snapshot {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                match self {
                    Self::Integer(v) => write!(f, "{v}"),
                    Self::Boolean(v) => write!(f, "{v}"),
                    Self::Text(v) => f.write_str(v),
                    Self::Unit => Ok(()),
                    Self::Record(n, fields) => {
                        write!(f, "{n}(")?;
                        for (i, (n, v)) in fields.iter().enumerate() {
                            if i > 0 {
                                f.write_str(", ")?;
                            }
                            write!(f, "{n}: {v}")?;
                        }
                        f.write_str(")")
                    }
                    Self::Variant(n, c, vs) => {
                        write!(f, "{n}.{c}(")?;
                        for (i, v) in vs.iter().enumerate() {
                            if i > 0 {
                                f.write_str(", ")?;
                            }
                            write!(f, "{v}")?;
                        }
                        f.write_str(")")
                    }
                    Self::Sequence(array, vs) => {
                        if *array {
                            f.write_str("Array")?;
                        }
                        f.write_str("[")?;
                        for (i, v) in vs.iter().enumerate() {
                            if i > 0 {
                                f.write_str(", ")?;
                            }
                            write!(f, "{v}")?;
                        }
                        f.write_str("]")
                    }
                }
            }
        }
        #[derive(Clone, Debug, PartialEq, Eq)]
        pub struct Failure {
            pub code: &'static str,
            pub message: String,
            pub loc: Loc,
            pub function: Option<usize>,
        }
        #[derive(Clone, Debug, Default, PartialEq, Eq)]
        pub struct Evidence {
            pub allocations: usize,
            pub roots_registered: usize,
            pub roots_released: usize,
            pub cleanup_failures: usize,
            pub recovered: usize,
            pub guard_entries: usize,
            pub guard_exits: usize,
            pub guard_entry_failures: usize,
            pub graph_reads: usize,
            pub graph_writes: usize,
            pub baseline_roots: usize,
            pub final_roots: usize,
            pub charged_bytes: u128,
            pub steps: usize,
            pub memory_effects_v1: MemoryEffectsV1,
            pub behavioral_effects: Vec<String>,
            pub capabilities: Vec<String>,
        }
        impl Evidence {
            pub fn json(&self, memory: &MemoryReport) -> String {
                format!("{{\"schema_version\":1,\"allocations\":{},\"roots_registered\":{},\"roots_released\":{},\"cleanup_failures\":{},\"recovered\":{},\"guard_entries\":{},\"guard_exits\":{},\"guard_entry_failures\":{},\"graph_reads\":{},\"graph_writes\":{},\"baseline_roots\":{},\"final_roots\":{},\"charged_bytes\":{},\"behavioral_effects\":{:?},\"capabilities\":{:?},\"memory_effects_v1\":{{\"may_allocate_managed\":{},\"may_auto_collect_at_allocation\":{},\"may_explicitly_collect\":{},\"may_allocate_root_bookkeeping\":{}}},\"memory\":{}}}",self.allocations,self.roots_registered,self.roots_released,self.cleanup_failures,self.recovered,self.guard_entries,self.guard_exits,self.guard_entry_failures,self.graph_reads,self.graph_writes,self.baseline_roots,self.final_roots,self.charged_bytes,self.behavioral_effects,self.capabilities,self.memory_effects_v1.may_allocate_managed,self.memory_effects_v1.may_auto_collect_at_allocation,self.memory_effects_v1.may_explicitly_collect,self.memory_effects_v1.may_allocate_root_bookkeeping,memory.to_json())
            }
        }
        #[derive(Clone, Debug)]
        pub struct Execution {
            pub result: Result<Snapshot, Failure>,
            pub evidence: Evidence,
            pub memory: MemoryReport,
        }
        #[derive(Debug)]
        enum Fault {
            AllocationAt(AllocationError, Loc, Option<usize>),
            Primary(Failure),
        }
        impl Fault {
            fn allocation(error: AllocationError) -> Self {
                Self::AllocationAt(error, Loc::default(), None)
            }
        }
        type Fallible<T> = Result<T, Fault>;
        fn invariant(message: impl Into<String>) -> Fault {
            Fault::Primary(Failure {
                code: "CGR091",
                message: message.into(),
                loc: Loc::default(),
                function: None,
            })
        }
        impl From<GraphError> for Fault {
            fn from(e: GraphError) -> Self {
                match e {
                    GraphError::Memory(MemoryError::Allocation(e)) => Self::allocation(e),
                    GraphError::ShapeLimit => Self::allocation(AllocationError::ShapeLimit),
                    _ => invariant(format!("managed graph invariant: {e:?}")),
                }
            }
        }
        impl From<MemoryError> for Fault {
            fn from(e: MemoryError) -> Self {
                match e {
                    MemoryError::Allocation(e) => Self::allocation(e),
                    _ => invariant(format!("managed memory invariant: {e:?}")),
                }
            }
        }
        fn primary(code: &'static str, message: impl Into<String>, loc: Loc) -> Fault {
            Fault::Primary(Failure {
                code,
                message: message.into(),
                loc,
                function: None,
            })
        }
        fn failure(f: Fault, loc: Loc) -> Failure {
            match f {
                Fault::AllocationAt(e, at, function) => Failure {
                    code: "CGR090",
                    message: format!("managed allocation failed: {e:?}"),
                    loc: if at == Loc::default() { loc } else { at },
                    function,
                },
                Fault::Primary(mut e) => {
                    if e.loc == Loc::default() {
                        e.loc = loc;
                    }
                    e
                }
            }
        }
        struct Machine<'a> {
            memory: Option<&'a crate::cgx2_runtime::ordinary_memory::MemoryProgramV1>,
            allocation_region: Option<RegionId>,
            p: &'a Program,
            args: &'a [String],
            steps: usize,
            depth: usize,
            step_limit: usize,
            evidence: Evidence,
        }
        struct Env(Vec<HashMap<usize, Value>>);
        impl Env {
            fn new() -> Self {
                Self(vec![HashMap::new()])
            }
            fn get(&self, n: usize) -> Fallible<Value> {
                self.0
                    .iter()
                    .rev()
                    .find_map(|m| m.get(&n).copied())
                    .ok_or_else(|| invariant("uninitialized local"))
            }
            fn pop(
                &mut self,
                roots: &mut ScopedRoots<'_>,
                evidence: &mut Evidence,
            ) -> Fallible<()> {
                for v in self
                    .0
                    .pop()
                    .ok_or_else(|| invariant("scope underflow"))?
                    .into_values()
                {
                    release(roots, v, evidence)?;
                }
                Ok(())
            }
        }
        fn root(roots: &mut ScopedRoots<'_>, v: Value, e: &mut Evidence) -> Fallible<()> {
            if let Some(h) = v.handle() {
                roots.root(h)?;
                e.roots_registered += 1;
            }
            Ok(())
        }
        fn release(roots: &mut ScopedRoots<'_>, v: Value, e: &mut Evidence) -> Fallible<()> {
            if let Some(h) = v.handle() {
                roots.release(h)?;
                e.roots_released += 1;
            }
            Ok(())
        }
        fn cleanup(e: &mut Evidence, r: CleanupReport) {
            e.roots_released += r.released_roots;
            if r.first_error.is_some() {
                e.cleanup_failures += 1;
            }
        }
        fn integer(v: Value) -> Fallible<i64> {
            match v.atom {
                Atom::Int(n) if v.depth == 0 => Ok(n),
                _ => Err(invariant("expected integer")),
            }
        }
        fn boolean(v: Value) -> Fallible<bool> {
            match v.atom {
                Atom::Bool(n) if v.depth == 0 => Ok(n),
                _ => Err(invariant("expected Boolean")),
            }
        }
        fn reserve<T>(v: &mut Vec<T>, n: usize) -> Fallible<()> {
            v.try_reserve_exact(n)
                .map_err(|_| Fault::allocation(AllocationError::HostAllocation))
        }

        #[derive(Clone, Copy)]
        enum EntryValue {
            Int(i64),
            Bool(bool),
            Unit,
            Error(crate::cgx2_runtime::SessionEntryError),
            Site,
        }
        struct EntryMachine<'a> {
            p: &'a Program,
            steps: usize,
            depth: usize,
        }
        impl EntryMachine<'_> {
            fn step(&mut self, loc: Loc) -> Fallible<()> {
                self.steps += 1;
                if self.steps > STEPS {
                    Err(primary("CGR010", "execution work budget exceeded", loc))
                } else {
                    Ok(())
                }
            }
            fn expr(
                &mut self,
                id: usize,
                env: &[HashMap<usize, EntryValue>],
            ) -> Fallible<EntryValue> {
                let e = self
                    .p
                    .expressions
                    .get(id)
                    .ok_or_else(|| invariant("fallback expression"))?;
                self.step(e.loc)?;
                match &e.op {
                    Op::EInt(n) => Ok(EntryValue::Int(*n)),
                    Op::EBool(b) => Ok(EntryValue::Bool(*b)),
                    Op::EUnit => Ok(EntryValue::Unit),
                    Op::ELocal(n) => env
                        .iter()
                        .rev()
                        .find_map(|s| s.get(n).copied())
                        .ok_or_else(|| invariant("fallback local")),
                    Op::EBinary(a, op, b) => {
                        let a = self.expr(*a, env)?;
                        let b = self.expr(*b, env)?;
                        match (a, b) {
                            (EntryValue::Int(a), EntryValue::Int(b)) => {
                                if *op <= 4 {
                                    if *op == 4 && b == 0 {
                                        return Err(primary("CGR006", "division by zero", e.loc));
                                    }
                                    let n = match op {
                                        1 => a.checked_add(b),
                                        2 => a.checked_sub(b),
                                        3 => a.checked_mul(b),
                                        4 => a.checked_div(b),
                                        _ => None,
                                    }
                                    .ok_or_else(|| {
                                        primary("CGR005", "i64 arithmetic overflow", e.loc)
                                    })?;
                                    Ok(EntryValue::Int(n))
                                } else {
                                    Ok(EntryValue::Bool(match op {
                                        5 => a == b,
                                        6 => a != b,
                                        7 => a < b,
                                        8 => a <= b,
                                        9 => a > b,
                                        10 => a >= b,
                                        _ => return Err(invariant("fallback comparison")),
                                    }))
                                }
                            }
                            (EntryValue::Bool(a), EntryValue::Bool(b)) if matches!(op, 5 | 6) => {
                                Ok(EntryValue::Bool(if *op == 5 { a == b } else { a != b }))
                            }
                            _ => Err(invariant("fallback scalar operation")),
                        }
                    }
                    Op::ECall(f, args) => {
                        let mut values = Vec::new();
                        reserve(&mut values, args.len())?;
                        for e in args {
                            values.push(self.expr(*e, env)?);
                        }
                        self.call(*f, values)
                    }
                    _ => Err(invariant("resource operation before Session entry")),
                }
            }
            fn call(&mut self, id: usize, arguments: Vec<EntryValue>) -> Fallible<EntryValue> {
                let f = self
                    .p
                    .functions
                    .get(id)
                    .ok_or_else(|| invariant("fallback callee"))?;
                if self.depth >= 64 {
                    return Err(primary("CGR011", "call depth exceeds 64", f.loc));
                }
                if f.parameters.len() != arguments.len() {
                    return Err(primary("CGR012", "function argument count mismatch", f.loc));
                }
                self.depth += 1;
                let mut env = vec![f.parameters.iter().copied().zip(arguments).collect()];
                let result = (|| {
                    for c in &f.requires {
                        if !matches!(self.expr(*c, &env)?, EntryValue::Bool(true)) {
                            return Err(primary(
                                "CGR015",
                                "requires condition failed",
                                self.p.expressions[*c].loc,
                            ));
                        }
                    }
                    let (value, _) = self.block(&f.body, &mut env)?;
                    env[0].insert(f.result_name, value);
                    for c in &f.ensures {
                        if !matches!(self.expr(*c, &env)?, EntryValue::Bool(true)) {
                            return Err(primary(
                                "CGR016",
                                "ensures condition failed",
                                self.p.expressions[*c].loc,
                            ));
                        }
                    }
                    Ok(value)
                })();
                self.depth -= 1;
                result
            }
            fn block(
                &mut self,
                body: &[Statement],
                env: &mut Vec<HashMap<usize, EntryValue>>,
            ) -> Fallible<(EntryValue, bool)> {
                let mut value = EntryValue::Unit;
                for st in body {
                    self.step(Loc::default())?;
                    match st {
                        Statement::SLet(n, e) => {
                            let v = self.expr(*e, env)?;
                            env.last_mut()
                                .ok_or_else(|| invariant("fallback scope"))?
                                .insert(*n, v);
                            value = EntryValue::Unit;
                        }
                        Statement::SExpr(e) => value = self.expr(*e, env)?,
                        Statement::SReturn(e) => {
                            return Ok((
                                if let Some(e) = e {
                                    self.expr(*e, env)?
                                } else {
                                    EntryValue::Unit
                                },
                                true,
                            ))
                        }
                        Statement::SAssign(n, op, e) => {
                            let mut v = self.expr(*e, env)?;
                            let old = env
                                .iter_mut()
                                .rev()
                                .find_map(|s| s.get_mut(n))
                                .ok_or_else(|| invariant("fallback assignment"))?;
                            if *op == 1 {
                                let (EntryValue::Int(a), EntryValue::Int(b)) = (*old, v) else {
                                    return Err(invariant("fallback compound scalar assignment"));
                                };
                                v = EntryValue::Int(a.checked_add(b).ok_or_else(|| {
                                    primary(
                                        "CGR005",
                                        "i64 arithmetic overflow",
                                        self.p.expressions[*e].loc,
                                    )
                                })?);
                            } else if *op != 0 {
                                return Err(invariant("fallback assignment operator"));
                            }
                            *old = v;
                            value = EntryValue::Unit;
                        }
                        Statement::SRange(n, start, end, body) => {
                            let (EntryValue::Int(start), EntryValue::Int(end)) =
                                (self.expr(*start, env)?, self.expr(*end, env)?)
                            else {
                                return Err(invariant("fallback range bounds"));
                            };
                            for i in start..end {
                                self.step(Loc::default())?;
                                env.push(HashMap::from([(*n, EntryValue::Int(i))]));
                                let branch = self.block(body, env);
                                env.pop();
                                let (v, returned) = branch?;
                                if returned {
                                    return Ok((v, true));
                                }
                            }
                            value = EntryValue::Unit;
                        }
                        Statement::SIf(e, a, b) => {
                            let EntryValue::Bool(condition) = self.expr(*e, env)? else {
                                return Err(invariant("fallback condition"));
                            };
                            env.push(HashMap::new());
                            let branch = self.block(if condition { a } else { b }, env);
                            env.pop();
                            let (v, returned) = branch?;
                            if returned {
                                return Ok((v, true));
                            }
                            value = v;
                        }
                        Statement::SMatch(e, arms) => {
                            let (case, payload) = match self.expr(*e, env)? {
                                EntryValue::Error(crate::cgx2_runtime::SessionEntryError::HostAllocation {
                                    site: crate::cgx2_runtime::ReserveSiteV2::SessionRegions,
                                }) => (0, Some(EntryValue::Site)),
                                EntryValue::Error(
                                    crate::cgx2_runtime::SessionEntryError::IdentifierExhausted,
                                ) => (1, None),
                                EntryValue::Site => (0, None),
                                _ => return Err(invariant("fallback entry error match")),
                            };
                            let arm = arms
                                .iter()
                                .find(|a| a.case.is_none_or(|c| c == case))
                                .ok_or_else(|| invariant("fallback nonexhaustive match"))?;
                            env.push(HashMap::new());
                            if let (Some(n), Some(v)) = (arm.bindings.first(), payload) {
                                env.last_mut().unwrap().insert(*n, v);
                            }
                            let branch = self.block(&arm.body, env);
                            env.pop();
                            let (v, returned) = branch?;
                            if returned {
                                return Ok((v, true));
                            }
                            value = v;
                        }
                        _ => {
                            return Err(invariant(
                                "resource or unsupported operation before Session entry",
                            ))
                        }
                    }
                }
                Ok((value, false))
            }
        }
        pub(crate) fn entry_failure(
            memory: &crate::cgx2_runtime::ordinary_memory::MemoryProgramV1,
            error: crate::cgx2_runtime::SessionEntryError,
        ) -> Execution {
            let p = &memory.program;
            let result = (|| {
                if memory.entry_policy != crate::cgx2_runtime::ordinary_memory::EntryPolicyV1::Recoverable {
                    return Err(primary(
                        "CGR090",
                        format!("managed session entry failed: {error:?}"),
                        p.functions.get(p.entry).map_or(p.output_loc, |f| f.loc),
                    ));
                }
                let f = p
                    .functions
                    .get(p.entry)
                    .ok_or_else(|| invariant("fallback entry function"))?;
                if !f.requires.is_empty() || !f.ensures.is_empty() || f.body.len() != 1 {
                    return Err(invariant("fallback entry contract"));
                }
                let Statement::SMatch(e, arms) = &f.body[0] else {
                    return Err(invariant("fallback entry policy"));
                };
                if !matches!(
                    memory.operations.get(e),
                    Some(crate::cgx2_runtime::ordinary_memory::MemoryOpV1::SessionEntry)
                ) {
                    return Err(invariant("fallback entry identity"));
                }
                let arm = arms
                    .iter()
                    .find(|a| a.case == Some(1))
                    .ok_or_else(|| invariant("missing Session error arm"))?;
                let mut machine = EntryMachine {
                    p,
                    steps: 0,
                    depth: 1,
                };
                let mut env = vec![HashMap::new()];
                let binding = *arm
                    .bindings
                    .first()
                    .ok_or_else(|| invariant("Session error binding"))?;
                env[0].insert(binding, EntryValue::Error(error));
                match machine.block(&arm.body, &mut env)?.0 {
                    EntryValue::Int(n) => Ok(Snapshot::Integer(n)),
                    EntryValue::Bool(b) => Ok(Snapshot::Boolean(b)),
                    EntryValue::Unit => Ok(Snapshot::Unit),
                    _ => Err(invariant("entry error capability escaped fallback")),
                }
            })();
            Execution {
                result: result.map_err(|e| failure(e, p.output_loc)),
                evidence: Evidence::default(),
                memory: MemoryReport {
                    schema_version: 1,
                    regions: vec![],
                    totals: Default::default(),
                },
            }
        }
        pub fn run(p: &Program, args: &[String]) -> Execution {
            match Session::try_new() {
                Ok(s) => run_with_session(p, args, s),
                Err(e) => Execution {
                    result: Err(Failure {
                        code: "CGR090",
                        message: format!("managed session entry failed: {e:?}"),
                        loc: p.functions.get(p.entry).map_or(Loc::default(), |f| f.loc),
                        function: None,
                    }),
                    evidence: Evidence::default(),
                    memory: MemoryReport {
                        schema_version: 1,
                        regions: vec![],
                        totals: Default::default(),
                    },
                },
            }
        }
        /// Copied-scalar bridge into an existing execution Session. No session is
        /// created, replaced or collected at entry/cleanup.
        pub fn run_function_borrowed(
            p: &Program,
            function: usize,
            args: &[Snapshot],
            session: &mut Session,
            remaining_steps: usize,
            depth: usize,
        ) -> Execution {
            let baseline = session.root_census().map_or(0, |r| r.root_registrations);
            let mut m = Machine {
                memory: None,
                allocation_region: None,
                p,
                args: &[],
                steps: 0,
                depth,
                step_limit: remaining_steps,
                evidence: Evidence {
                    baseline_roots: baseline,
                    ..Evidence::default()
                },
            };
            let mut roots = session.scoped_roots();
            let loc = p.functions.get(function).map_or(Loc::default(), |f| f.loc);
            let result = (|| {
                m.validate()?;
                let f = p
                    .functions
                    .get(function)
                    .ok_or_else(|| invariant("bridge callee"))?;
                if args.len() != f.parameter_types.len() {
                    return Err(invariant("bridge arity"));
                }
                let mut values = Vec::new();
                reserve(&mut values, args.len())?;
                for (arg, ty) in args.iter().zip(&f.parameter_types) {
                    let atom = match (arg, &p.layouts[*ty].shape) {
                        (Snapshot::Integer(n), Shape::KInt) => Atom::Int(*n),
                        (Snapshot::Boolean(b), Shape::KBool) => Atom::Bool(*b),
                        (Snapshot::Unit, Shape::KUnit) => Atom::Unit,
                        _ => return Err(invariant("bridge requires copied scalar arguments")),
                    };
                    values.push(Value::new(*ty, atom));
                }
                let value = m.call(function, values, &mut roots)?;
                root(&mut roots, value, &mut m.evidence)?;
                m.snapshot(value, &roots, &mut 0, 0)
            })();
            let outcome = roots.finish(result);
            cleanup(&mut m.evidence, outcome.cleanup);
            drop(roots);
            m.evidence.final_roots = session
                .root_census()
                .map_or(usize::MAX, |r| r.root_registrations);
            m.evidence.steps = m.steps;
            m.evidence.charged_bytes = session.memory_observation_v2().charged_bytes;
            Execution {
                result: outcome.result.map_err(|e| failure(e, loc)),
                evidence: m.evidence,
                memory: session.memory_report(),
            }
        }
        pub fn run_with_session(p: &Program, args: &[String], session: Session) -> Execution {
            run_configured(p, args, session, None)
        }
        pub(crate) fn run_memory_with_session(
            memory: &crate::cgx2_runtime::ordinary_memory::MemoryProgramV1,
            args: &[String],
            session: Session,
        ) -> Execution {
            run_configured(&memory.program, args, session, Some(memory))
        }
        fn run_configured<'a>(
            p: &'a Program,
            args: &[String],
            mut session: Session,
            memory: Option<&'a crate::cgx2_runtime::ordinary_memory::MemoryProgramV1>,
        ) -> Execution {
            let baseline = session.root_census().map_or(0, |r| r.root_registrations);
            let mut m = Machine {
                memory,
                allocation_region: None,
                p,
                args,
                steps: 0,
                depth: 0,
                step_limit: STEPS,
                evidence: Evidence {
                    baseline_roots: baseline,
                    ..Evidence::default()
                },
            };
            if let Some(f) = p.functions.get(p.entry) {
                m.evidence.memory_effects_v1 = f.effects;
                m.evidence.behavioral_effects = f
                    .behavioral_effects
                    .iter()
                    .map(|i| p.strings[*i].clone())
                    .collect();
                m.evidence.capabilities = f
                    .capabilities
                    .iter()
                    .map(|i| p.strings[*i].clone())
                    .collect();
            }
            let mut roots = session.scoped_roots();
            let loc = p.functions.get(p.entry).map_or(Loc::default(), |f| f.loc);
            let result = (|| {
                m.validate()?;
                if p.entry == usize::MAX {
                    return Err(primary("CGR008", "module requires main", p.output_loc));
                }
                let v = m.call(p.entry, vec![], &mut roots)?;
                root(&mut roots, v, &mut m.evidence)?;
                let mut count = 0;
                let snap = m.snapshot(v, &roots, &mut count, 0).map_err(|e| match e {
                    Fault::Primary(mut e) => {
                        if e.loc == Loc::default() {
                            e.loc = p.output_loc;
                        }
                        Fault::Primary(e)
                    }
                    e => e,
                })?;
                if snap.to_string().len() > BYTES {
                    return Err(primary(
                        "CGR010",
                        "output exceeds 1048576 bytes",
                        p.output_loc,
                    ));
                }
                Ok(snap)
            })();
            let outcome = roots.finish(result);
            cleanup(&mut m.evidence, outcome.cleanup);
            drop(roots);
            m.evidence.final_roots = session
                .root_census()
                .map_or(usize::MAX, |r| r.root_registrations);
            m.evidence.charged_bytes = session.memory_observation_v2().charged_bytes;
            m.evidence.steps = m.steps;
            Execution {
                result: outcome.result.map_err(|e| failure(e, loc)),
                evidence: m.evidence,
                memory: session.memory_report(),
            }
        }
        impl Machine<'_> {
            fn memory_error_value(&self, ty: usize, error: AllocationError) -> Fallible<Value> {
                let error_ty = match &self.p.layouts[ty].shape {
                    Shape::KVariant(cases) => cases.get(1).and_then(|c| c.1.first()).copied(),
                    _ => None,
                }
                .ok_or_else(|| invariant("ordinary-memory recovery layout"))?;
                Value::new(error_ty, Atom::Error(error_code(error))).wrap(ty, 1)
            }
            fn memory_region(
                &mut self,
                id: usize,
                env: &Env,
                roots: &mut ScopedRoots<'_>,
            ) -> Fallible<RegionId> {
                match self.expr(id, env, roots)?.atom {
                    Atom::Region(region) => Ok(region),
                    _ => Err(invariant("expected authenticated region capability")),
                }
            }
            fn memory_expr(
                &mut self,
                e: &Expression,
                operation: &crate::cgx2_runtime::ordinary_memory::MemoryOpV1,
                env: &Env,
                roots: &mut ScopedRoots<'_>,
            ) -> Fallible<Value> {
                use crate::cgx2_runtime::ordinary_memory::MemoryOpV1 as M;
                match operation {
                    M::DefaultRegion => Ok(Value::new(e.ty, Atom::Region(roots.default_region()))),
                    M::TryIn { region, value } => {
                        let region = self.memory_region(*region, env, roots)?;
                        let previous = self.allocation_region.replace(region);
                        let result = self.expr(*value, env, roots);
                        self.allocation_region = previous;
                        match result {
                            Ok(v) => {
                                if v.handle().is_some_and(|h| h.region() != region) {
                                    return Err(invariant(
                                        "allocation result has a different region",
                                    ));
                                }
                                v.wrap(e.ty, 0)
                            }
                            Err(Fault::AllocationAt(error, _, _)) => {
                                self.evidence.recovered += 1;
                                self.memory_error_value(e.ty, error)
                            }
                            Err(error) => Err(error),
                        }
                    }
                    M::CopyTo { region, value } => {
                        let destination = self.memory_region(*region, env, roots)?;
                        let value = self.expr(*value, env, roots)?;
                        let copied = if let Some(handle) = value.handle() {
                            roots.copy_graph_to_v1(destination, handle).map(|h| {
                                // copy_graph_to_v1 publishes one registration into
                                // this table; expression cleanup already sees it.
                                self.evidence.roots_registered += 1;
                                Value {
                                    atom: Atom::Heap(h),
                                    ..value
                                }
                            })
                        } else {
                            Ok(value)
                        };
                        // expr owns the recovery boundary, including argument
                        // evaluation and publication of the final result root.
                        copied.map_err(Fault::from)?.wrap(e.ty, 0)
                    }
                    M::Collect { region } => {
                        let region = self.memory_region(*region, env, roots)?;
                        roots.collect(region)?;
                        Ok(self.unit())
                    }
                    _ => Err(invariant("scoped entry must be a direct exhaustive match")),
                }
            }
            fn memory_arm(
                &mut self,
                case: usize,
                payload: Value,
                arms: &[Arm],
                env: &mut Env,
                roots: &mut ScopedRoots<'_>,
            ) -> Fallible<(Value, bool)> {
                let arm = arms.iter().find(|a| a.case == Some(case)).ok_or_else(|| {
                    invariant("ordinary-memory entry requires exhaustive Result arms")
                })?;
                if arm.bindings.len() != 1 {
                    return Err(invariant("entry payload binding count"));
                }
                env.0.push(HashMap::new());
                let result = (|| {
                    root(roots, payload, &mut self.evidence)?;
                    self.bind(env, roots, arm.bindings[0], payload)?;
                    self.block(&arm.body, env, roots, false)
                })();
                let popped = env.pop(roots, &mut self.evidence);
                match result {
                    Err(e) => Err(e),
                    Ok(value) => {
                        popped?;
                        Ok(value)
                    }
                }
            }
            fn memory_match(
                &mut self,
                expression: usize,
                operation: &crate::cgx2_runtime::ordinary_memory::MemoryOpV1,
                arms: &[Arm],
                env: &mut Env,
                roots: &mut ScopedRoots<'_>,
            ) -> Fallible<(Value, bool)> {
                use crate::cgx2_runtime::ordinary_memory::MemoryOpV1 as M;
                let e = &self.p.expressions[expression];
                let (ok_ty, err_ty) = match &self.p.layouts[e.ty].shape {
                    Shape::KVariant(cases)
                        if cases.len() == 2 && cases.iter().all(|c| c.1.len() == 1) =>
                    {
                        (cases[0].1[0], cases[1].1[0])
                    }
                    _ => return Err(invariant("scoped entry Result layout")),
                };
                let failure = |error| Value::new(err_ty, Atom::Error(error_code(error)));
                match operation {
                    M::SessionEntry => self.memory_arm(0, self.unit(), arms, env, roots),
                    M::GuardEntry { budget } => {
                        let budget = integer(self.expr(*budget, env, roots)?)?;
                        let Ok(budget) = usize::try_from(budget) else {
                            return self.memory_arm(
                                1,
                                failure(AllocationError::ShapeLimit),
                                arms,
                                env,
                                roots,
                            );
                        };
                        let result = roots.with_no_gc(budget, |guard| {
                            self.evidence.guard_entries += 1;
                            let result = self.memory_arm(0, self.unit(), arms, env, guard);
                            self.evidence.guard_exits += 1;
                            result
                        });
                        match result {
                            Ok(result) => result,
                            Err(error) => {
                                self.evidence.guard_entry_failures += 1;
                                self.memory_arm(1, failure(error), arms, env, roots)
                            }
                        }
                    }
                    M::RegionEntry {
                        manual,
                        arguments,
                        limit,
                        trigger,
                    } => {
                        let mut values = Vec::new();
                        reserve(&mut values, arguments.len())?;
                        for id in arguments {
                            values.push(integer(self.expr(*id, env, roots)?)?);
                        }
                        let limit = values
                            .get(*limit)
                            .copied()
                            .and_then(|v| usize::try_from(v).ok());
                        let trigger = trigger.map_or(Some(1 << 20), |i| {
                            values
                                .get(i)
                                .copied()
                                .and_then(|v| usize::try_from(v).ok())
                                .filter(|n| *n > 0)
                        });
                        let result = match (limit, trigger) {
                            (Some(limit), Some(trigger)) => roots.create_region(
                                if *manual {
                                    crate::cgx2_runtime::CollectionMode::Manual
                                } else {
                                    crate::cgx2_runtime::CollectionMode::Auto {
                                        trigger_bytes: trigger,
                                    }
                                },
                                limit,
                            ),
                            _ => Err(AllocationError::ShapeLimit),
                        };
                        match result {
                            Err(error) => self.memory_arm(1, failure(error), arms, env, roots),
                            Ok(region) => {
                                // Bindings and their registration table must have
                                // the same lifetime. In particular, assignment to
                                // an outer cell must release its old registration
                                // and leave the replacement alive after this arm.
                                let result = self.memory_arm(
                                    0,
                                    Value::new(ok_ty, Atom::Region(region)),
                                    arms,
                                    env,
                                    roots,
                                );
                                let result = result.and_then(|(v, returned)| {
                                    if v.handle().is_some_and(|h| h.region() == region)
                                        || matches!(v.atom, Atom::Region(r) if r == region)
                                    {
                                        return Err(invariant(
                                            "named region result escaped its scope",
                                        ));
                                    }
                                    Ok((v, returned))
                                });
                                let report = roots.cleanup_region_v1(region);
                                cleanup(&mut self.evidence, report);
                                let closed = roots.close_region(region);
                                match result {
                                    Err(error) => {
                                        if closed.is_err() {
                                            self.evidence.cleanup_failures += 1;
                                        }
                                        Err(error)
                                    }
                                    Ok(value) => {
                                        closed?;
                                        Ok(value)
                                    }
                                }
                            }
                        }
                    }
                    _ => Err(invariant("invalid scoped ordinary-memory entry")),
                }
            }

            fn validate(&self) -> Fallible<()> {
                if self.p.schema_version != 1
                    || (self.p.entry >= self.p.functions.len() && self.p.entry != usize::MAX)
                    || self.p.layouts.len() > 4096
                    || self.p.expressions.len() > 1_000_000
                {
                    return Err(invariant("invalid managed program envelope"));
                }
                for l in &self.p.layouts {
                    if l.name >= self.p.strings.len() {
                        return Err(invariant("layout name"));
                    }
                }
                Ok(())
            }
            fn step(&mut self, loc: Loc) -> Fallible<()> {
                self.work(1, loc)
            }
            fn work(&mut self, units: usize, loc: Loc) -> Fallible<()> {
                self.steps = self
                    .steps
                    .checked_add(units)
                    .ok_or_else(|| primary("CGR010", "execution work budget exceeded", loc))?;
                if self.steps > self.step_limit {
                    Err(primary("CGR010", "execution work budget exceeded", loc))
                } else {
                    Ok(())
                }
            }
            fn unit(&self) -> Value {
                Value::new(
                    self.p
                        .layouts
                        .iter()
                        .position(|t| t.shape == Shape::KUnit)
                        .unwrap_or(0),
                    Atom::Unit,
                )
            }
            fn int(&self, n: i64) -> Value {
                Value::new(
                    self.p
                        .layouts
                        .iter()
                        .position(|t| t.shape == Shape::KInt)
                        .unwrap_or(0),
                    Atom::Int(n),
                )
            }
            fn bind(
                &mut self,
                env: &mut Env,
                roots: &mut ScopedRoots<'_>,
                n: usize,
                v: Value,
            ) -> Fallible<()> {
                if let Some(old) = env
                    .0
                    .last_mut()
                    .ok_or_else(|| invariant("scope"))?
                    .insert(n, v)
                {
                    release(roots, old, &mut self.evidence)?;
                }
                Ok(())
            }
            fn assign(
                &mut self,
                env: &mut Env,
                roots: &mut ScopedRoots<'_>,
                n: usize,
                v: Value,
            ) -> Fallible<()> {
                let old = env
                    .0
                    .iter_mut()
                    .rev()
                    .find_map(|m| m.get_mut(&n))
                    .ok_or_else(|| invariant("assignment local"))?;
                let old = std::mem::replace(old, v);
                release(roots, old, &mut self.evidence)
            }
            fn call(&mut self, id: usize, args: Vec<Value>, s: &mut Session) -> Fallible<Value> {
                let previous = self.allocation_region.take();
                let result = self.call_in_default_context(id, args, s);
                self.allocation_region = previous;
                result
            }
            fn call_in_default_context(
                &mut self,
                id: usize,
                args: Vec<Value>,
                s: &mut Session,
            ) -> Fallible<Value> {
                let f = self
                    .p
                    .functions
                    .get(id)
                    .ok_or_else(|| invariant("callee index"))?;
                if self.depth >= 64 {
                    return Err(primary(
                        "CGR011",
                        "function call depth limit of 64 exceeded",
                        f.loc,
                    ));
                }
                if args.len() != f.parameters.len() {
                    return Err(primary("CGR012", "function argument count mismatch", f.loc));
                }
                self.depth += 1;
                let mut roots = s.scoped_roots();
                let mut env = Env::new();
                let result = (|| {
                    for (n, v) in f.parameters.iter().zip(args) {
                        root(&mut roots, v, &mut self.evidence)?;
                        self.bind(&mut env, &mut roots, *n, v)?;
                    }
                    for &e in &f.requires {
                        if !boolean(self.expr(e, &env, &mut roots)?)? {
                            return Err(primary(
                                "CGR015",
                                "requires condition failed",
                                self.p.expressions[e].loc,
                            ));
                        }
                    }
                    let (v, _) = self.block(&f.body, &mut env, &mut roots, false)?;
                    root(&mut roots, v, &mut self.evidence)?;
                    self.bind(&mut env, &mut roots, f.result_name, v)?;
                    for &e in &f.ensures {
                        if !boolean(self.expr(e, &env, &mut roots)?)? {
                            return Err(primary(
                                "CGR016",
                                "ensures condition failed",
                                self.p.expressions[e].loc,
                            ));
                        }
                    }
                    Ok(v)
                })();
                let outcome = roots.finish(result);
                cleanup(&mut self.evidence, outcome.cleanup);
                self.depth -= 1;
                outcome.result.map_err(|e| match e {
                    Fault::Primary(mut e) => {
                        if e.function.is_none() {
                            e.function = Some(id);
                        }
                        Fault::Primary(e)
                    }
                    Fault::AllocationAt(error, at, function) => Fault::AllocationAt(
                        error,
                        if at == Loc::default() { f.loc } else { at },
                        function.or(Some(id)),
                    ),
                })
            }
            fn block(
                &mut self,
                body: &[Statement],
                env: &mut Env,
                roots: &mut ScopedRoots<'_>,
                nested: bool,
            ) -> Fallible<(Value, bool)> {
                if nested {
                    env.0.push(HashMap::new());
                }
                let mut tail = self.unit();
                let result = (|| {
                    for st in body {
                        self.step(Loc::default())?;
                        release(roots, tail, &mut self.evidence)?;
                        tail = self.unit();
                        match st {
                            Statement::SLet(n, e) => {
                                let v = self.expr(*e, env, roots)?;
                                self.bind(env, roots, *n, v)?;
                            }
                            Statement::SAssign(n, op, e) => {
                                let mut v = self.expr(*e, env, roots)?;
                                if *op != 0 {
                                    v = self.binary(
                                        env.get(*n)?,
                                        v,
                                        *op,
                                        self.p.expressions[*e].loc,
                                        roots,
                                    )?;
                                }
                                self.assign(env, roots, *n, v)?;
                            }
                            Statement::SExpr(e) => {
                                tail = self.expr(*e, env, roots)?;
                            }
                            Statement::SReturn(e) => {
                                let v = if let Some(e) = e {
                                    self.expr(*e, env, roots)?
                                } else {
                                    self.unit()
                                };
                                return Ok((v, true));
                            }
                            Statement::SIf(e, yes, no) => {
                                let test = boolean(self.expr(*e, env, roots)?)?;
                                let (v, ret) =
                                    self.block(if test { yes } else { no }, env, roots, true)?;
                                if ret {
                                    return Ok((v, true));
                                }
                                release(roots, v, &mut self.evidence)?;
                            }
                            Statement::SMatch(e, arms) => {
                                if let Some(operation) =
                                    self.memory.and_then(|m| m.operations.get(e)).cloned()
                                {
                                    if matches!(
                                        operation,
                                        crate::cgx2_runtime::ordinary_memory::MemoryOpV1::RegionEntry { .. }
                                            | crate::cgx2_runtime::ordinary_memory::MemoryOpV1::GuardEntry { .. }
                                            | crate::cgx2_runtime::ordinary_memory::MemoryOpV1::SessionEntry
                                    ) {
                                        let (value, returned) =
                                            self.memory_match(*e, &operation, arms, env, roots)?;
                                        if returned {
                                            return Ok((value, true));
                                        }
                                        tail = value;
                                        continue;
                                    }
                                }
                                let v = self.expr(*e, env, roots)?;
                                let mut transferred = false;
                                let branch = (|| {
                                    let (case, children) = self.parts(v, roots)?;
                                    let arm = arms
                                        .iter()
                                        .find(|a| a.case.is_none_or(|c| c == case))
                                        .ok_or_else(|| invariant("nonexhaustive runtime match"))?;
                                    // An inline carrier owns exactly its payload's
                                    // registration. Heap aggregates still need the
                                    // parent protected while children are rooted.
                                    let inline = v.depth > 0
                                        && arm.bindings.len() == 1
                                        && children.len() == 1
                                        && v.handle().is_some()
                                        && v.handle() == children[0].handle();
                                    env.0.push(HashMap::new());
                                    let branch = (|| {
                                        for (n, child) in arm.bindings.iter().zip(children) {
                                            if !inline {
                                                root(roots, child, &mut self.evidence)?;
                                            }
                                            self.bind(env, roots, *n, child)?;
                                            transferred = inline;
                                        }
                                        self.block(&arm.body, env, roots, false)
                                    })();
                                    let popped = env.pop(roots, &mut self.evidence);
                                    match branch {
                                        Err(error) => Err(error),
                                        Ok(value) => {
                                            popped?;
                                            Ok(value)
                                        }
                                    }
                                })();
                                let released = if transferred {
                                    Ok(()) // The binding's env.pop owns this release.
                                } else {
                                    release(roots, v, &mut self.evidence)
                                };
                                let (v, ret) = branch?;
                                released?;
                                if ret {
                                    return Ok((v, true));
                                }
                                tail = v;
                            }
                            Statement::SFor(n, e, body) => {
                                let xs = self.expr(*e, env, roots)?;
                                let values = self.parts(xs, roots)?.1;
                                let result: Fallible<Option<Value>> = (|| {
                                    for v in values {
                                        env.0.push(HashMap::new());
                                        root(roots, v, &mut self.evidence)?;
                                        self.bind(env, roots, *n, v)?;
                                        let branch = self.block(body, env, roots, false);
                                        let popped = env.pop(roots, &mut self.evidence);
                                        let (v, ret) = branch?;
                                        popped?;
                                        if ret {
                                            return Ok(Some(v));
                                        }
                                        release(roots, v, &mut self.evidence)?;
                                    }
                                    Ok(None)
                                })(
                                );
                                release(roots, xs, &mut self.evidence)?;
                                if let Some(v) = result? {
                                    return Ok((v, true));
                                }
                            }
                            Statement::SRange(n, start, end, body) => {
                                let a = integer(self.expr(*start, env, roots)?)?;
                                let b = integer(self.expr(*end, env, roots)?)?;
                                for i in a..b {
                                    self.step(Loc::default())?;
                                    env.0.push(HashMap::new());
                                    self.bind(env, roots, *n, self.int(i))?;
                                    let branch = self.block(body, env, roots, false);
                                    let popped = env.pop(roots, &mut self.evidence);
                                    let (v, ret) = branch?;
                                    popped?;
                                    if ret {
                                        return Ok((v, true));
                                    }
                                    release(roots, v, &mut self.evidence)?;
                                }
                            }
                            Statement::SGuard(budget, loc, body) => {
                                let result = roots.with_no_gc(*budget, |r| {
                                    self.evidence.guard_entries += 1;
                                    let out = self.block(body, env, r, true);
                                    self.evidence.guard_exits += 1;
                                    out
                                });
                                match result {
                                    Err(e) => {
                                        self.evidence.guard_entry_failures += 1;
                                        return Err(primary(
                                            "CGR090",
                                            format!("no_gc guard entry failed: {e:?}"),
                                            *loc,
                                        ));
                                    }
                                    Ok(r) => {
                                        let (v, ret) = r?;
                                        if ret {
                                            return Ok((v, true));
                                        }
                                        release(roots, v, &mut self.evidence)?;
                                    }
                                }
                            }
                        }
                    }
                    Ok((tail, false))
                })();
                // Returned handles remain protected by existing registrations until this
                // nonallocating cleanup finishes; callers root before their next safepoint.
                // A successful block transfers its tail registration to its
                // caller. The caller either keeps it or releases it immediately.
                // Function-level finish handles both error and unwind cleanup.
                let popped = if nested {
                    env.pop(roots, &mut self.evidence)
                } else {
                    Ok(())
                };
                match result {
                    Err(e) => Err(e),
                    Ok(v) => {
                        popped?;
                        Ok(v)
                    }
                }
            }
            fn expr(
                &mut self,
                id: usize,
                env: &Env,
                roots: &mut ScopedRoots<'_>,
            ) -> Fallible<Value> {
                let e = self
                    .p
                    .expressions
                    .get(id)
                    .ok_or_else(|| invariant("expression index"))?;
                self.step(e.loc)?;
                let checkpoint = roots.checkpoint();
                let operation = self.memory.and_then(|m| m.operations.get(&id)).cloned();
                let evaluated = if let Some(operation) = &operation {
                    self.memory_expr(e, operation, env, roots)
                } else {
                    self.expr_inner(e, env, roots)
                };
                let mut result = evaluated.and_then(|v| {
                    if let Some(h) = v.handle() {
                        if !roots.contains_since(checkpoint, h) {
                            root(roots, v, &mut self.evidence)?;
                        }
                    }
                    Ok(v)
                });
                if matches!(
                    operation,
                    Some(crate::cgx2_runtime::ordinary_memory::MemoryOpV1::CopyTo { .. })
                ) {
                    if let Err(Fault::AllocationAt(error, _, _)) = result {
                        self.evidence.recovered += 1;
                        result = self.memory_error_value(e.ty, error);
                    }
                } else if matches!(e.op, Op::ETry(_)) {
                    if let Err(Fault::AllocationAt(error, _, _)) = result {
                        self.evidence.recovered += 1;
                        let error_ty = match &self.p.layouts[e.ty].shape {
                            Shape::KVariant(v) => v[1].1[0],
                            _ => return Err(invariant("recovery layout")),
                        };
                        result = Value::new(error_ty, Atom::Error(error_code(error))).wrap(e.ty, 1);
                    }
                }
                let retained = result.as_ref().ok().and_then(|v| v.handle());
                let report = roots.finish_since(checkpoint, retained);
                cleanup(&mut self.evidence, report);
                if result.is_ok() {
                    self.step(e.loc)?;
                }
                result.map_err(|f| match f {
                    Fault::Primary(mut d) => {
                        if d.loc == Loc::default() {
                            d.loc = e.loc;
                        }
                        Fault::Primary(d)
                    }
                    Fault::AllocationAt(error, at, function) => Fault::AllocationAt(
                        error,
                        if at == Loc::default() { e.loc } else { at },
                        function,
                    ),
                })
            }
            fn child(
                &mut self,
                id: usize,
                env: &Env,
                roots: &mut ScopedRoots<'_>,
            ) -> Fallible<Value> {
                self.expr(id, env, roots)
            }
            fn children(
                &mut self,
                ids: &[usize],
                env: &Env,
                roots: &mut ScopedRoots<'_>,
            ) -> Fallible<Vec<Value>> {
                let mut out = Vec::new();
                reserve(&mut out, ids.len())?;
                for id in ids {
                    out.push(self.child(*id, env, roots)?);
                }
                Ok(out)
            }
            fn expr_inner(
                &mut self,
                e: &Expression,
                env: &Env,
                roots: &mut ScopedRoots<'_>,
            ) -> Fallible<Value> {
                match &e.op {
                    Op::EInt(n) => Ok(Value::new(e.ty, Atom::Int(*n))),
                    Op::EBool(v) => Ok(Value::new(e.ty, Atom::Bool(*v))),
                    Op::EUnit => Ok(self.unit()),
                    Op::EString(n) => self.string(e.ty, &self.p.strings[*n], roots),
                    Op::ELocal(n) => env.get(*n),
                    Op::EField(value, index) => {
                        let v = self.child(*value, env, roots)?;
                        self.parts(v, roots)?
                            .1
                            .get(*index)
                            .copied()
                            .ok_or_else(|| invariant("field index"))
                    }
                    Op::EBinary(a, op, b) => {
                        let a = self.child(*a, env, roots)?;
                        let b = self.child(*b, env, roots)?;
                        self.binary(a, b, *op, e.loc, roots)
                    }
                    Op::ERecord(fields) => {
                        let mut values = vec![self.unit(); fields.len()];
                        for (index, id) in fields {
                            let v = self.child(*id, env, roots)?;
                            *values
                                .get_mut(*index)
                                .ok_or_else(|| invariant("record field ordering"))? = v;
                        }
                        self.construct(e.ty, 0, &values, roots)
                    }
                    Op::ECall(f, args) => {
                        let args = self.children(args, env, roots)?;
                        self.call(*f, args, roots)
                    }
                    Op::EConstruct(case, args) => {
                        let args = self.children(args, env, roots)?;
                        self.construct(e.ty, *case, &args, roots)
                    }
                    Op::EData(op, args) => {
                        let loc = if *op == 11 {
                            args.first().map_or(e.loc, |id| self.p.expressions[*id].loc)
                        } else {
                            e.loc
                        };
                        let args = self.children(args, env, roots)?;
                        let previous = self.allocation_region;
                        if (1..=9).contains(op) {
                            if let Some(region) =
                                args.first().and_then(|v| v.handle()).map(|h| h.region())
                            {
                                self.allocation_region = Some(region);
                            }
                        }
                        let result = self.data(*op, e.ty, args, roots, loc);
                        self.allocation_region = previous;
                        result
                    }
                    Op::ETry(inner) => {
                        let result = self.child(*inner, env, roots);
                        match result {
                            Ok(v) => v.wrap(e.ty, 0),
                            Err(Fault::AllocationAt(error, _, _)) => {
                                self.evidence.recovered += 1;
                                let error_ty = match &self.p.layouts[e.ty].shape {
                                    Shape::KVariant(v) => v[1].1[0],
                                    _ => return Err(invariant("recovery Result layout")),
                                };
                                Value::new(error_ty, Atom::Error(error_code(error))).wrap(e.ty, 1)
                            }
                            Err(e) => Err(e),
                        }
                    }
                    Op::ERef(inner) => {
                        let v = self.child(*inner, env, roots)?;
                        self.construct(e.ty, 0, &[v], roots)
                    }
                    Op::EGet(inner) => {
                        let v = self.child(*inner, env, roots)?;
                        self.parts(v, roots)?
                            .1
                            .first()
                            .copied()
                            .ok_or_else(|| invariant("cell payload"))
                    }
                    Op::ESet(reference, value) => {
                        let r = self.child(*reference, env, roots)?;
                        let v = self.child(*value, env, roots)?;
                        let Shape::KRef(target) = self.p.layouts[r.ty].shape else {
                            return Err(invariant("cell layout"));
                        };
                        if v.ty != target {
                            return Err(invariant("cell payload type"));
                        }
                        let h = r.handle().ok_or_else(|| invariant("cell handle"))?;
                        let mut seen = HashSet::new();
                        seen.insert(h);
                        let mut count = 1;
                        self.count(v, roots, &mut seen, &mut count, 0)?;
                        self.work(count.saturating_sub(1), e.loc)?;
                        let (mut bytes, refs) = self.encode(r.ty, 0, &[v])?;
                        let shape = roots.graph_shape(h)?;
                        if shape.payload_bytes != bytes.len() || shape.references != refs.len() {
                            return Err(invariant("cell encoding changed shape"));
                        }
                        for (i, h2) in refs.into_iter().enumerate() {
                            roots.set_graph_reference(h, i, h2)?;
                        }
                        roots.write_graph_bytes(h, 0, &bytes)?;
                        bytes.clear();
                        self.evidence.graph_writes += 1;
                        Ok(self.unit())
                    }
                    Op::ECollect => {
                        let region = self
                            .allocation_region
                            .unwrap_or_else(|| roots.default_region());
                        roots.collect(region)?;
                        Ok(self.unit())
                    }
                }
            }
            fn encode(
                &self,
                ty: usize,
                case: usize,
                values: &[Value],
            ) -> Fallible<(Vec<u8>, Vec<Option<Handle>>)> {
                if values.len() > ELEMENTS {
                    return Err(Fault::allocation(AllocationError::ShapeLimit));
                }
                let mut bytes = Vec::new();
                reserve(&mut bytes, 12 + values.len().saturating_mul(18))?;
                bytes.extend_from_slice(&(ty as u32).to_le_bytes());
                bytes.extend_from_slice(&(case as u32).to_le_bytes());
                bytes.extend_from_slice(&(values.len() as u32).to_le_bytes());
                let mut refs = Vec::new();
                reserve(&mut refs, values.len())?;
                for v in values {
                    bytes.extend_from_slice(&(v.ty as u32).to_le_bytes());
                    bytes.push(v.depth as u8);
                    for c in &v.carriers[..v.depth] {
                        bytes.extend_from_slice(&(c.ty as u32).to_le_bytes());
                        bytes.extend_from_slice(&(c.case as u32).to_le_bytes());
                    }
                    match v.atom {
                        Atom::Int(n) => {
                            bytes.push(0);
                            bytes.extend_from_slice(&n.to_le_bytes());
                        }
                        Atom::Bool(b) => {
                            bytes.push(1);
                            bytes.push(u8::from(b));
                        }
                        Atom::Unit => bytes.push(2),
                        Atom::Heap(_) => bytes.push(3),
                        Atom::Region(_) => {
                            return Err(invariant("region capability stored in a graph"))
                        }
                        Atom::Error(n) => {
                            bytes.push(4);
                            bytes.push(n);
                        }
                    }
                    refs.push(v.handle());
                }
                // A recoverable Result may be either an intrinsic carrier or an
                // ordinary variant handle. Cells reserve the maximum carrier
                // encoding so replacing either representation never reallocates.
                if let Shape::KRef(target) = self.p.layouts[ty].shape {
                    if matches!(&self.p.layouts[target].shape,Shape::KVariant(cases) if cases.len()==2 && cases[1].1.len()==1 && self.p.layouts[cases[1].1[0]].shape==Shape::KError)
                    {
                        let padded = 12 + 4 + 1 + WRAPPERS * 8 + 1 + 8;
                        if bytes.len() < padded {
                            let extra = padded - bytes.len();
                            reserve(&mut bytes, extra)?;
                            bytes.resize(padded, 0);
                        }
                    }
                }
                if bytes.len() > BYTES {
                    return Err(Fault::allocation(AllocationError::ShapeLimit));
                }
                Ok((bytes, refs))
            }
            fn construct(
                &mut self,
                ty: usize,
                case: usize,
                values: &[Value],
                s: &mut Session,
            ) -> Fallible<Value> {
                match &self.p.layouts[ty].shape {
                    Shape::KRecord(fs) => {
                        if fs.len() != values.len()
                            || fs.iter().zip(values).any(|((_, t), v)| *t != v.ty)
                        {
                            return Err(invariant("record type/layout mismatch"));
                        }
                    }
                    Shape::KVariant(cases) => {
                        let fs = &cases.get(case).ok_or_else(|| invariant("variant case"))?.1;
                        if fs.len() != values.len()
                            || fs.iter().zip(values).any(|(t, v)| *t != v.ty)
                        {
                            return Err(invariant("variant type/layout mismatch"));
                        }
                    }
                    Shape::KList(t) | Shape::KArray(t) => {
                        if values.iter().any(|v| v.ty != *t) {
                            return Err(invariant("collection type mismatch"));
                        }
                    }
                    Shape::KRef(t) => {
                        if values.len() != 1 || values[0].ty != *t {
                            return Err(invariant("reference target type mismatch"));
                        }
                    }
                    _ => return Err(invariant("nonaggregate construction")),
                }
                let mut visited = HashSet::new();
                let mut count = 1;
                for v in values {
                    self.count(*v, s, &mut visited, &mut count, 0)?;
                }
                self.work(count.saturating_sub(1), Loc::default())?;
                let (bytes, refs) = self.encode(ty, case, values)?;
                let h = s.alloc_graph(
                    self.allocation_region.unwrap_or_else(|| s.default_region()),
                    &bytes,
                    &refs,
                )?;
                self.evidence.allocations += 1;
                self.evidence.graph_writes += 1;
                Ok(Value::new(ty, Atom::Heap(h)))
            }
            fn string(&mut self, ty: usize, text: &str, s: &mut Session) -> Fallible<Value> {
                if text.len() > BYTES {
                    return Err(Fault::allocation(AllocationError::ShapeLimit));
                }
                let h = s.alloc_graph(
                    self.allocation_region.unwrap_or_else(|| s.default_region()),
                    text.as_bytes(),
                    &[],
                )?;
                self.evidence.allocations += 1;
                self.evidence.graph_writes += 1;
                Ok(Value::new(ty, Atom::Heap(h)))
            }
            fn text(&mut self, v: Value, s: &Session) -> Fallible<String> {
                if v.depth != 0 || self.p.layouts[v.ty].shape != Shape::KString {
                    return Err(invariant("string type"));
                }
                let h = v.handle().ok_or_else(|| invariant("string handle"))?;
                let shape = s.graph_shape(h)?;
                if shape.payload_bytes > BYTES || shape.references != 0 {
                    return Err(invariant("string graph layout"));
                }
                let mut bytes = Vec::new();
                reserve(&mut bytes, shape.payload_bytes)?;
                bytes.resize(shape.payload_bytes, 0);
                s.read_graph_bytes(h, 0, &mut bytes)?;
                self.evidence.graph_reads += 1;
                String::from_utf8(bytes).map_err(|_| invariant("invalid stored UTF-8"))
            }
            fn parts(&mut self, v: Value, s: &Session) -> Fallible<(usize, Vec<Value>)> {
                if v.depth > 0 {
                    let (c, p) = v.unwrap();
                    return Ok((c, vec![p]));
                }
                if let Atom::Error(c) = v.atom {
                    return Ok((c as usize, vec![]));
                }
                let h = v.handle().ok_or_else(|| invariant("aggregate handle"))?;
                let shape = s.graph_shape(h)?;
                if shape.payload_bytes > BYTES || shape.references > ELEMENTS {
                    return Err(invariant("aggregate graph envelope"));
                }
                let mut bytes = Vec::new();
                reserve(&mut bytes, shape.payload_bytes)?;
                bytes.resize(shape.payload_bytes, 0);
                s.read_graph_bytes(h, 0, &mut bytes)?;
                self.evidence.graph_reads += 1;
                let mut cursor = 0;
                fn byte(bytes: &[u8], at: &mut usize) -> Fallible<u8> {
                    let b = *bytes
                        .get(*at)
                        .ok_or_else(|| invariant("truncated graph payload"))?;
                    *at += 1;
                    Ok(b)
                }
                fn word(bytes: &[u8], at: &mut usize) -> Fallible<usize> {
                    let end = at
                        .checked_add(4)
                        .ok_or_else(|| invariant("payload overflow"))?;
                    let b = bytes
                        .get(*at..end)
                        .ok_or_else(|| invariant("truncated graph word"))?;
                    *at = end;
                    Ok(
                        u32::from_le_bytes(b.try_into().map_err(|_| invariant("graph word"))?)
                            as usize,
                    )
                }
                if word(&bytes, &mut cursor)? != v.ty {
                    return Err(invariant("stored type identity mismatch"));
                }
                let case = word(&bytes, &mut cursor)?;
                let n = word(&bytes, &mut cursor)?;
                if n != shape.references {
                    return Err(invariant("stored child count"));
                }
                let mut out = Vec::new();
                reserve(&mut out, n)?;
                for i in 0..n {
                    let ty = word(&bytes, &mut cursor)?;
                    if ty >= self.p.layouts.len() {
                        return Err(invariant("stored child type"));
                    }
                    let depth = byte(&bytes, &mut cursor)? as usize;
                    if depth > WRAPPERS {
                        return Err(invariant("carrier depth"));
                    }
                    let mut carriers = [Carrier::default(); WRAPPERS];
                    for c in &mut carriers[..depth] {
                        c.ty = word(&bytes, &mut cursor)?;
                        c.case = word(&bytes, &mut cursor)?;
                    }
                    let atom = match byte(&bytes, &mut cursor)? {
                        0 => {
                            let end = cursor
                                .checked_add(8)
                                .ok_or_else(|| invariant("integer payload overflow"))?;
                            let b = bytes
                                .get(cursor..end)
                                .ok_or_else(|| invariant("integer payload"))?;
                            cursor = end;
                            Atom::Int(i64::from_le_bytes(
                                b.try_into().map_err(|_| invariant("integer bytes"))?,
                            ))
                        }
                        1 => {
                            let b = byte(&bytes, &mut cursor)?;
                            if b > 1 {
                                return Err(invariant("Boolean encoding"));
                            }
                            Atom::Bool(b == 1)
                        }
                        2 => Atom::Unit,
                        3 => Atom::Heap(
                            s.graph_reference(h, i)?
                                .ok_or_else(|| invariant("missing traced child"))?,
                        ),
                        4 => Atom::Error(byte(&bytes, &mut cursor)?),
                        _ => return Err(invariant("unknown payload tag")),
                    };
                    out.push(Value {
                        ty,
                        atom,
                        carriers,
                        depth,
                    });
                }
                if cursor != bytes.len()
                    && !(matches!(self.p.layouts[v.ty].shape, Shape::KRef(_))
                        && bytes[cursor..].iter().all(|b| *b == 0))
                {
                    return Err(invariant("trailing payload bytes"));
                }
                Ok((case, out))
            }
            fn count(
                &mut self,
                v: Value,
                s: &Session,
                seen: &mut HashSet<Handle>,
                count: &mut usize,
                _depth: usize,
            ) -> Fallible<()> {
                fn enqueue(
                    mut value: Value,
                    queue: &mut Vec<Value>,
                    seen: &mut HashSet<Handle>,
                    count: &mut usize,
                ) -> Fallible<()> {
                    *count = count
                        .checked_add(value.depth)
                        .ok_or(Fault::allocation(AllocationError::ShapeLimit))?;
                    while value.depth > 0 {
                        value = value.unwrap().1;
                    }
                    let fresh = if let Some(h) = value.handle() {
                        if seen.contains(&h) {
                            false
                        } else {
                            seen.try_reserve(1)
                                .map_err(|_| Fault::allocation(AllocationError::HostAllocation))?;
                            seen.insert(h);
                            true
                        }
                    } else {
                        true
                    };
                    if fresh {
                        *count = count
                            .checked_add(1)
                            .ok_or(Fault::allocation(AllocationError::ShapeLimit))?;
                    }
                    if *count > NODES {
                        return Err(Fault::allocation(AllocationError::ShapeLimit));
                    }
                    if fresh && value.handle().is_some() {
                        queue
                            .try_reserve(1)
                            .map_err(|_| Fault::allocation(AllocationError::HostAllocation))?;
                        queue.push(value);
                    }
                    Ok(())
                }
                let mut queue = Vec::new();
                enqueue(v, &mut queue, seen, count)?;
                while let Some(value) = queue.pop() {
                    if self.p.layouts[value.ty].shape != Shape::KString {
                        for child in self.parts(value, s)?.1 {
                            enqueue(child, &mut queue, seen, count)?;
                        }
                    }
                }
                Ok(())
            }
            fn snapshot(
                &mut self,
                v: Value,
                s: &Session,
                count: &mut usize,
                depth: usize,
            ) -> Fallible<Snapshot> {
                let mut bytes = 0;
                self.snapshot_bounded(v, s, count, &mut bytes, depth)
            }
            fn snapshot_bounded(
                &mut self,
                v: Value,
                s: &Session,
                count: &mut usize,
                bytes: &mut usize,
                depth: usize,
            ) -> Fallible<Snapshot> {
                self.step(Loc::default())?;
                *count += 1;
                if *count > NODES || depth >= 64 {
                    return Err(primary(
                        "CGR010",
                        "materialized value bound exceeded",
                        Loc::default(),
                    ));
                }
                if v.depth > 0 {
                    let name = self.p.strings[self.p.layouts[v.ty].name].clone();
                    let Shape::KVariant(cases) = &self.p.layouts[v.ty].shape else {
                        return Err(invariant("carrier layout"));
                    };
                    let (c, p) = v.unwrap();
                    let case = self.p.strings[cases[c].0].clone();
                    display_charge(bytes, name.len() + case.len() + 3)?;
                    return Ok(Snapshot::Variant(
                        name,
                        case,
                        vec![self.snapshot_bounded(p, s, count, bytes, depth + 1)?],
                    ));
                }
                match v.atom {
                    Atom::Int(n) => {
                        display_charge(bytes, n.to_string().len())?;
                        Ok(Snapshot::Integer(n))
                    }
                    Atom::Bool(b) => {
                        display_charge(bytes, if b { 4 } else { 5 })?;
                        Ok(Snapshot::Boolean(b))
                    }
                    Atom::Unit => Ok(Snapshot::Unit),
                    Atom::Region(_) => Err(invariant("region capability escaped in a snapshot")),
                    Atom::Error(c) => {
                        display_charge(bytes, 23 + ERRORS[c as usize].len() + 3)?;
                        Ok(Snapshot::Variant(
                            "cgx2.core.AllocationError".into(),
                            ERRORS[c as usize].into(),
                            vec![],
                        ))
                    }
                    Atom::Heap(_) => match &self.p.layouts[v.ty].shape {
                        Shape::KString => {
                            display_charge(
                                bytes,
                                s.graph_shape(
                                    v.handle().ok_or_else(|| invariant("string handle"))?,
                                )?
                                .payload_bytes,
                            )?;
                            Ok(Snapshot::Text(self.text(v, s)?))
                        }
                        Shape::KRef(_) => Err(primary(
                            "CGR091",
                            "reference-bearing public snapshot is unsupported",
                            Loc::default(),
                        )),
                        Shape::KRecord(fields) => {
                            let name = self.p.strings[self.p.layouts[v.ty].name].clone();
                            let values = self.parts(v, s)?.1;
                            display_charge(
                                bytes,
                                name.len()
                                    + 2
                                    + values.len().saturating_sub(1) * 2
                                    + fields
                                        .iter()
                                        .map(|(n, _)| self.p.strings[*n].len() + 2)
                                        .sum::<usize>(),
                            )?;
                            let mut out = Vec::new();
                            reserve(&mut out, values.len())?;
                            for ((n, _), v) in fields.iter().zip(values) {
                                out.push((
                                    self.p.strings[*n].clone(),
                                    self.snapshot_bounded(v, s, count, bytes, depth + 1)?,
                                ));
                            }
                            Ok(Snapshot::Record(name, out))
                        }
                        Shape::KVariant(cases) => {
                            let name = self.p.strings[self.p.layouts[v.ty].name].clone();
                            let (c, values) = self.parts(v, s)?;
                            let case = self.p.strings[cases[c].0].clone();
                            display_charge(
                                bytes,
                                name.len() + case.len() + 3 + values.len().saturating_sub(1) * 2,
                            )?;
                            let mut out = Vec::new();
                            reserve(&mut out, values.len())?;
                            for v in values {
                                out.push(self.snapshot_bounded(v, s, count, bytes, depth + 1)?);
                            }
                            Ok(Snapshot::Variant(name, case, out))
                        }
                        Shape::KList(_) | Shape::KArray(_) => {
                            let array = matches!(self.p.layouts[v.ty].shape, Shape::KArray(_));
                            let values = self.parts(v, s)?.1;
                            display_charge(
                                bytes,
                                2 + if array { 5 } else { 0 } + values.len().saturating_sub(1) * 2,
                            )?;
                            let mut out = Vec::new();
                            reserve(&mut out, values.len())?;
                            for v in values {
                                out.push(self.snapshot_bounded(v, s, count, bytes, depth + 1)?);
                            }
                            Ok(Snapshot::Sequence(array, out))
                        }
                        _ => Err(invariant("heap scalar layout")),
                    },
                }
            }
            fn equal(
                &mut self,
                a: Value,
                b: Value,
                s: &Session,
                seen: &mut HashSet<(Handle, Handle)>,
                nodes: &mut usize,
                depth: usize,
            ) -> Fallible<bool> {
                self.step(Loc::default())?;
                if a.ty != b.ty {
                    return Ok(false);
                }
                *nodes += 1;
                if *nodes > NODES || depth >= 64 {
                    return Err(primary(
                        "CGR010",
                        "equality work bound exceeded",
                        Loc::default(),
                    ));
                }
                // Carrier depth describes storage, not the logical variant value.
                // Only unwrapped heap nodes may use handle identity/cycle shortcuts:
                // a carrier's handle belongs to its payload, not its outer case.
                match (a.depth, b.depth, a.atom, b.atom) {
                    (0, 0, Atom::Heap(x), Atom::Heap(y)) => {
                        if x == y || seen.contains(&(x, y)) {
                            return Ok(true);
                        }
                        seen.try_reserve(1)
                            .map_err(|_| Fault::allocation(AllocationError::HostAllocation))?;
                        seen.insert((x, y));
                        if self.p.layouts[a.ty].shape == Shape::KString {
                            return Ok(self.text(a, s)? == self.text(b, s)?);
                        }
                    }
                    (0, 0, a, b) => return Ok(a == b),
                    _ => {}
                }
                // Decode a single logical layer from either representation without
                // constructing a managed variant or changing roots/guard charges.
                let (c, aa) = self.parts(a, s)?;
                let (d, bb) = self.parts(b, s)?;
                if c != d || aa.len() != bb.len() {
                    return Ok(false);
                }
                for (a, b) in aa.into_iter().zip(bb) {
                    if !self.equal(a, b, s, seen, nodes, depth + 1)? {
                        return Ok(false);
                    }
                }
                Ok(true)
            }
            fn binary(
                &mut self,
                a: Value,
                b: Value,
                op: usize,
                loc: Loc,
                s: &Session,
            ) -> Fallible<Value> {
                if (1..=4).contains(&op) {
                    let a = integer(a)?;
                    let b = integer(b)?;
                    if op == 4 && b == 0 {
                        return Err(primary("CGR006", "division by zero", loc));
                    }
                    let n = match op {
                        1 => a.checked_add(b),
                        2 => a.checked_sub(b),
                        3 => a.checked_mul(b),
                        _ => a.checked_div(b),
                    }
                    .ok_or_else(|| primary("CGR005", "i64 arithmetic overflow", loc))?;
                    return Ok(self.int(n));
                }
                let boolean_ty = self
                    .p
                    .layouts
                    .iter()
                    .position(|t| t.shape == Shape::KBool)
                    .ok_or_else(|| invariant("Bool layout"))?;
                let result = match op {
                    5 | 6 => {
                        let mut n = 0;
                        let same = self.equal(a, b, s, &mut HashSet::new(), &mut n, 0)?;
                        if op == 5 {
                            same
                        } else {
                            !same
                        }
                    }
                    7 => integer(a)? < integer(b)?,
                    8 => integer(a)? <= integer(b)?,
                    9 => integer(a)? > integer(b)?,
                    10 => integer(a)? >= integer(b)?,
                    _ => return Err(invariant("binary opcode")),
                };
                Ok(Value::new(boolean_ty, Atom::Bool(result)))
            }
            fn option(&mut self, ty: usize, v: Option<Value>, s: &mut Session) -> Fallible<Value> {
                match v {
                    Some(v) => self.construct(ty, 0, &[v], s),
                    None => self.construct(ty, 1, &[], s),
                }
            }
            fn data(
                &mut self,
                op: usize,
                ty: usize,
                vs: Vec<Value>,
                s: &mut Session,
                loc: Loc,
            ) -> Fallible<Value> {
                match op {
                    0 => {
                        let n = if self.p.layouts[vs[0].ty].shape == Shape::KString {
                            self.text(vs[0], s)?.chars().count()
                        } else {
                            self.parts(vs[0], s)?.1.len()
                        };
                        Ok(self.int(n as i64))
                    }
                    1 => {
                        let index = integer(vs[1])?;
                        let value = if self.p.layouts[vs[0].ty].shape == Shape::KString {
                            let text = self.text(vs[0], s)?;
                            if let Some(c) = usize::try_from(index)
                                .ok()
                                .and_then(|i| text.chars().nth(i))
                            {
                                let string_ty = vs[0].ty;
                                Some(self.string(string_ty, &c.to_string(), s)?)
                            } else {
                                None
                            }
                        } else {
                            let values = self.parts(vs[0], s)?.1;
                            usize::try_from(index)
                                .ok()
                                .and_then(|i| values.get(i).copied())
                        };
                        if let Some(v) = value {
                            let mut r = s.scoped_roots();
                            root(&mut r, v, &mut self.evidence)?;
                            let out = self.option(ty, Some(v), &mut r);
                            let o = r.finish(out);
                            cleanup(&mut self.evidence, o.cleanup);
                            o.result
                        } else {
                            self.option(ty, None, s)
                        }
                    }
                    2 => {
                        let mut values = self.parts(vs[0], s)?.1;
                        let index = integer(vs[1])?;
                        if let Some(slot) =
                            usize::try_from(index).ok().and_then(|i| values.get_mut(i))
                        {
                            *slot = vs[2];
                            let updated = self.construct(vs[0].ty, 0, &values, s)?;
                            let mut r = s.scoped_roots();
                            root(&mut r, updated, &mut self.evidence)?;
                            let result = self.option(ty, Some(updated), &mut r);
                            let out = r.finish(result);
                            cleanup(&mut self.evidence, out.cleanup);
                            out.result
                        } else {
                            self.option(ty, None, s)
                        }
                    }
                    3 => {
                        let mut values = self.parts(vs[0], s)?.1;
                        reserve(&mut values, 1)?;
                        values.push(vs[1]);
                        self.construct(ty, 0, &values, s)
                    }
                    4 | 5 => {
                        let values = self.parts(vs[0], s)?.1;
                        self.construct(ty, 0, &values, s)
                    }
                    6 => {
                        let mut a = self.text(vs[0], s)?;
                        let b = self.text(vs[1], s)?;
                        let len = a
                            .len()
                            .checked_add(b.len())
                            .ok_or(Fault::allocation(AllocationError::ShapeLimit))?;
                        if len > BYTES {
                            return Err(Fault::allocation(AllocationError::ShapeLimit));
                        }
                        a.try_reserve_exact(b.len())
                            .map_err(|_| Fault::allocation(AllocationError::HostAllocation))?;
                        a.push_str(&b);
                        self.string(ty, &a, s)
                    }
                    7 => {
                        let text = self.text(vs[0], s)?;
                        let a = integer(vs[1])?;
                        let b = integer(vs[2])?;
                        if a < 0 || b < a || b as usize > text.chars().count() {
                            return self.option(ty, None, s);
                        }
                        let result = text
                            .chars()
                            .skip(a as usize)
                            .take((b - a) as usize)
                            .collect::<String>();
                        let v = self.string(vs[0].ty, &result, s)?;
                        let mut r = s.scoped_roots();
                        root(&mut r, v, &mut self.evidence)?;
                        let result = self.option(ty, Some(v), &mut r);
                        let out = r.finish(result);
                        cleanup(&mut self.evidence, out.cleanup);
                        out.result
                    }
                    8 => {
                        let text = self.text(vs[0], s)?;
                        let digits = text
                            .strip_prefix('-')
                            .or_else(|| text.strip_prefix('+'))
                            .unwrap_or(&text);
                        let parsed =
                            if !digits.is_empty() && digits.bytes().all(|b| b.is_ascii_digit()) {
                                text.parse::<i64>().ok()
                            } else {
                                None
                            };
                        if let Some(n) = parsed {
                            self.construct(ty, 0, &[self.int(n)], s)
                        } else {
                            let error_ty = match &self.p.layouts[ty].shape {
                                Shape::KVariant(c) => c[1].1[0],
                                _ => return Err(invariant("parse Result")),
                            };
                            let v = self.string(error_ty, "invalid integer", s)?;
                            let mut r = s.scoped_roots();
                            root(&mut r, v, &mut self.evidence)?;
                            let result = self.construct(ty, 1, &[v], &mut r);
                            let out = r.finish(result);
                            cleanup(&mut self.evidence, out.cleanup);
                            out.result
                        }
                    }
                    9 => {
                        let mut count = 0;
                        let shown = self.snapshot(vs[0], s, &mut count, 0)?.to_string();
                        if shown.len() > BYTES {
                            return Err(primary("CGR010", "output exceeds 1048576 bytes", loc));
                        }
                        self.string(ty, &shown, s)
                    }
                    10 => Ok(self.int(self.args.len() as i64)),
                    11 => {
                        let i = integer(vs[0])?;
                        let index = usize::try_from(i)
                            .map_err(|_| primary("CGR007", "arg index must be nonnegative", loc))?;
                        let text = self.args.get(index).ok_or_else(|| {
                            primary("CGR007", format!("arg index {index} is out of range"), loc)
                        })?;
                        self.string(ty, text, s)
                    }
                    _ => Err(invariant("data intrinsic opcode")),
                }
            }
        }
        fn display_charge(bytes: &mut usize, n: usize) -> Fallible<()> {
            *bytes = bytes
                .checked_add(n)
                .ok_or_else(|| primary("CGR010", "output exceeds 1048576 bytes", Loc::default()))?;
            if *bytes > BYTES {
                Err(primary(
                    "CGR010",
                    "output exceeds 1048576 bytes",
                    Loc::default(),
                ))
            } else {
                Ok(())
            }
        }
        const ERRORS: [&str; 5] = [
            "BudgetExceeded",
            "RegionLimit",
            "HostAllocation",
            "InvalidRegion",
            "ShapeLimit",
        ];
        fn error_code(e: AllocationError) -> u8 {
            match e {
                AllocationError::BudgetExceeded => 0,
                AllocationError::RegionLimit => 1,
                AllocationError::HostAllocation => 2,
                AllocationError::InvalidRegion => 3,
                AllocationError::ShapeLimit => 4,
            }
        }
    }
    pub use engine::{
        run, run_function_borrowed, run_with_session, Evidence, Execution, Failure, Snapshot,
    };
}

/// Versioned transactional graph transfers for the ordinary-memory producer.
/// Kept in graph.rs so the frozen standalone runtime inventory stays complete.
pub mod ordinary_memory {
    use super::default_managed::model::Program;
    use super::GraphError;
    use crate::cgx2_runtime::{
        AllocationError, Handle, MemoryError, OwnedBytes, RegionId, ReserveSite, ScopedRoots,
        Session,
    };
    use std::collections::{BTreeMap, HashMap};
    use std::mem::size_of;

    #[derive(Clone, Debug, PartialEq, Eq)]
    pub enum MemoryOpV1 {
        DefaultRegion,
        TryIn {
            region: usize,
            value: usize,
        },
        CopyTo {
            region: usize,
            value: usize,
        },
        Collect {
            region: usize,
        },
        RegionEntry {
            manual: bool,
            arguments: Vec<usize>,
            limit: usize,
            trigger: Option<usize>,
        },
        GuardEntry {
            budget: usize,
        },
        SessionEntry,
    }
    #[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
    pub enum EntryPolicyV1 {
        #[default]
        Implicit,
        Recoverable,
    }
    #[derive(Clone, Debug, PartialEq, Eq)]
    pub struct MemoryProgramV1 {
        pub program: Program,
        pub operations: BTreeMap<usize, MemoryOpV1>,
        pub entry_policy: EntryPolicyV1,
    }
    #[derive(Clone, Debug)]
    pub struct ExecutionV1 {
        pub result: Result<super::default_managed::Snapshot, super::default_managed::Failure>,
        pub evidence: Option<super::default_managed::Evidence>,
        pub memory: Option<crate::cgx2_runtime::MemoryReport>,
    }
    fn entered(execution: super::default_managed::Execution) -> ExecutionV1 {
        ExecutionV1 {
            result: execution.result,
            evidence: Some(execution.evidence),
            memory: Some(execution.memory),
        }
    }
    pub fn run(program: &MemoryProgramV1, args: &[String]) -> ExecutionV1 {
        match Session::try_new() {
            Ok(session) => run_with_session(program, args, session),
            Err(error) => run_with_entry_error_v1(program, error),
        }
    }
    pub fn run_with_session(
        program: &MemoryProgramV1,
        args: &[String],
        session: Session,
    ) -> ExecutionV1 {
        entered(super::default_managed::engine::run_memory_with_session(
            program, args, session,
        ))
    }
    /// Direct pre-Session control for conformance, including identifier exhaustion.
    pub fn run_with_entry_error_v1(
        program: &MemoryProgramV1,
        error: crate::cgx2_runtime::SessionEntryError,
    ) -> ExecutionV1 {
        let execution = super::default_managed::engine::entry_failure(program, error);
        ExecutionV1 {
            result: execution.result,
            evidence: None,
            memory: None,
        }
    }
    #[cfg(feature = "fault-injection")]
    pub fn run_with_host_failure_v1(
        program: &MemoryProgramV1,
        args: &[String],
        index: usize,
    ) -> ExecutionV1 {
        match Session::try_new_with_host_failure_at_reserve(index) {
            Ok(session) => run_with_session(program, args, session),
            Err(error) => run_with_entry_error_v1(program, error),
        }
    }

    const NODES: usize = 65_537;
    const BYTES: usize = 64 << 20;
    const NONE: u32 = u32::MAX;

    /// An independent, accounted graph image. No managed handles or host
    /// pointers are encoded. Only the runtime can construct a valid image.
    #[derive(Debug)]
    pub struct OwnedGraphV1 {
        storage: OwnedBytes,
        nodes: usize,
    }
    impl OwnedGraphV1 {
        pub fn node_count(&self) -> usize {
            self.nodes
        }
        pub fn encoded_bytes(&self) -> &[u8] {
            self.storage.as_slice()
        }
        /// Evidence identity; moves and failed promotions preserve this value.
        pub fn identity_v1(&self) -> usize {
            self.storage.as_slice().as_ptr() as usize
        }
    }
    #[derive(Debug)]
    pub struct PromotionFailureV1 {
        pub error: AllocationError,
        pub owner: OwnedGraphV1,
    }
    #[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
    pub struct MemoryEvidenceV1 {
        pub copied_graphs: usize,
        pub promoted_graphs: usize,
        pub failed_promotions: usize,
        pub rolled_back_nodes: usize,
    }

    fn allocation(error: AllocationError) -> GraphError {
        error.into()
    }
    fn transfer_error(error: GraphError) -> AllocationError {
        match error {
            GraphError::Memory(MemoryError::Allocation(e)) => e,
            GraphError::ShapeLimit => AllocationError::ShapeLimit,
            _ => AllocationError::InvalidRegion,
        }
    }
    /// Allocate replacement metadata before commitment and charge its entire
    /// capacity, including overlap with the old table. This is temporary
    /// traversal metadata; authoritative graph payloads remain OwnedBytes or
    /// actual Session objects.
    fn reserve<T>(s: &mut Session, v: &mut Vec<T>, needed: usize) -> Result<(), GraphError> {
        if needed <= v.capacity() {
            return Ok(());
        }
        let bytes = needed
            .checked_mul(size_of::<T>())
            .ok_or(GraphError::ShapeLimit)?;
        s.check_budgets(bytes)?;
        s.fault
            .before_reserve(ReserveSite::ObjectReferences)
            .map_err(|_| allocation(AllocationError::HostAllocation))?;
        let mut replacement = Vec::new();
        replacement
            .try_reserve_exact(needed)
            .map_err(|_| allocation(AllocationError::HostAllocation))?;
        let charge = replacement
            .capacity()
            .checked_mul(size_of::<T>())
            .ok_or(GraphError::ShapeLimit)?;
        s.check_budgets(charge)?;
        s.charge_budgets(charge);
        replacement.append(v);
        *v = replacement;
        Ok(())
    }
    fn add_handle(
        s: &mut Session,
        nodes: &mut Vec<Handle>,
        indices: &mut HashMap<Handle, u32>,
        h: Handle,
    ) -> Result<(), GraphError> {
        if indices.contains_key(&h) {
            return Ok(());
        }
        if nodes.len() >= NODES {
            return Err(GraphError::ShapeLimit);
        }
        let needed = nodes.len() + 1;
        reserve(s, nodes, needed.next_power_of_two().min(NODES))?;
        if needed > indices.capacity() {
            // Logical hash-table metadata includes a control byte per bucket;
            // allocator internals/RSS are outside the runtime byte contract.
            let count = needed.next_power_of_two().min(NODES);
            let unit = size_of::<(Handle, u32)>() + 1;
            s.check_budgets(count.checked_mul(unit).ok_or(GraphError::ShapeLimit)?)?;
            s.fault
                .before_reserve(ReserveSite::ObjectReferences)
                .map_err(|_| allocation(AllocationError::HostAllocation))?;
            let mut replacement = HashMap::new();
            replacement
                .try_reserve(count)
                .map_err(|_| allocation(AllocationError::HostAllocation))?;
            let charge = replacement
                .capacity()
                .checked_mul(unit)
                .ok_or(GraphError::ShapeLimit)?;
            s.check_budgets(charge)?;
            s.charge_budgets(charge);
            replacement.extend(indices.drain());
            *indices = replacement;
        }
        indices.insert(h, nodes.len() as u32);
        nodes.push(h);
        Ok(())
    }
    fn put(out: &mut [u8], at: &mut usize, n: u32) {
        out[*at..*at + 4].copy_from_slice(&n.to_le_bytes());
        *at += 4;
    }
    fn get(input: &[u8], at: &mut usize) -> Result<u32, GraphError> {
        let end = at.checked_add(4).ok_or(GraphError::ShapeLimit)?;
        let n = u32::from_le_bytes(
            input
                .get(*at..end)
                .ok_or(GraphError::ShapeLimit)?
                .try_into()
                .map_err(|_| GraphError::ShapeLimit)?,
        );
        *at = end;
        Ok(n)
    }
    fn index(indices: &HashMap<Handle, u32>, h: Option<Handle>) -> Result<u32, GraphError> {
        h.map_or(Ok(NONE), |h| {
            indices.get(&h).copied().ok_or(GraphError::ShapeLimit)
        })
    }
    struct Node<'a> {
        bytes: &'a [u8],
        refs: Option<&'a [u8]>,
        edges: &'a [u8],
    }
    fn take<'a>(input: &'a [u8], at: &mut usize, n: usize) -> Result<&'a [u8], GraphError> {
        let end = at.checked_add(n).ok_or(GraphError::ShapeLimit)?;
        let part = input.get(*at..end).ok_or(GraphError::ShapeLimit)?;
        *at = end;
        Ok(part)
    }
    fn node<'a>(input: &'a [u8], at: &mut usize) -> Result<Node<'a>, GraphError> {
        let bytes = get(input, at)? as usize;
        let refs = get(input, at)?;
        let edges = get(input, at)? as usize;
        let bytes = take(input, at, bytes)?;
        let refs = if refs == NONE {
            None
        } else {
            Some(take(
                input,
                at,
                (refs as usize)
                    .checked_mul(4)
                    .ok_or(GraphError::ShapeLimit)?,
            )?)
        };
        let edges = take(
            input,
            at,
            edges.checked_mul(4).ok_or(GraphError::ShapeLimit)?,
        )?;
        Ok(Node { bytes, refs, edges })
    }
    fn target(input: &[u8], handles: &[Handle]) -> Result<Option<Handle>, GraphError> {
        let n = u32::from_le_bytes(input.try_into().map_err(|_| GraphError::ShapeLimit)?);
        if n == NONE {
            Ok(None)
        } else {
            handles
                .get(n as usize)
                .copied()
                .map(Some)
                .ok_or(GraphError::ShapeLimit)
        }
    }
    struct Prepared {
        handles: Vec<Handle>,
    }
    impl Session {
        fn object_v1(&self, handle: Handle) -> Result<&crate::cgx2_runtime::heap::Object, MemoryError> {
            self.read_bytes(handle)?;
            self.region(handle.region())?.slots[handle.slot]
                .object
                .as_ref()
                .ok_or(MemoryError::InvalidHandle)
        }
        fn graph_image_v1(&mut self, source: Handle) -> Result<OwnedGraphV1, GraphError> {
            self.read_bytes(source)?;
            let mut nodes = Vec::new();
            let mut indices = HashMap::new();
            add_handle(self, &mut nodes, &mut indices, source)?;
            let mut cursor = 0;
            let mut length = 0usize;
            let mut work = 0usize;
            while cursor < nodes.len() {
                let h = nodes[cursor];
                let object = self.object_v1(h)?;
                let references = object.references.as_ref().map_or(0, Vec::len);
                length = length
                    .checked_add(12)
                    .and_then(|n| n.checked_add(object.bytes.len()))
                    .and_then(|n| n.checked_add(references.checked_mul(4)?))
                    .and_then(|n| n.checked_add(object.edges.len().checked_mul(4)?))
                    .filter(|n| *n <= BYTES)
                    .ok_or(GraphError::ShapeLimit)?;
                let children = references + object.edges.len();
                for child in 0..children {
                    let object = self.object_v1(h)?;
                    let next = if child < references {
                        object.references.as_ref().and_then(|r| r[child])
                    } else {
                        Some(object.edges[child - references])
                    };
                    work = work
                        .checked_add(1)
                        .filter(|n| *n <= 1_000_000)
                        .ok_or(GraphError::ShapeLimit)?;
                    if let Some(next) = next {
                        if next.region() != source.region() {
                            return Err(MemoryError::CrossRegionEdge.into());
                        }
                        self.read_bytes(next)?;
                        add_handle(self, &mut nodes, &mut indices, next)?;
                    }
                }
                cursor += 1;
            }
            let mut storage = self.alloc_owned_bytes(length)?;
            let out = storage.as_mut_slice();
            let mut at = 0;
            for h in &nodes {
                let object = self.object_v1(*h)?;
                put(out, &mut at, object.bytes.len() as u32);
                put(
                    out,
                    &mut at,
                    object.references.as_ref().map_or(NONE, |r| r.len() as u32),
                );
                put(out, &mut at, object.edges.len() as u32);
                out[at..at + object.bytes.len()].copy_from_slice(&object.bytes);
                at += object.bytes.len();
                if let Some(refs) = &object.references {
                    for h in refs {
                        put(out, &mut at, index(&indices, *h)?);
                    }
                }
                for h in &object.edges {
                    put(out, &mut at, index(&indices, Some(*h))?);
                }
            }
            Ok(OwnedGraphV1 {
                storage,
                nodes: nodes.len(),
            })
        }
        fn discard_prepared_v1(&mut self, handles: &[Handle]) {
            // No reserve, collection or refund. Reverse order also handles a
            // partially linked cycle because every staged handle is private.
            for h in handles.iter().rev() {
                if let Ok(region) = self.region_mut(h.region()) {
                    if let Some(slot) = region.slots.get_mut(h.slot) {
                        if slot.generation == h.generation {
                            if let Some(object) = slot.object.take() {
                                debug_assert_eq!(object.roots, 0);
                                region.stats.live_bytes -= object.charge;
                                region.stats.committed_bytes -= object.charge;
                                slot.generation = slot.generation.saturating_add(1);
                            }
                        }
                    }
                }
            }
        }
        fn prepare_graph_v1(
            &mut self,
            destination: RegionId,
            image: &OwnedGraphV1,
        ) -> Result<Prepared, GraphError> {
            self.mode(destination)?;
            let mut handles = Vec::new();
            reserve(self, &mut handles, image.nodes)?;
            let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                let mut roots = self.scoped_roots();
                let mut at = 0;
                for _ in 0..image.nodes {
                    let n = node(image.encoded_bytes(), &mut at)?;
                    let h = if let Some(refs) = n.refs {
                        roots.alloc_object(destination, n.bytes.len(), refs.len() / 4)?
                    } else {
                        roots.alloc_bytes(destination, n.bytes.len())?
                    };
                    handles.push(h); // before the fallible publication reserve
                    roots.root(h)?;
                    roots.write_bytes(h, 0, n.bytes).map_err(|e| match e {
                        super::PayloadError::Memory(e) => GraphError::Memory(e),
                        _ => GraphError::ShapeLimit,
                    })?;
                }
                if at != image.encoded_bytes().len() {
                    return Err(GraphError::ShapeLimit);
                }
                at = 0;
                for h in &handles {
                    let n = node(image.encoded_bytes(), &mut at)?;
                    if let Some(refs) = n.refs {
                        for (i, r) in refs.as_chunks::<4>().0.iter().enumerate() {
                            roots.set_reference(*h, i, target(r, &handles)?)?;
                        }
                    }
                    for edge in n.edges.as_chunks::<4>().0 {
                        roots.link(*h, target(edge, &handles)?.ok_or(GraphError::ShapeLimit)?)?;
                    }
                }
                Ok(())
            }));
            match result {
                Ok(Ok(())) => Ok(Prepared { handles }),
                Ok(Err(error)) => {
                    self.discard_prepared_v1(&handles);
                    Err(error)
                }
                Err(panic) => {
                    self.discard_prepared_v1(&handles);
                    std::panic::resume_unwind(panic)
                }
            }
        }
    }
    impl ScopedRoots<'_> {
        /// Independent graph snapshot. Source remains rooted at every safepoint.
        /// The source producer additionally rejects Ref-bearing owned topology.
        pub fn copy_owned_graph_v1(&mut self, source: Handle) -> Result<OwnedGraphV1, GraphError> {
            let checkpoint = self.checkpoint();
            self.root(source)?;
            let result = self.graph_image_v1(source);
            let cleanup = self.finish_since(checkpoint, None);
            match (result, cleanup.first_error) {
                (Err(e), _) => Err(e),
                (Ok(_), Some(e)) => Err(e.into()),
                (Ok(value), None) => Ok(value),
            }
        }
        fn publish_graph_v1(
            &mut self,
            destination: RegionId,
            image: &OwnedGraphV1,
        ) -> Result<Handle, GraphError> {
            // Reserve before preparing payload, so root publication cannot
            // allocate after source ownership is irreversibly consumed.
            self.reserve_root_slots_v1(1)?;
            let prepared = self.prepare_graph_v1(destination, image)?;
            let root = prepared.handles[0];
            if let Err(error) = self.root(root) {
                self.discard_prepared_v1(&prepared.handles);
                return Err(error.into());
            }
            Ok(root)
        }
        /// Deep copy preserving raw graph aliases, cycles and checked edges.
        /// The returned root belongs to this lexical scope.
        pub fn copy_graph_to_v1(
            &mut self,
            destination: RegionId,
            source: Handle,
        ) -> Result<Handle, GraphError> {
            let checkpoint = self.checkpoint();
            self.root(source)?;
            // The snapshot owns its bytes but does not keep the input handle
            // alive. Destination allocation can collect the source region too.
            let result = (|| {
                let image = self.graph_image_v1(source)?;
                self.publish_graph_v1(destination, &image)
            })();
            let retained = result.as_ref().ok().copied();
            let cleanup = self.finish_since(checkpoint, retained);
            match (result, cleanup.first_error) {
                (Err(error), _) => Err(error),
                (Ok(_), Some(error)) => Err(error.into()),
                (Ok(handle), None) => Ok(handle),
            }
        }
        /// Failure returns the single original owner, including failures in
        /// root-table reservation after earlier graph preparation/charges.
        pub fn promote_graph_v1(
            &mut self,
            destination: RegionId,
            owner: OwnedGraphV1,
        ) -> Result<Handle, PromotionFailureV1> {
            match self.publish_graph_v1(destination, &owner) {
                Ok(handle) => Ok(handle),
                Err(error) => Err(PromotionFailureV1 {
                    error: transfer_error(error),
                    owner,
                }),
            }
        }
    }
}

}
mod heap {
use crate::cgx2_runtime::fault::{FaultInjection, ReserveSite};
use crate::cgx2_runtime::region::{CollectionMode, Handle, RegionStats};
use crate::cgx2_runtime::PauseReport;

pub(crate) struct Object {
    pub bytes: Vec<u8>,
    pub edges: Vec<Handle>,
    pub references: Option<Vec<Option<Handle>>>,
    pub roots: usize,
    pub scoped_roots: usize,
    pub charge: usize,
}

#[derive(Default)]
pub(crate) struct Slot {
    pub generation: u64,
    pub object: Option<Object>,
    pub marked: bool,
}

pub(crate) struct Region {
    pub mode: CollectionMode,
    pub limit_bytes: usize,
    pub slots: Vec<Slot>,
    pub stats: RegionStats,
    pub pause: PauseReport,
    pub closed: bool,
}

impl Region {
    pub fn new(mode: CollectionMode, limit_bytes: usize) -> Self {
        Self {
            mode,
            limit_bytes,
            slots: Vec::new(),
            stats: RegionStats::default(),
            pause: PauseReport::default(),
            closed: false,
        }
    }

    pub fn vacant_slot(&mut self, fault: &mut FaultInjection) -> Result<usize, ()> {
        if let Some(index) = self
            .slots
            .iter()
            .position(|slot| slot.object.is_none() && slot.generation < u64::MAX)
        {
            return Ok(index);
        }
        if self.slots.len() == self.slots.capacity() {
            fault.before_reserve(ReserveSite::SlotTable)?;
        }
        self.slots.try_reserve(1).map_err(|_| ())?;
        self.slots.push(Slot::default());
        Ok(self.slots.len() - 1)
    }
}

}
mod owned {
use crate::cgx2_runtime::{AllocationError, Handle, MemoryError, ReserveSite, Session};

/// Fixed logical header charge for a separately owned byte buffer.
pub const OWNED_METADATA_BYTES: usize = 32;

/// A uniquely owned byte buffer, released when the Rust value is dropped.
///
/// This value cannot be cloned; an explicit managed-to-owned copy is available
/// through [`Session::copy_managed_to_owned`].
///
/// ```compile_fail
/// use cgx2_runtime::Session;
/// let mut session = Session::new();
/// let value = session.alloc_owned_bytes(1).unwrap();
/// let second_owner = value.clone();
/// ```
#[derive(Debug)]
pub struct OwnedBytes {
    pub(crate) bytes: Vec<u8>,
}

impl OwnedBytes {
    pub fn as_slice(&self) -> &[u8] {
        &self.bytes
    }

    pub fn as_mut_slice(&mut self) -> &mut [u8] {
        &mut self.bytes
    }

    pub fn len(&self) -> usize {
        self.bytes.len()
    }

    pub fn is_empty(&self) -> bool {
        self.bytes.is_empty()
    }
}

impl Session {
    pub fn alloc_owned_bytes(&mut self, len: usize) -> Result<OwnedBytes, AllocationError> {
        let minimum = len
            .checked_add(OWNED_METADATA_BYTES)
            .ok_or(AllocationError::HostAllocation)?;
        self.check_budgets(minimum)?;
        let mut bytes = Vec::new();
        if len > 0 {
            self.fault
                .before_reserve(ReserveSite::OwnedBytes)
                .map_err(|_| AllocationError::HostAllocation)?;
        }
        bytes
            .try_reserve_exact(len)
            .map_err(|_| AllocationError::HostAllocation)?;
        let charge = bytes
            .capacity()
            .checked_add(OWNED_METADATA_BYTES)
            .ok_or(AllocationError::HostAllocation)?;
        self.check_budgets(charge)?;
        bytes.resize(len, 0);
        self.charge_budgets(charge);
        Ok(OwnedBytes { bytes })
    }

    /// Copies the managed payload into separately owned storage. The handle
    /// remains valid, subject to the ordinary region collection rules.
    pub fn copy_managed_to_owned(&mut self, handle: Handle) -> Result<OwnedBytes, MemoryError> {
        let len = self.read_bytes(handle)?.len();
        let minimum = len
            .checked_add(OWNED_METADATA_BYTES)
            .ok_or(MemoryError::Allocation(AllocationError::HostAllocation))?;
        self.check_budgets(minimum)
            .map_err(MemoryError::Allocation)?;
        let mut bytes = Vec::new();
        if len > 0 {
            self.fault
                .before_reserve(ReserveSite::ManagedToOwned)
                .map_err(|_| MemoryError::Allocation(AllocationError::HostAllocation))?;
        }
        bytes
            .try_reserve_exact(len)
            .map_err(|_| MemoryError::Allocation(AllocationError::HostAllocation))?;
        let charge = bytes
            .capacity()
            .checked_add(OWNED_METADATA_BYTES)
            .ok_or(MemoryError::Allocation(AllocationError::HostAllocation))?;
        self.check_budgets(charge)
            .map_err(MemoryError::Allocation)?;
        bytes.extend_from_slice(self.read_bytes(handle)?);
        self.charge_budgets(charge);
        Ok(OwnedBytes { bytes })
    }
}

}
mod region {
/// The first runtime charges this fixed amount for each occupied object slot.
pub const SLOT_METADATA_BYTES: usize = 64;
/// Session bookkeeping charged to active no-GC budgets when a region is created.
pub const REGION_METADATA_BYTES: usize = 128;
/// One stored reference is charged by its reserved vector capacity.
pub const EDGE_METADATA_BYTES: usize = std::mem::size_of::<Handle>();
/// One preallocated checked reference slot, charged by reserved vector capacity.
pub const REFERENCE_SLOT_METADATA_BYTES: usize = std::mem::size_of::<Option<Handle>>();
/// Maximum payload in the direct managed-object profile.
pub const MAX_OBJECT_PAYLOAD_BYTES: usize = 1 << 20;
/// Maximum checked references in one managed object.
pub const MAX_OBJECT_REFERENCE_SLOTS: usize = 256;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CollectionMode {
    Auto { trigger_bytes: usize },
    Manual,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct RegionId {
    pub(crate) session: u64,
    pub(crate) index: usize,
}
impl RegionId {
    /// Stable index within the creating session. Closed indices are never reused.
    pub fn index(self) -> usize {
        self.index
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct Handle {
    pub(crate) region: RegionId,
    pub(crate) slot: usize,
    pub(crate) generation: u64,
}
impl Handle {
    pub fn region(self) -> RegionId {
        self.region
    }

    pub fn generation(self) -> u64 {
        self.generation
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct RegionStats {
    pub committed_bytes: usize,
    pub live_bytes: usize,
    pub peak_bytes: usize,
    pub allocation_failures: u64,
    pub collection_count: u64,
    pub total_collected_bytes: usize,
}
/// Direct count of live runtime root registrations.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct RootCensus {
    /// Number of live objects with at least one root registration.
    pub rooted_handles: usize,
    /// Total registrations, including repeated roots of the same handle.
    pub root_registrations: usize,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum AllocationError {
    BudgetExceeded,
    RegionLimit,
    HostAllocation,
    InvalidRegion,
    ShapeLimit,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MemoryError {
    InvalidHandle,
    InvalidRegion,
    NotObject,
    InvalidReferenceSlot,
    CrossRegionEdge,
    RegionHasRoots,
    CollectionForbidden,
    NotRooted,
    RootCensusOverflow,
    Allocation(AllocationError),
}

}
mod report {
use std::fmt::Write;

use crate::cgx2_runtime::{CollectionMode, RegionId, RegionStats};

/// Version of the stable text/JSON memory report schema.
pub const MEMORY_REPORT_SCHEMA_VERSION: u32 = 1;

/// Bounded, log2 pause histogram. Bucket 0 is exactly zero nanoseconds;
/// bucket n (1..=64) contains [2^(n-1), 2^n) nanoseconds, with bucket 64
/// extending through `u64::MAX`. Durations larger than `u64::MAX` saturate.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PauseReport {
    pub sample_count: u64,
    pub total_ns: u128,
    pub min_ns: u64,
    pub max_ns: u64,
    pub buckets: [u64; 65],
}

impl Default for PauseReport {
    fn default() -> Self {
        Self {
            sample_count: 0,
            total_ns: 0,
            min_ns: 0,
            max_ns: 0,
            buckets: [0; 65],
        }
    }
}

impl PauseReport {
    pub(crate) fn record(&mut self, elapsed_ns: u128) {
        let ns = elapsed_ns.min(u128::from(u64::MAX)) as u64;
        let bucket = if ns == 0 {
            0
        } else {
            (u64::BITS - ns.leading_zeros()) as usize
        };
        self.sample_count = self.sample_count.saturating_add(1);
        self.total_ns = self.total_ns.saturating_add(elapsed_ns);
        self.buckets[bucket] = self.buckets[bucket].saturating_add(1);
        if self.sample_count == 1 {
            self.min_ns = ns;
            self.max_ns = ns;
        } else {
            self.min_ns = self.min_ns.min(ns);
            self.max_ns = self.max_ns.max(ns);
        }
    }
}

/// A region's current or terminal counters. Byte fields are logical CGx2
/// region charges, including slot and edge capacity, excluding foreign memory.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RegionReport {
    pub id: RegionId,
    pub is_open: bool,
    pub mode: CollectionMode,
    pub limit_bytes: usize,
    pub committed_bytes: usize,
    pub live_bytes: usize,
    pub peak_bytes: usize,
    pub allocation_failures: u64,
    pub collection_count: u64,
    pub total_collected_bytes: usize,
    pub pause: PauseReport,
}

/// A read-only, deterministic snapshot. `totals.peak_bytes` sums each region's
/// individual high-water mark; it is not a simultaneous session peak.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct MemoryReport {
    pub schema_version: u32,
    pub regions: Vec<RegionReport>,
    pub totals: RegionStats,
}

impl MemoryReport {
    /// Renders versioned JSON without user-provided strings or external crates.
    pub fn to_json(&self) -> String {
        let mut out = format!("{{\"schema_version\":{},\"regions\":[", self.schema_version);
        for (index, row) in self.regions.iter().enumerate() {
            if index != 0 {
                out.push(',');
            }
            let (mode, trigger) = match row.mode {
                CollectionMode::Auto { trigger_bytes } => ("auto", trigger_bytes.to_string()),
                CollectionMode::Manual => ("manual", "null".to_owned()),
            };
            write!(
                out,
                "{{\"region_id\":{{\"session\":{},\"index\":{}}},\"is_open\":{},\"mode\":\"{}\",\"trigger_bytes\":{},\"limit_bytes\":{},\"committed_bytes\":{},\"live_bytes\":{},\"peak_bytes\":{},\"allocation_failures\":{},\"collection_count\":{},\"total_collected_bytes\":{},\"pause\":{{\"sample_count\":{},\"total_ns\":{},\"min_ns\":{},\"max_ns\":{},\"buckets\":[",
                row.id.session,
                row.id.index,
                row.is_open,
                mode,
                trigger,
                row.limit_bytes,
                row.committed_bytes,
                row.live_bytes,
                row.peak_bytes,
                row.allocation_failures,
                row.collection_count,
                row.total_collected_bytes,
                row.pause.sample_count,
                row.pause.total_ns,
                row.pause.min_ns,
                row.pause.max_ns,
            )
            .expect("writing to a String cannot fail");
            for (bucket, count) in row.pause.buckets.iter().enumerate() {
                if bucket != 0 {
                    out.push(',');
                }
                write!(out, "{count}").expect("writing to a String cannot fail");
            }
            out.push_str("]}}");
        }
        let totals = &self.totals;
        write!(
            out,
            "],\"totals\":{{\"committed_bytes\":{},\"live_bytes\":{},\"peak_bytes\":{},\"allocation_failures\":{},\"collection_count\":{},\"total_collected_bytes\":{}}}}}",
            totals.committed_bytes,
            totals.live_bytes,
            totals.peak_bytes,
            totals.allocation_failures,
            totals.collection_count,
            totals.total_collected_bytes,
        )
        .expect("writing to a String cannot fail");
        out
    }

    /// Renders the same counters in a stable, line-oriented human format.
    pub fn to_text(&self) -> String {
        let mut out = format!("CGx2 memory report v{}\n", self.schema_version);
        for row in &self.regions {
            let mode = match row.mode {
                CollectionMode::Auto { trigger_bytes } => {
                    format!("auto trigger_bytes={trigger_bytes}")
                }
                CollectionMode::Manual => "manual".to_owned(),
            };
            let state = if row.is_open { "open" } else { "closed" };
            writeln!(
                out,
                "region {}:{} {} mode={} limit_bytes={} committed_bytes={} live_bytes={} peak_bytes={} allocation_failures={} collection_count={} total_collected_bytes={} pause_samples={} pause_total_ns={} pause_min_ns={} pause_max_ns={} pause_buckets={:?}",
                row.id.session,
                row.id.index,
                state,
                mode,
                row.limit_bytes,
                row.committed_bytes,
                row.live_bytes,
                row.peak_bytes,
                row.allocation_failures,
                row.collection_count,
                row.total_collected_bytes,
                row.pause.sample_count,
                row.pause.total_ns,
                row.pause.min_ns,
                row.pause.max_ns,
                row.pause.buckets,
            )
            .expect("writing to a String cannot fail");
        }
        let totals = &self.totals;
        writeln!(
            out,
            "totals committed_bytes={} live_bytes={} peak_bytes={} allocation_failures={} collection_count={} total_collected_bytes={}",
            totals.committed_bytes,
            totals.live_bytes,
            totals.peak_bytes,
            totals.allocation_failures,
            totals.collection_count,
            totals.total_collected_bytes,
        )
        .expect("writing to a String cannot fail");
        out
    }
}

#[cfg(test)]
mod tests {
    use super::PauseReport;

    #[test]
    fn pause_histogram_bounds_and_saturating_units() {
        let mut pause = PauseReport::default();
        for ns in [0, 1, 2, 3, u128::from(u64::MAX) + 1] {
            pause.record(ns);
        }
        assert_eq!(pause.sample_count, 5);
        assert_eq!(pause.buckets[0], 1);
        assert_eq!(pause.buckets[1], 1);
        assert_eq!(pause.buckets[2], 2);
        assert_eq!(pause.buckets[64], 1);
        assert_eq!(pause.min_ns, 0);
        assert_eq!(pause.max_ns, u64::MAX);
        assert_eq!(pause.total_ns, u128::from(u64::MAX) + 7);
        pause.record(u128::MAX);
        assert_eq!(pause.total_ns, u128::MAX);
    }
}

}
mod scope {
//! Compiler-consumable lexical root ownership. No source lowering is implied.
use std::ops::{Deref, DerefMut};

use crate::cgx2_runtime::{AllocationError, Handle, MemoryError, ReserveSiteV2, Session};

/// Cleanup continues after an error and never replaces the caller's result.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct CleanupReport {
    pub released_roots: usize,
    pub first_error: Option<MemoryError>,
}

#[derive(Debug, PartialEq, Eq)]
pub struct ScopeOutcome<T, E> {
    pub result: Result<T, E>,
    pub cleanup: CleanupReport,
}

/// Owns exactly the registrations acquired by `ScopedRoots::root`.
///
/// Nested scopes borrow the session exclusively. Drop performs allocation-free
/// cleanup on normal return, cancellation by drop, and Rust panic unwind. As with
/// Rust RAII, abort, process termination and `mem::forget` do not run cleanup.
/// Manual `Session::unroot` cannot consume these protected registrations.
pub struct ScopedRoots<'a> {
    session: &'a mut Session,
    roots: Vec<Handle>,
}

impl Session {
    /// Scope entry itself does not allocate. Each root registration is fallible.
    pub fn scoped_roots(&mut self) -> ScopedRoots<'_> {
        ScopedRoots {
            session: self,
            roots: Vec::new(),
        }
    }
}

impl ScopedRoots<'_> {
    /// Nonallocating marker for a compiler expression's temporary registrations.
    pub fn checkpoint(&self) -> usize {
        self.roots.len()
    }

    pub fn contains_since(&self, checkpoint: usize, handle: Handle) -> bool {
        self.roots
            .get(checkpoint..)
            .is_some_and(|roots| roots.contains(&handle))
    }

    /// Releases expression temporaries, retaining one already registered result.
    /// Capacity is retained and this operation never allocates or collects.
    pub fn finish_since(&mut self, checkpoint: usize, retain: Option<Handle>) -> CleanupReport {
        if checkpoint > self.roots.len() {
            return CleanupReport {
                released_roots: 0,
                first_error: Some(MemoryError::NotRooted),
            };
        }
        let retained = retain.and_then(|handle| {
            self.roots[checkpoint..]
                .iter()
                .rposition(|h| *h == handle)
                .map(|index| self.roots.swap_remove(checkpoint + index))
        });
        let mut report = CleanupReport::default();
        while self.roots.len() > checkpoint {
            let handle = self.roots.pop().expect("temporary root");
            match self.session.object_mut(handle).and_then(|object| {
                if object.scoped_roots == 0 || object.roots == 0 {
                    return Err(MemoryError::NotRooted);
                }
                object.scoped_roots -= 1;
                object.roots -= 1;
                Ok(())
            }) {
                Ok(()) => report.released_roots += 1,
                Err(error) => {
                    report.first_error.get_or_insert(error);
                }
            }
        }
        if let Some(handle) = retained {
            self.roots.push(handle);
        }
        report
    }

    /// Releases one registration owned by this scope, without allocation or collection.
    /// This permits compiler temporaries and overwritten bindings to end promptly.
    pub fn release(&mut self, handle: Handle) -> Result<(), MemoryError> {
        let index = self
            .roots
            .iter()
            .rposition(|h| *h == handle)
            .ok_or(MemoryError::NotRooted)?;
        let object = self.session.object_mut(handle)?;
        if object.scoped_roots == 0 || object.roots == 0 {
            return Err(MemoryError::NotRooted);
        }
        object.scoped_roots -= 1;
        object.roots -= 1;
        self.roots.swap_remove(index);
        Ok(())
    }

    /// End the registrations dependent on one lexical region, preserving roots
    /// of outer bindings even when those bindings were replaced inside the arm.
    /// The table is shared with the arm so an assignment releases its actual
    /// registration owner. Cleanup never allocates or collects.
    pub(crate) fn cleanup_region_v1(&mut self, region: crate::cgx2_runtime::RegionId) -> CleanupReport {
        let mut report = CleanupReport::default();
        for index in (0..self.roots.len()).rev() {
            if self.roots[index].region() != region {
                continue;
            }
            let handle = self.roots.swap_remove(index);
            match self.session.object_mut(handle).and_then(|object| {
                if object.scoped_roots == 0 || object.roots == 0 {
                    return Err(MemoryError::NotRooted);
                }
                object.scoped_roots -= 1;
                object.roots -= 1;
                Ok(())
            }) {
                Ok(()) => report.released_roots += 1,
                Err(error) => {
                    report.first_error.get_or_insert(error);
                }
            }
        }
        report
    }

    /// Runs a lexical guard with the same protected registration table and Session.
    /// Moving the table performs no allocation. Nested scopes still clean up on unwind.
    pub fn with_no_gc<T>(
        &mut self,
        budget: usize,
        body: impl FnOnce(&mut ScopedRoots<'_>) -> T,
    ) -> Result<T, AllocationError> {
        let mut guard = self.session.try_no_gc(budget)?;
        let registrations = std::mem::take(&mut self.roots);
        let mut nested = ScopedRoots {
            session: &mut guard,
            roots: registrations,
        };
        // Restore the registration owner even when a caller catches an unwind
        // without dropping its outer scope. Then resume the original panic.
        let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| body(&mut nested)));
        self.roots = std::mem::take(&mut nested.roots);
        match result {
            Ok(value) => Ok(value),
            Err(payload) => std::panic::resume_unwind(payload),
        }
    }

    /// Registers one protected root. Failure leaves registrations unchanged.
    /// Root-table growth is charged to every active no_gc budget, not a region.
    pub fn root(&mut self, handle: Handle) -> Result<(), MemoryError> {
        self.session
            .object_mut(handle)?
            .roots
            .checked_add(1)
            .ok_or(MemoryError::InvalidHandle)?;
        self.root_many(&[Some(handle)])
    }

    /// Registers a complete evaluated child list before an allocating safepoint.
    /// Invalid handles and counter overflow leave registrations unchanged. A
    /// successful table reserve remains charged even if registration fails.
    pub fn root_many(&mut self, handles: &[Option<Handle>]) -> Result<(), MemoryError> {
        let count = handles.iter().flatten().count();
        for handle in handles.iter().flatten() {
            self.session.read_bytes(*handle)?;
        }
        self.reserve_root_slots_v1(count)?;
        let initial = self.roots.len();
        for handle in handles.iter().flatten().copied() {
            let object = self.session.object_mut(handle)?;
            let Some(next) = object.roots.checked_add(1) else {
                while self.roots.len() > initial {
                    let registered = self.roots.pop().expect("new registration");
                    let object = self.session.object_mut(registered)?;
                    object.roots -= 1;
                    object.scoped_roots -= 1;
                }
                return Err(MemoryError::InvalidHandle);
            };
            object.roots = next;
            object.scoped_roots += 1;
            self.roots.push(handle);
        }
        Ok(())
    }

    /// Prepare publication before an irreversible graph transfer. Reservations
    /// remain charged even if later payload preparation fails.
    pub(crate) fn reserve_root_slots_v1(&mut self, count: usize) -> Result<(), MemoryError> {
        let needed = self
            .roots
            .len()
            .checked_add(count)
            .ok_or(MemoryError::Allocation(AllocationError::HostAllocation))?;
        if needed > self.roots.capacity() {
            let bytes = needed
                .checked_mul(std::mem::size_of::<Handle>())
                .ok_or(MemoryError::Allocation(AllocationError::HostAllocation))?;
            self.session
                .check_budgets(bytes)
                .map_err(MemoryError::Allocation)?;
            self.session
                .fault
                .before_reserve_v2(ReserveSiteV2::ScopedRoots)
                .map_err(|_| MemoryError::Allocation(AllocationError::HostAllocation))?;
            let mut replacement: Vec<Handle> = Vec::new();
            replacement
                .try_reserve_exact(needed)
                .map_err(|_| MemoryError::Allocation(AllocationError::HostAllocation))?;
            let charge = replacement
                .capacity()
                .checked_mul(std::mem::size_of::<Handle>())
                .ok_or(MemoryError::Allocation(AllocationError::HostAllocation))?;
            self.session
                .check_budgets(charge)
                .map_err(MemoryError::Allocation)?;
            self.session.charge_budgets(charge);
            replacement.extend_from_slice(&self.roots);
            self.roots = replacement;
        }
        Ok(())
    }

    /// Drains in reverse registration order, including duplicate handles.
    /// Repeated cleanup is a no-op; table capacity is retained for scope reuse.
    pub fn cleanup(&mut self) -> CleanupReport {
        let mut report = CleanupReport::default();
        while let Some(handle) = self.roots.pop() {
            let released = self.session.object_mut(handle).and_then(|object| {
                if object.scoped_roots == 0 || object.roots == 0 {
                    return Err(MemoryError::NotRooted);
                }
                object.scoped_roots -= 1;
                object.roots -= 1;
                Ok(())
            });
            match released {
                Ok(()) => report.released_roots += 1,
                Err(error) => {
                    report.first_error.get_or_insert(error);
                }
            }
        }
        report
    }

    /// Preserves success or the original error (including caller cancellation),
    /// with separate cleanup diagnostics. Also safe to call before Drop.
    pub fn finish<T, E>(&mut self, result: Result<T, E>) -> ScopeOutcome<T, E> {
        ScopeOutcome {
            result,
            cleanup: self.cleanup(),
        }
    }
}

impl Deref for ScopedRoots<'_> {
    type Target = Session;
    fn deref(&self) -> &Session {
        self.session
    }
}

impl DerefMut for ScopedRoots<'_> {
    fn deref_mut(&mut self) -> &mut Session {
        self.session
    }
}

impl Drop for ScopedRoots<'_> {
    fn drop(&mut self) {
        self.cleanup();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn overflow_and_invalid_handles_leave_scope_empty() {
        let mut session = Session::try_new().unwrap();
        let handle = session.alloc_bytes(session.default_region(), 1).unwrap();
        session.object_mut(handle).unwrap().roots = usize::MAX;
        let mut scope = session.scoped_roots();
        assert_eq!(scope.root(handle), Err(MemoryError::InvalidHandle));
        assert_eq!(scope.cleanup(), CleanupReport::default());
        scope.object_mut(handle).unwrap().roots = 0;
        scope.collect(handle.region()).unwrap();
        assert_eq!(scope.root(handle), Err(MemoryError::InvalidHandle));
        assert_eq!(scope.cleanup(), CleanupReport::default());
    }

    #[test]
    fn cleanup_continues_after_corruption_and_preserves_primary_error() {
        // Internal corruption injection, not a supported compiler operation.
        let mut session = Session::try_new().unwrap();
        let a = session.alloc_bytes(session.default_region(), 1).unwrap();
        let b = session.alloc_bytes(session.default_region(), 1).unwrap();
        let mut scope = session.scoped_roots();
        scope.root(a).unwrap();
        scope.root(b).unwrap();
        scope.object_mut(b).unwrap().scoped_roots = 0;
        let outcome = scope.finish::<(), _>(Err("primary failure"));
        assert_eq!(outcome.result, Err("primary failure"));
        assert_eq!(
            outcome.cleanup,
            CleanupReport {
                released_roots: 1,
                first_error: Some(MemoryError::NotRooted),
            }
        );
        assert_eq!(scope.cleanup(), CleanupReport::default());
        assert_eq!(scope.object_mut(a).unwrap().roots, 0);
        scope.unroot(b).unwrap();
    }

    #[test]
    fn identifier_exhaustion_is_fallible_and_does_not_wrap() {
        use std::sync::atomic::{AtomicU64, Ordering};
        let counter = AtomicU64::new(u64::MAX - 1);
        assert_eq!(crate::cgx2_runtime::try_session_id(&counter), Ok(u64::MAX - 1));
        assert_eq!(
            crate::cgx2_runtime::try_session_id(&counter),
            Err(crate::cgx2_runtime::SessionEntryError::IdentifierExhausted)
        );
        assert_eq!(counter.load(Ordering::Relaxed), u64::MAX);
    }
}

}
pub use graph::default_managed;

use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Instant;

use budget::Budget;
pub use budget::NoGcGuard;
use fault::FaultInjection;
pub use fault::{ReserveSite, ReserveSiteV2};
/// Additive ordinary-memory graph and transfer APIs.
pub use graph::ordinary_memory;
pub use graph::{
    GraphError, GraphShape, PayloadError, MAX_GRAPH_PAYLOAD_BYTES, MAX_GRAPH_REFERENCES,
};
use heap::{Object, Region};
pub use owned::{OwnedBytes, OWNED_METADATA_BYTES};
pub use region::{
    AllocationError, CollectionMode, Handle, MemoryError, RegionId, RegionStats, RootCensus,
    EDGE_METADATA_BYTES, MAX_OBJECT_PAYLOAD_BYTES, MAX_OBJECT_REFERENCE_SLOTS,
    REFERENCE_SLOT_METADATA_BYTES, REGION_METADATA_BYTES, SLOT_METADATA_BYTES,
};
pub use report::{MemoryReport, PauseReport, RegionReport, MEMORY_REPORT_SCHEMA_VERSION};
pub use scope::{CleanupReport, ScopeOutcome, ScopedRoots};

static NEXT_SESSION_ID: AtomicU64 = AtomicU64::new(1);

/// Failure before a usable session has been published.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SessionEntryError {
    HostAllocation { site: ReserveSiteV2 },
    IdentifierExhausted,
}

fn try_session_id(counter: &AtomicU64) -> Result<u64, SessionEntryError> {
    counter
        .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |n| n.checked_add(1))
        .map_err(|_| SessionEntryError::IdentifierExhausted)
}

pub struct Session {
    id: u64,
    regions: Vec<Region>,
    pub(crate) budgets: Vec<Budget>,
    pub(crate) charged_bytes_v2: u128,
    fault: FaultInjection,
}

impl Default for Session {
    fn default() -> Self {
        Self::new()
    }
}

/// Cumulative successful logical runtime charges, not RSS or foreign storage.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MemoryObservationV2 {
    pub charged_bytes: u128,
    pub active_guards: usize,
    pub collection_count: u64,
}
impl Session {
    pub fn memory_observation_v2(&self) -> MemoryObservationV2 {
        MemoryObservationV2 {
            charged_bytes: self.charged_bytes_v2,
            active_guards: self.budgets.len(),
            collection_count: self
                .regions
                .iter()
                .fold(0u64, |n, r| n.saturating_add(r.stats.collection_count)),
        }
    }

    pub fn new() -> Self {
        // Compatibility entry point: retain historical allocation/fault behavior.
        let id = NEXT_SESSION_ID
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |n| n.checked_add(1))
            .expect("session identifier space exhausted");
        Self {
            id,
            regions: vec![Region::new(
                CollectionMode::Auto {
                    trigger_bytes: 1 << 20,
                },
                64 << 20,
            )],
            budgets: Vec::new(),
            charged_bytes_v2: 0,
            fault: FaultInjection::default(),
        }
    }

    /// Fallible default session entry: auto trigger 1 MiB, region limit 64 MiB.
    pub fn try_new() -> Result<Self, SessionEntryError> {
        Self::try_new_with_fault(FaultInjection::default())
    }

    /// Conformance-only injection before the session exists. Index is one-based.
    #[cfg(feature = "fault-injection")]
    pub fn try_new_with_host_failure_at_reserve(index: usize) -> Result<Self, SessionEntryError> {
        let mut fault = FaultInjection::default();
        fault.arm(index);
        Self::try_new_with_fault(fault)
    }

    fn try_new_with_fault(mut fault: FaultInjection) -> Result<Self, SessionEntryError> {
        let site = ReserveSiteV2::SessionRegions;
        let mut regions = Vec::new();
        fault
            .before_reserve_v2(site)
            .map_err(|_| SessionEntryError::HostAllocation { site })?;
        regions
            .try_reserve_exact(1)
            .map_err(|_| SessionEntryError::HostAllocation { site })?;
        let id = try_session_id(&NEXT_SESSION_ID)?;
        regions.push(Region::new(
            CollectionMode::Auto {
                trigger_bytes: 1 << 20,
            },
            64 << 20,
        ));
        Ok(Self {
            id,
            regions,
            budgets: Vec::new(),
            charged_bytes_v2: 0,
            fault,
        })
    }

    /// Arms a one-shot failure at the one-based index of the next fallible
    /// host reserve. Available only to explicit conformance builds.
    #[cfg(feature = "fault-injection")]
    pub fn inject_host_failure_at_reserve(&mut self, index: usize) {
        self.fault.arm(index);
    }

    #[cfg(feature = "fault-injection")]
    pub fn disable_host_failure(&mut self) {
        self.fault.disable();
    }

    #[cfg(feature = "fault-injection")]
    pub fn host_reserve_attempts(&self) -> usize {
        self.fault.attempts
    }

    #[cfg(feature = "fault-injection")]
    pub fn last_host_failure_site(&self) -> Option<ReserveSite> {
        self.fault.failed_site
    }

    #[cfg(feature = "fault-injection")]
    pub fn last_host_failure_site_v2(&self) -> Option<ReserveSiteV2> {
        self.fault.failed_site_v2
    }

    /// Test-only visibility into slot-table capacity for targeting a real growth reserve.
    #[cfg(feature = "fault-injection")]
    pub fn host_slot_table_capacity(
        &self,
        region: RegionId,
    ) -> Result<(usize, usize), MemoryError> {
        let slots = &self.region(region)?.slots;
        Ok((slots.len(), slots.capacity()))
    }

    fn vacant_slot(&mut self, region: RegionId) -> Result<usize, ()> {
        let (regions, fault) = (&mut self.regions, &mut self.fault);
        regions[region.index].vacant_slot(fault)
    }

    pub fn default_region(&self) -> RegionId {
        RegionId {
            session: self.id,
            index: 0,
        }
    }

    pub fn no_gc(&mut self, budget_bytes: usize) -> NoGcGuard<'_> {
        // Compatibility entry point: bookkeeping retains its historical policy.
        self.budgets.push(Budget {
            limit: budget_bytes,
            spent: 0,
        });
        NoGcGuard { session: self }
    }

    /// Enters only after any budget-table growth succeeds. Existing guards stay
    /// active on failure; entry bookkeeping is charged to those outer guards.
    pub fn try_no_gc(&mut self, budget_bytes: usize) -> Result<NoGcGuard<'_>, AllocationError> {
        if self.budgets.len() == self.budgets.capacity() {
            let needed = self
                .budgets
                .len()
                .checked_add(1)
                .ok_or(AllocationError::HostAllocation)?;
            let bytes = needed
                .checked_mul(std::mem::size_of::<Budget>())
                .ok_or(AllocationError::HostAllocation)?;
            self.check_budgets(bytes)?;
            self.fault
                .before_reserve_v2(ReserveSiteV2::GuardBudgets)
                .map_err(|_| AllocationError::HostAllocation)?;
            let mut replacement = Vec::new();
            replacement
                .try_reserve_exact(needed)
                .map_err(|_| AllocationError::HostAllocation)?;
            let charge = replacement
                .capacity()
                .checked_mul(std::mem::size_of::<Budget>())
                .ok_or(AllocationError::HostAllocation)?;
            self.check_budgets(charge)?;
            self.charge_budgets(charge);
            replacement.extend_from_slice(&self.budgets);
            self.budgets = replacement;
        }
        self.budgets.push(Budget {
            limit: budget_bytes,
            spent: 0,
        });
        Ok(NoGcGuard { session: self })
    }

    pub fn create_region(
        &mut self,
        mode: CollectionMode,
        limit_bytes: usize,
    ) -> Result<RegionId, AllocationError> {
        self.check_budgets(REGION_METADATA_BYTES)?;
        if self.regions.len() == self.regions.capacity() {
            self.fault
                .before_reserve(ReserveSite::RegionTable)
                .map_err(|_| AllocationError::HostAllocation)?;
        }
        self.regions
            .try_reserve(1)
            .map_err(|_| AllocationError::HostAllocation)?;
        let id = RegionId {
            session: self.id,
            index: self.regions.len(),
        };
        self.regions.push(Region::new(mode, limit_bytes));
        self.charge_budgets(REGION_METADATA_BYTES);
        Ok(id)
    }

    fn region(&self, id: RegionId) -> Result<&Region, MemoryError> {
        if id.session != self.id {
            return Err(MemoryError::InvalidRegion);
        }
        self.regions
            .get(id.index)
            .filter(|region| !region.closed)
            .ok_or(MemoryError::InvalidRegion)
    }

    fn region_mut(&mut self, id: RegionId) -> Result<&mut Region, MemoryError> {
        if id.session != self.id {
            return Err(MemoryError::InvalidRegion);
        }
        self.regions
            .get_mut(id.index)
            .filter(|region| !region.closed)
            .ok_or(MemoryError::InvalidRegion)
    }

    pub fn mode(&self, region: RegionId) -> Result<CollectionMode, MemoryError> {
        Ok(self.region(region)?.mode)
    }
    pub fn limit_bytes(&self, region: RegionId) -> Result<usize, MemoryError> {
        Ok(self.region(region)?.limit_bytes)
    }
    pub fn stats(&self, region: RegionId) -> Result<RegionStats, MemoryError> {
        Ok(self.region(region)?.stats)
    }

    /// Returns a read-only snapshot in creation order, including closed regions.
    /// Closed IDs are never reused; they remain invalid for region operations.
    pub fn memory_report(&self) -> MemoryReport {
        let mut totals = RegionStats::default();
        let regions = self
            .regions
            .iter()
            .enumerate()
            .map(|(index, region)| {
                let stats = region.stats;
                totals.committed_bytes =
                    totals.committed_bytes.saturating_add(stats.committed_bytes);
                totals.live_bytes = totals.live_bytes.saturating_add(stats.live_bytes);
                totals.peak_bytes = totals.peak_bytes.saturating_add(stats.peak_bytes);
                totals.allocation_failures = totals
                    .allocation_failures
                    .saturating_add(stats.allocation_failures);
                totals.collection_count = totals
                    .collection_count
                    .saturating_add(stats.collection_count);
                totals.total_collected_bytes = totals
                    .total_collected_bytes
                    .saturating_add(stats.total_collected_bytes);
                RegionReport {
                    id: RegionId {
                        session: self.id,
                        index,
                    },
                    is_open: !region.closed,
                    mode: region.mode,
                    limit_bytes: region.limit_bytes,
                    committed_bytes: stats.committed_bytes,
                    live_bytes: stats.live_bytes,
                    peak_bytes: stats.peak_bytes,
                    allocation_failures: stats.allocation_failures,
                    collection_count: stats.collection_count,
                    total_collected_bytes: stats.total_collected_bytes,
                    pause: region.pause.clone(),
                }
            })
            .collect();
        MemoryReport {
            schema_version: MEMORY_REPORT_SCHEMA_VERSION,
            regions,
            totals,
        }
    }

    pub fn alloc_bytes(&mut self, region: RegionId, len: usize) -> Result<Handle, AllocationError> {
        let r = self
            .region(region)
            .map_err(|_| AllocationError::InvalidRegion)?;
        let requested = match len.checked_add(SLOT_METADATA_BYTES) {
            Some(requested) => requested,
            None => {
                self.region_mut(region)
                    .expect("validated region")
                    .stats
                    .allocation_failures += 1;
                return Err(AllocationError::HostAllocation);
            }
        };
        if requested > r.limit_bytes {
            self.region_mut(region)
                .expect("validated region")
                .stats
                .allocation_failures += 1;
            return Err(AllocationError::RegionLimit);
        }
        // Vec cannot reserve a buffer larger than isize::MAX bytes on this host.
        if len > isize::MAX as usize {
            self.region_mut(region)
                .expect("validated region")
                .stats
                .allocation_failures += 1;
            return Err(AllocationError::HostAllocation);
        }
        if let Err(error) = self.check_budgets(requested) {
            self.region_mut(region)
                .expect("validated region")
                .stats
                .allocation_failures += 1;
            return Err(error);
        }
        let needs_collect = self.budgets.is_empty()
            && matches!(r.mode, CollectionMode::Auto { trigger_bytes } if
                r.stats.committed_bytes >= trigger_bytes
                    || requested > r.limit_bytes.saturating_sub(r.stats.committed_bytes));
        if needs_collect {
            self.collect(region)
                .map_err(|_| AllocationError::InvalidRegion)?;
        }
        let r = &mut self.regions[region.index];
        if requested > r.limit_bytes.saturating_sub(r.stats.committed_bytes) {
            r.stats.allocation_failures += 1;
            return Err(AllocationError::RegionLimit);
        }
        let mut bytes = Vec::new();
        if (len > 0
            && self
                .fault
                .before_reserve(ReserveSite::ManagedBytes)
                .is_err())
            || bytes.try_reserve_exact(len).is_err()
        {
            r.stats.allocation_failures += 1;
            return Err(AllocationError::HostAllocation);
        }
        let charge = match bytes.capacity().checked_add(SLOT_METADATA_BYTES) {
            Some(charge) => charge,
            None => {
                r.stats.allocation_failures += 1;
                return Err(AllocationError::HostAllocation);
            }
        };
        // Release the mutable region borrow before checking all active budgets.
        if let Err(error) = self.check_budgets(charge) {
            self.region_mut(region)
                .expect("validated region")
                .stats
                .allocation_failures += 1;
            return Err(error);
        }
        let r = &mut self.regions[region.index];
        if charge > r.limit_bytes.saturating_sub(r.stats.committed_bytes) {
            r.stats.allocation_failures += 1;
            return Err(AllocationError::RegionLimit);
        }
        bytes.resize(len, 0);
        let index = match r.vacant_slot(&mut self.fault) {
            Ok(index) => index,
            Err(()) => {
                r.stats.allocation_failures += 1;
                return Err(AllocationError::HostAllocation);
            }
        };
        let slot = &mut r.slots[index];
        slot.object = Some(Object {
            bytes,
            edges: Vec::new(),
            references: None,
            roots: 0,
            scoped_roots: 0,
            charge,
        });
        r.stats.committed_bytes += charge;
        r.stats.live_bytes += charge;
        r.stats.peak_bytes = r.stats.peak_bytes.max(r.stats.committed_bytes);
        let generation = slot.generation;
        self.charge_budgets(charge);
        Ok(Handle {
            region,
            slot: index,
            generation,
        })
    }

    /// Allocates a bounded managed object with zero-filled bytes and empty checked references.
    /// The returned handle is initially unrooted, like `alloc_bytes`.
    pub fn alloc_object(
        &mut self,
        region: RegionId,
        payload_len: usize,
        reference_slots: usize,
    ) -> Result<Handle, AllocationError> {
        let limit_bytes = self
            .region(region)
            .map_err(|_| AllocationError::InvalidRegion)?
            .limit_bytes;
        if payload_len > MAX_OBJECT_PAYLOAD_BYTES || reference_slots > MAX_OBJECT_REFERENCE_SLOTS {
            return Err(self.allocation_failure(region, AllocationError::ShapeLimit));
        }
        let minimum_charge = payload_len
            .checked_add(SLOT_METADATA_BYTES)
            .and_then(|n| {
                reference_slots
                    .checked_mul(REFERENCE_SLOT_METADATA_BYTES)
                    .and_then(|references| n.checked_add(references))
            })
            .ok_or_else(|| self.allocation_failure(region, AllocationError::HostAllocation))?;
        if minimum_charge > limit_bytes {
            return Err(self.allocation_failure(region, AllocationError::RegionLimit));
        }
        self.check_budgets(minimum_charge)
            .map_err(|error| self.allocation_failure(region, error))?;
        let r = self.region(region).expect("validated region");
        // Manual regions and no_gc cannot reclaim space before this allocation. Reject
        // their logical limit before attempting any host reserve or injected failure.
        if (matches!(r.mode, CollectionMode::Manual) || !self.budgets.is_empty())
            && minimum_charge > r.limit_bytes.saturating_sub(r.stats.committed_bytes)
        {
            return Err(self.allocation_failure(region, AllocationError::RegionLimit));
        }

        let mut bytes = Vec::new();
        if payload_len > 0 {
            self.fault
                .before_reserve(ReserveSite::ObjectPayload)
                .map_err(|_| self.allocation_failure(region, AllocationError::HostAllocation))?;
        }
        bytes
            .try_reserve_exact(payload_len)
            .map_err(|_| self.allocation_failure(region, AllocationError::HostAllocation))?;
        let mut references = Vec::new();
        if reference_slots > 0 {
            self.fault
                .before_reserve(ReserveSite::ObjectReferences)
                .map_err(|_| self.allocation_failure(region, AllocationError::HostAllocation))?;
        }
        references
            .try_reserve_exact(reference_slots)
            .map_err(|_| self.allocation_failure(region, AllocationError::HostAllocation))?;
        let charge = bytes
            .capacity()
            .checked_add(SLOT_METADATA_BYTES)
            .and_then(|n| {
                references
                    .capacity()
                    .checked_mul(REFERENCE_SLOT_METADATA_BYTES)
                    .and_then(|reference_charge| n.checked_add(reference_charge))
            })
            .ok_or_else(|| self.allocation_failure(region, AllocationError::HostAllocation))?;
        if charge > self.region(region).expect("validated region").limit_bytes {
            return Err(self.allocation_failure(region, AllocationError::RegionLimit));
        }
        self.check_budgets(charge)
            .map_err(|error| self.allocation_failure(region, error))?;

        let r = self.region(region).expect("validated region");
        let needs_collect = self.budgets.is_empty()
            && matches!(r.mode, CollectionMode::Auto { trigger_bytes } if
                r.stats.committed_bytes >= trigger_bytes
                    || charge > r.limit_bytes.saturating_sub(r.stats.committed_bytes));
        if needs_collect {
            self.collect(region)
                .map_err(|_| AllocationError::InvalidRegion)?;
        }
        let r = self.region(region).expect("validated region");
        if charge > r.limit_bytes.saturating_sub(r.stats.committed_bytes) {
            return Err(self.allocation_failure(region, AllocationError::RegionLimit));
        }
        bytes.resize(payload_len, 0);
        references.resize(reference_slots, None);
        let index = match self.vacant_slot(region) {
            Ok(index) => index,
            Err(()) => return Err(self.allocation_failure(region, AllocationError::HostAllocation)),
        };
        let slot = &mut self.region_mut(region).expect("validated region").slots[index];
        let generation = slot.generation;
        slot.object = Some(Object {
            bytes,
            edges: Vec::new(),
            references: Some(references),
            roots: 0,
            scoped_roots: 0,
            charge,
        });
        let r = self.region_mut(region).expect("validated region");
        r.stats.committed_bytes += charge;
        r.stats.live_bytes += charge;
        r.stats.peak_bytes = r.stats.peak_bytes.max(r.stats.committed_bytes);
        self.charge_budgets(charge);
        Ok(Handle {
            region,
            slot: index,
            generation,
        })
    }

    fn allocation_failure(&mut self, region: RegionId, error: AllocationError) -> AllocationError {
        self.region_mut(region)
            .expect("validated region")
            .stats
            .allocation_failures += 1;
        error
    }

    /// Moves a unique owned payload into a managed slot without copying it.
    /// The active guard charge is only the newly created slot metadata; the
    /// payload was charged when it was allocated as owned storage.
    pub fn promote_owned(
        &mut self,
        region: RegionId,
        value: OwnedBytes,
    ) -> Result<Handle, (AllocationError, OwnedBytes)> {
        let r = match self.region(region) {
            Ok(r) => r,
            Err(_) => return Err((AllocationError::InvalidRegion, value)),
        };
        let charge = match value.bytes.capacity().checked_add(SLOT_METADATA_BYTES) {
            Some(charge) => charge,
            None => {
                self.region_mut(region)
                    .expect("validated region")
                    .stats
                    .allocation_failures += 1;
                return Err((AllocationError::HostAllocation, value));
            }
        };
        if let Err(error) = self.check_budgets(SLOT_METADATA_BYTES) {
            self.region_mut(region)
                .expect("validated region")
                .stats
                .allocation_failures += 1;
            return Err((error, value));
        }
        if charge > r.limit_bytes.saturating_sub(r.stats.committed_bytes) {
            self.region_mut(region)
                .expect("validated region")
                .stats
                .allocation_failures += 1;
            return Err((AllocationError::RegionLimit, value));
        }
        let index = match self.vacant_slot(region) {
            Ok(index) => index,
            Err(()) => {
                return Err((
                    self.allocation_failure(region, AllocationError::HostAllocation),
                    value,
                ));
            }
        };
        let r = self.region_mut(region).expect("validated region");
        let slot = &mut r.slots[index];
        slot.object = Some(Object {
            bytes: value.bytes,
            edges: Vec::new(),
            references: None,
            roots: 0,
            scoped_roots: 0,
            charge,
        });
        r.stats.committed_bytes += charge;
        r.stats.live_bytes += charge;
        r.stats.peak_bytes = r.stats.peak_bytes.max(r.stats.committed_bytes);
        let generation = slot.generation;
        self.charge_budgets(SLOT_METADATA_BYTES);
        Ok(Handle {
            region,
            slot: index,
            generation,
        })
    }

    pub fn read_bytes(&self, handle: Handle) -> Result<&[u8], MemoryError> {
        let r = self
            .region(handle.region)
            .map_err(|_| MemoryError::InvalidHandle)?;
        let slot = r.slots.get(handle.slot).ok_or(MemoryError::InvalidHandle)?;
        if slot.generation != handle.generation {
            return Err(MemoryError::InvalidHandle);
        }
        Ok(&slot
            .object
            .as_ref()
            .ok_or(MemoryError::InvalidHandle)?
            .bytes)
    }

    fn object_mut(&mut self, handle: Handle) -> Result<&mut Object, MemoryError> {
        let r = self
            .region_mut(handle.region)
            .map_err(|_| MemoryError::InvalidHandle)?;
        let slot = r
            .slots
            .get_mut(handle.slot)
            .ok_or(MemoryError::InvalidHandle)?;
        if slot.generation != handle.generation {
            return Err(MemoryError::InvalidHandle);
        }
        slot.object.as_mut().ok_or(MemoryError::InvalidHandle)
    }

    pub fn root(&mut self, handle: Handle) -> Result<(), MemoryError> {
        let object = self.object_mut(handle)?;
        object.roots = object
            .roots
            .checked_add(1)
            .ok_or(MemoryError::InvalidHandle)?;
        Ok(())
    }

    pub fn unroot(&mut self, handle: Handle) -> Result<(), MemoryError> {
        let object = self.object_mut(handle)?;
        if object.roots == object.scoped_roots {
            return Err(MemoryError::NotRooted);
        }
        object.roots -= 1;
        Ok(())
    }
    /// Counts registrations held by live runtime objects without allocating or changing session state.
    pub fn root_census(&self) -> Result<RootCensus, MemoryError> {
        let mut census = RootCensus::default();
        for region in self.regions.iter().filter(|region| !region.closed) {
            Self::accumulate_roots(region, &mut census)?;
        }
        Ok(census)
    }

    /// Counts registrations in an open region's live slot table.
    pub fn root_census_region(&self, region: RegionId) -> Result<RootCensus, MemoryError> {
        let mut census = RootCensus::default();
        Self::accumulate_roots(self.region(region)?, &mut census)?;
        Ok(census)
    }

    fn accumulate_roots(region: &Region, census: &mut RootCensus) -> Result<(), MemoryError> {
        for slot in &region.slots {
            if let Some(object) = &slot.object {
                if object.roots > 0 {
                    census.rooted_handles = census
                        .rooted_handles
                        .checked_add(1)
                        .ok_or(MemoryError::RootCensusOverflow)?;
                    census.root_registrations = census
                        .root_registrations
                        .checked_add(object.roots)
                        .ok_or(MemoryError::RootCensusOverflow)?;
                }
            }
        }
        Ok(())
    }

    /// Reads one checked reference slot of a live managed object.
    pub fn reference(&self, owner: Handle, index: usize) -> Result<Option<Handle>, MemoryError> {
        let region = self
            .region(owner.region)
            .map_err(|_| MemoryError::InvalidHandle)?;
        let slot = region
            .slots
            .get(owner.slot)
            .ok_or(MemoryError::InvalidHandle)?;
        if slot.generation != owner.generation {
            return Err(MemoryError::InvalidHandle);
        }
        let object = slot.object.as_ref().ok_or(MemoryError::InvalidHandle)?;
        let references = object.references.as_ref().ok_or(MemoryError::NotObject)?;
        references
            .get(index)
            .copied()
            .ok_or(MemoryError::InvalidReferenceSlot)
    }

    /// Replaces or clears a checked reference without allocating or collecting.
    pub fn set_reference(
        &mut self,
        owner: Handle,
        index: usize,
        target: Option<Handle>,
    ) -> Result<(), MemoryError> {
        self.reference(owner, index)?;
        if let Some(target) = target {
            self.read_bytes(target)?;
            if owner.region != target.region {
                return Err(MemoryError::CrossRegionEdge);
            }
        }
        self.object_mut(owner)?
            .references
            .as_mut()
            .expect("validated managed object")[index] = target;
        Ok(())
    }

    pub fn link(&mut self, parent: Handle, child: Handle) -> Result<(), MemoryError> {
        self.read_bytes(parent)?;
        self.read_bytes(child)?;
        if parent.region != child.region {
            return Err(MemoryError::CrossRegionEdge);
        }
        let (old_len, old_capacity) = {
            let r = self.region(parent.region)?;
            let object = r.slots[parent.slot]
                .object
                .as_ref()
                .ok_or(MemoryError::InvalidHandle)?;
            if object.edges.contains(&child) {
                return Ok(());
            }
            (object.edges.len(), object.edges.capacity())
        };
        if old_len < old_capacity {
            self.object_mut(parent)?.edges.push(child);
            return Ok(());
        }
        if let Err(error) = self.check_budgets(EDGE_METADATA_BYTES) {
            self.region_mut(parent.region)?.stats.allocation_failures += 1;
            return Err(MemoryError::Allocation(error));
        }
        let remaining = {
            let r = self.region(parent.region)?;
            r.limit_bytes.saturating_sub(r.stats.committed_bytes)
        };
        if EDGE_METADATA_BYTES > remaining {
            self.region_mut(parent.region)?.stats.allocation_failures += 1;
            return Err(MemoryError::Allocation(AllocationError::RegionLimit));
        }
        let mut edges = Vec::new();
        let needed = old_len.checked_add(1).ok_or_else(|| {
            self.region_mut(parent.region)
                .expect("validated region")
                .stats
                .allocation_failures += 1;
            MemoryError::Allocation(AllocationError::HostAllocation)
        })?;
        if self.fault.before_reserve(ReserveSite::Edges).is_err()
            || edges.try_reserve_exact(needed).is_err()
        {
            self.region_mut(parent.region)?.stats.allocation_failures += 1;
            return Err(MemoryError::Allocation(AllocationError::HostAllocation));
        }
        let added = edges
            .capacity()
            .checked_sub(old_capacity)
            .and_then(|count| count.checked_mul(EDGE_METADATA_BYTES))
            .ok_or_else(|| {
                self.region_mut(parent.region)
                    .expect("validated region")
                    .stats
                    .allocation_failures += 1;
                MemoryError::Allocation(AllocationError::HostAllocation)
            })?;
        let budget_charge = edges
            .capacity()
            .checked_mul(EDGE_METADATA_BYTES)
            .ok_or_else(|| {
                self.region_mut(parent.region)
                    .expect("validated region")
                    .stats
                    .allocation_failures += 1;
                MemoryError::Allocation(AllocationError::HostAllocation)
            })?;
        if let Err(error) = self.check_budgets(budget_charge) {
            self.region_mut(parent.region)?.stats.allocation_failures += 1;
            return Err(MemoryError::Allocation(error));
        }
        if added > remaining {
            self.region_mut(parent.region)?.stats.allocation_failures += 1;
            return Err(MemoryError::Allocation(AllocationError::RegionLimit));
        }
        let r = self.region_mut(parent.region)?;
        let object = r.slots[parent.slot]
            .object
            .as_mut()
            .ok_or(MemoryError::InvalidHandle)?;
        edges.extend_from_slice(&object.edges);
        edges.push(child);
        object.edges = edges;
        object.charge += added;
        r.stats.committed_bytes += added;
        r.stats.live_bytes += added;
        r.stats.peak_bytes = r.stats.peak_bytes.max(r.stats.committed_bytes);
        self.charge_budgets(budget_charge);
        Ok(())
    }

    pub fn close_region(&mut self, region: RegionId) -> Result<(), MemoryError> {
        let r = self.region_mut(region)?;
        if r.slots
            .iter()
            .any(|slot| slot.object.as_ref().is_some_and(|object| object.roots > 0))
        {
            return Err(MemoryError::RegionHasRoots);
        }
        r.slots = Vec::new();
        r.stats.committed_bytes = 0;
        r.stats.live_bytes = 0;
        r.closed = true;
        Ok(())
    }

    pub fn collect(&mut self, region: RegionId) -> Result<(), MemoryError> {
        if !self.budgets.is_empty() {
            return Err(MemoryError::CollectionForbidden);
        }
        let r = self.region_mut(region)?;
        let started = Instant::now();
        for slot in &mut r.slots {
            slot.marked = slot.object.as_ref().is_some_and(|object| object.roots > 0);
        }
        loop {
            let mut changed = false;
            for i in 0..r.slots.len() {
                if !r.slots[i].marked {
                    continue;
                }
                let edge_count = r.slots[i]
                    .object
                    .as_ref()
                    .map_or(0, |object| object.edges.len());
                let reference_count = r.slots[i]
                    .object
                    .as_ref()
                    .and_then(|object| object.references.as_ref())
                    .map_or(0, Vec::len);
                for j in 0..edge_count + reference_count {
                    let object = r.slots[i].object.as_ref().expect("marked slot occupied");
                    let child = if j < edge_count {
                        Some(object.edges[j])
                    } else {
                        object.references.as_ref().expect("reference count nonzero")[j - edge_count]
                    };
                    let Some(child) = child else { continue };
                    if child.region != region {
                        continue;
                    }
                    let Some(target) = r.slots.get_mut(child.slot) else {
                        continue;
                    };
                    if target.generation == child.generation
                        && target.object.is_some()
                        && !target.marked
                    {
                        target.marked = true;
                        changed = true;
                    }
                }
            }
            if !changed {
                break;
            }
        }
        let mut collected = 0;
        for slot in &mut r.slots {
            if slot.object.is_some() && !slot.marked {
                let object = slot.object.take().expect("occupied slot");
                collected += object.charge;
                slot.generation = slot.generation.saturating_add(1);
            }
            slot.marked = false;
        }
        r.stats.committed_bytes -= collected;
        r.stats.live_bytes -= collected;
        r.stats.total_collected_bytes += collected;
        r.stats.collection_count += 1;
        r.pause.record(started.elapsed().as_nanos());
        Ok(())
    }
}

#[cfg(test)]
mod root_census_tests {
    use super::*;

    #[test]
    fn registration_sum_overflow_is_reported() {
        let mut session = Session::new();
        let region = session.default_region();
        let first = session.alloc_bytes(region, 1).unwrap();
        let second = session.alloc_bytes(region, 1).unwrap();
        session.regions[region.index].slots[first.slot]
            .object
            .as_mut()
            .unwrap()
            .roots = usize::MAX;
        session.root(second).unwrap();
        assert_eq!(
            session.root_census_region(region),
            Err(MemoryError::RootCensusOverflow)
        );
        assert_eq!(session.root_census(), Err(MemoryError::RootCensusOverflow));
    }
}

}
use cgx2_runtime::default_managed::model::{*,Shape::*,Op::*,Statement::*};
fn main() {
    let program=Program{strings:vec!["i64".into(),"Bool".into(),"Unit".into(),"String".into(),"cgx2.managed.Ref<i64>".into(),"cell".into(),"cgx2.core.Result<cgx2.managed.Ref<i64>, cgx2.core.AllocationError>".into(),"Ok".into(),"cgx2.core.AllocationError".into(),"Err".into(),"outcome".into(),"main".into(),"result".into(),"ManagedAlloc".into()],layouts:vec![Layout { name: 0, shape: KInt }, Layout { name: 1, shape: KBool }, Layout { name: 2, shape: KUnit }, Layout { name: 3, shape: KString }, Layout { name: 4, shape: KRef(0) }, Layout { name: 6, shape: KVariant(vec![(7, vec![4]), (9, vec![6])]) }, Layout { name: 8, shape: KError }],expressions:vec![Expression { ty: 0, loc: Loc { start: 67, end: 68 }, op: EInt(1) }, Expression { ty: 4, loc: Loc { start: 55, end: 69 }, op: ERef(0) }, Expression { ty: 4, loc: Loc { start: 133, end: 137 }, op: ELocal(5) }, Expression { ty: 5, loc: Loc { start: 115, end: 138 }, op: ETry(2) }, Expression { ty: 0, loc: Loc { start: 143, end: 145 }, op: EInt(42) }],functions:vec![Function { name: 11, parameters: vec![], parameter_types: vec![], result: 0, behavioral_effects: vec![13], capabilities: vec![], requires: vec![], ensures: vec![], result_name: 12, body: vec![SLet(5, 1), SGuard(63, Loc { start: 74, end: 143 }, vec![SLet(10, 3)]), SExpr(4)], effects: MemoryEffectsV1 { may_allocate_managed: true, may_auto_collect_at_allocation: true, may_explicitly_collect: false, may_allocate_root_bookkeeping: true }, loc: Loc { start: 0, end: 146 } }],entry:0,schema_version:1,root_maps:vec![RootMapV1 { expression: 0, operands: vec![], may_allocate_managed: false, root_result: false }, RootMapV1 { expression: 1, operands: vec![0], may_allocate_managed: true, root_result: true }, RootMapV1 { expression: 2, operands: vec![], may_allocate_managed: false, root_result: true }, RootMapV1 { expression: 3, operands: vec![2], may_allocate_managed: false, root_result: true }, RootMapV1 { expression: 4, operands: vec![], may_allocate_managed: false, root_result: false }],output_loc:Loc { start: 0, end: 146 }};
    let args=std::env::args().skip(1).collect::<Vec<_>>();
    #[cfg(feature="fault-injection")]
    let execution=if let Some(index)=option_env!("CGX2_TEST_FAIL_RESERVE").and_then(|n|n.parse::<usize>().ok()) {
        match cgx2_runtime::Session::try_new_with_host_failure_at_reserve(index) {
            Ok(session)=>cgx2_runtime::default_managed::run_with_session(&program,&args,session),
            Err(error)=>{let loc=program.functions[program.entry].loc;eprintln!("CGR090: managed session entry failed: {error:?} at {}..{}",loc.start,loc.end);std::process::exit(1)}
        }
    } else {cgx2_runtime::default_managed::run(&program,&args)};
    #[cfg(not(feature="fault-injection"))]
    let execution=cgx2_runtime::default_managed::run(&program,&args);
    if std::env::var_os("CGX2_MANAGED_EVIDENCE").is_some() { eprintln!("CGX2_MANAGED_EVIDENCE {}",execution.evidence.json(&execution.memory)); }
    match execution.result {Ok(value)=>{let shown=value.to_string();if true{println!("{shown}");}},Err(error)=>{eprintln!("{}: {} at {}..{}",error.code,error.message,error.loc.start,error.loc.end);std::process::exit(1)}}
}
