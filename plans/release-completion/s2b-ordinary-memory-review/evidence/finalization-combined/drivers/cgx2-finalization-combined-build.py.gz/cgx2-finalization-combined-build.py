from pathlib import Path
import os, json, subprocess, hashlib
root=Path('/home/john-riley/.codex/worktrees/wave21-coordinator-review/lang')
out=Path('/home/john-riley/projects/lang/target/ordinary-finalization-combined-20261024')
out.mkdir(exist_ok=False)
env=dict(os.environ,RUSTUP_TOOLCHAIN='1.98.1',CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TARGET_DIR=str(out/'cargo'),TMPDIR=str(out/'tmp'),LIBRARY_PATH='/tmp/cgx2-wave22-lib',PYTHONDONTWRITEBYTECODE='1')
Path(env['TMPDIR']).mkdir()
script=root/'crates/cgx2-syntax/ordinary-parity-repair-evidence/verify.py'
cmd=['python3','-u',str(script),'--output-dir',str(out/'verification')]
record={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'dirty':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),'argv':cmd,'cwd':str(root),'environment':{k:env[k] for k in ('RUSTUP_TOOLCHAIN','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_TARGET_DIR','TMPDIR','LIBRARY_PATH','PYTHONDONTWRITEBYTECODE')},'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'limitation':'Harness reviewed_base hardcodes89464a7; authoritative current source identity is this wrapper plus exact source.json. Finalization defects remain open; raw outcomes independently audited.'}
(out/'coordinator-invocation.json').write_text(json.dumps(record,indent=2)+'\n')
with (out/'driver.log').open('wb') as log:
 result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
record['exit']=result.returncode
(out/'coordinator-invocation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'exit':result.returncode,'output':str(out)}),flush=True)
raise SystemExit(result.returncode)
