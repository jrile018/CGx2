import os, sys, runpy
from pathlib import Path
lane=Path('/home/john-riley/.codex/worktrees/wave21-coordinator-review/lang/crates/cgx2-syntax/ordinary-recovery-roots-evidence')
sys.path.insert(0,str(lane.parent/'ordinary-parity-repair-evidence'))
sys.path.insert(0,str(lane))
import common
original=common.Journal.__init__
def init(self,output):
 original(self,output)
 for k in ('CARGO_TARGET_DIR','TMPDIR'):self.env[k]=os.environ[k];self.report['environment'][k]=os.environ[k]
 self.report['coordinator_source_commit']=os.environ['CGX2_COORDINATOR_SOURCE']
 self.report['adapter_note']='Only private target/TMPDIR and actual coordinator source identity added; original expectations unchanged.'
 self.save()
common.Journal.__init__=init
script=lane/sys.argv[1];sys.argv=[str(script),*sys.argv[2:]]
runpy.run_path(str(script),run_name='__main__')
