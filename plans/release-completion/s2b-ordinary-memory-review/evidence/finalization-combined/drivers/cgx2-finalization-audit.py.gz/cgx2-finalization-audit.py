from pathlib import Path
import json,re,hashlib,sys
r=Path('/home/john-riley/.codex/worktrees/wave21-coordinator-review/lang');out=Path('/home/john-riley/projects/lang/target/ordinary-finalization-combined-20261024')
external=Path('/home/john-riley/.codex/visualizations/2026/10/23/01a167e4-6669-7803-b925-af52f00fe0f7/ordinary-finalization-combined-20261024')
result={'reports':{},'abnormal_commands':[],'stream_mismatches':[],'sentinel_diagnostics':[],'artifact_identity_errors':[]}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inspect(value,path):
 if isinstance(value,dict):
  if 'reason' in value and ('argv' in value or 'name' in value) and value['reason']!='exit':result['abnormal_commands'].append({'path':path,'name':value.get('name'),'reason':value['reason']})
  for s in ('stdout','stderr'):
   if isinstance(value.get(s),str) and s+'_sha256' in value:
    raw=value[s].encode();actual=hashlib.sha256(raw).hexdigest()
    if actual!=value[s+'_sha256'] or (s+'_bytes' in value and len(raw)!=value[s+'_bytes']):result['stream_mismatches'].append([path,value.get('name'),s])
  for k,v in value.items():inspect(v,path+'/'+k)
 elif isinstance(value,list):
  for i,v in enumerate(value):inspect(v,path+'/'+str(i))
for name,path in [('verification',out/'verification/report.json'),*[(n,out/n/'report.json') for n in ('matrix','auto','historical','package','review','recovery','recovery-reconciled','legacy-reconciliation')],('nominal',external/'nominal/report.json'),('admission',external/'admission/report.json')]:
 if not path.exists():result['reports'][name]={'missing':str(path)};continue
 d=json.loads(path.read_text());checks=d.get('checks',d.get('assertions',[]));result['reports'][name]={'path':str(path),'sha256':sha(path),'passed':sum(c.get('passed') is True for c in checks),'failed':sum(c.get('passed') is not True for c in checks),'failures':[c for c in checks if c.get('passed') is not True],'complete':d.get('complete'),'coverage_errors':d.get('coverage_errors'),'exceptions':d.get('exceptions',[]),'product_summary':d.get('product_summary')};inspect(d,name)
 if name=='verification':
  raw=''.join(x.get('stdout','')+x.get('stderr','') for x in d['commands'] if x['name']=='workspace-tests');counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',raw);result['workspace_counts']={k:sum(int(v[i]) for v in counts) for k,i in [('passed',0),('failed',1),('ignored',2)]}
 if name in ('matrix','package'):
  for cmd in d['commands']:
   n=cmd['name']
   if (name=='matrix' and any(n==case+'-'+operation for case in ('cross-region','cross-region-utf8','fallback-resource','dependency') for operation in ('build','emit-rust','emit-python'))) or (name=='package' and n.endswith('-python')):
    codes=re.findall(r'^([A-Z][A-Z0-9]*\d{3}):',cmd.get('stderr',''),re.M)
    result['sentinel_diagnostics'].append({'report':name,'name':n,'reason':cmd['reason'],'exit':cmd.get('exit'),'signal':cmd.get('signal'),'stdout':cmd.get('stdout'),'stderr':cmd.get('stderr'),'primary_codes':codes,'single_primary':len(codes)==1})
sys.path.insert(0,str(r/'crates/cgx2-syntax/ordinary-parity-repair-evidence'))
from integrity import verify_inputs
_,errors=verify_inputs(out/'verification/frozen',json.loads((out/'verification/inputs.json').read_text()));result['artifact_identity_errors']=errors
(out/'coordinator-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('reports','sentinel_diagnostics')},indent=2));print({k:(v.get('passed'),v.get('failed'),v.get('missing')) for k,v in result['reports'].items()});print('sentinels',len(result['sentinel_diagnostics']),all(x['single_primary'] for x in result['sentinel_diagnostics']))
