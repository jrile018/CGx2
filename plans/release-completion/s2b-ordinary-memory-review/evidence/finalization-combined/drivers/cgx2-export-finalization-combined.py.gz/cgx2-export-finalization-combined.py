from pathlib import Path
import os,json,gzip,hashlib,subprocess
r=Path('/home/john-riley/.codex/worktrees/wave21-coordinator-review/lang');raw=Path('/home/john-riley/projects/lang/target/ordinary-finalization-combined-20261024')
external=Path('/home/john-riley/.codex/visualizations/2026/10/23/01a167e4-6669-7803-b925-af52f00fe0f7/ordinary-finalization-combined-20261024')
dest=r/'plans/release-completion/s2b-ordinary-memory-review/evidence/finalization-combined';dest.mkdir(exist_ok=False)
manifest=[];executables={};sha=lambda b:hashlib.sha256(b).hexdigest()
def retain(path,relative):
 data=path.read_bytes();compressed=gzip.compress(data,mtime=0);target=dest/(str(relative)+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(compressed)
 manifest.append({'source':str(path),'archive':str(target.relative_to(dest)),'bytes':len(data),'sha256':sha(data),'compressed_bytes':len(compressed),'compressed_sha256':sha(compressed)})
for base,label in [(raw,'coordinator'),(external,'external')]:
 for folder,dirs,files in os.walk(base):
  dirs[:]=[d for d in dirs if d not in ('cargo','tmp','frozen','__pycache__')]
  for name in files:
   path=Path(folder)/name
   if path.is_file() and path.stat().st_mode & 0o111:executables[str(path)]={'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size,'resolved':str(path.resolve())}
   if path.suffix in ('.json','.py','.rs','.cg','.toml','.log','.gz'):retain(path,Path(label)/path.relative_to(base))
for name in ('cgx2-finalization-combined-build.py','cgx2-finalization-products.py','cgx2-private-recovery-invoke.py','cgx2-finalization-audit.py','cgx2-export-finalization-combined.py'):
 retain(Path('/home/john-riley/projects/lang/target')/name,Path('drivers')/name)
for row in manifest:
 data=(dest/row['archive']).read_bytes();assert sha(data)==row['compressed_sha256'];assert sha(gzip.decompress(data))==row['sha256']
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(dest/'executables.json').write_text(json.dumps(executables,indent=2)+'\n')
audit=json.loads((raw/'coordinator-audit.json').read_text());inv=json.loads((raw/'coordinator-invocation.json').read_text())
expected=json.loads((raw/'verification/source.json').read_text());changed=[name for name,digest in expected.items() if not (r/name).is_file() or sha((r/name).read_bytes())!=digest]
accept={'source_commit':inv['source_commit'],'compiler_inputs_changed':changed,'environment':inv['environment'],'workspace_counts':audit['workspace_counts'],'reports':audit['reports'],'abnormal_commands':audit['abnormal_commands'],'stream_mismatches':audit['stream_mismatches'],'artifact_identity_errors':audit['artifact_identity_errors'],'archives':len(manifest),'raw_root':str(raw),'external_root':str(external),'runtime_recovery_bounded_review':True,'harness_accepted':False,'ordinary_memory_accepted':False,'release_accepted':False,'limits':['Main static dependency filename remains failed.','Historical reports preserve removed-root reserve expectation failures; separate reconciliation does not rewrite history.','Harness diagnostic/finalization/provenance defects require the planned bounded repair.','Journal reviewed_base89464a7 is stale; actual source ded3768 is recorded by coordinator-invocation plus all compiler hashes.','No live solver, leak-enabled memory, scored isolation, library/runtime external, GPU or paired human/model acceptance is implied.']}
(dest/'acceptance.json').write_text(json.dumps(accept,indent=2)+'\n')
print(json.dumps({'archives':len(manifest),'compiler_inputs_changed':changed,'destination':str(dest)},indent=2))
