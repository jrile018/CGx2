from pathlib import Path
import os,sys,json,gzip,hashlib,resource
r=Path('/home/john-riley/.codex/worktrees/wave21-coordinator-review/lang')
out=Path('/home/john-riley/projects/lang/target/ordinary-finalization-combined-20261024')
b=out/'verification/frozen';here=r/'crates/cgx2-syntax/ordinary-parity-repair-evidence'
external=Path('/home/john-riley/.codex/visualizations/2026/10/23/01a167e4-6669-7803-b925-af52f00fe0f7/ordinary-finalization-combined-20261024');external.mkdir(exist_ok=False)
sys.path.insert(0,str(r/'crates/cgx2-syntax/owned-result-runner-evidence'))
from supervisor import supervise,evidence
inv=json.loads((out/'coordinator-invocation.json').read_text())
env={**os.environ,**inv['environment'],'CGX2_COORDINATOR_SOURCE':inv['source_commit']}
report={'source_commit':inv['source_commit'],'external_root':str(external),'checks':[],'known_limits':'Harness finalization and provenance defects remain open. Independent command, diagnostic and integrity audit required. No broader acceptance.'}
def save():(out/'products.json').write_text(json.dumps(report,indent=2)+'\n')
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,)*2);resource.setrlimit(resource.RLIMIT_CPU,(3600,)*2);resource.setrlimit(resource.RLIMIT_FSIZE,(512*1024**2,)*2)
def run(name,cmd):
 argv=list(map(str,cmd));row={'name':name,'argv':argv,'cwd':str(r),'reason':'pending'};report['checks'].append(row);save();print('start',name,flush=True)
 result=supervise(argv,cwd=r,env=env,limits=limits,cap=8*1024**2,timeout=2400)
 row.update(evidence(result));save();print('finish',name,row.get('reason'),row.get('exit'),flush=True)
py=sys.executable
for name,cmd in [
 ('matrix',[py,here/'run.py','--binary-dir',b,'--output-dir',out/'matrix','--standalone-root',external]),
 ('auto',[py,here/'auto.py','--binary-dir',b,'--output-dir',out/'auto','--standalone-root',external]),
 ('historical',[py,here/'replay.py','--binary-dir',b,'--output-dir',out/'historical','--standalone-root',external]),
 ('package',[py,here/'package_parity.py','--binary-dir',b,'--historical-product',out/'historical/product','--output-dir',out/'package','--standalone-root',external]),
 ('review',[py,here/'review.py','--binary-dir',b,'--matrix-report',out/'matrix/report.json','--output-dir',out/'review']),
 ('nominal',[py,r/'crates/cgx2-syntax/ordinary-borrow-repair-evidence/run.py','--binary-dir',b,'--output-dir',external/'nominal']),
 ('admission',[py,r/'crates/cgx2-syntax/ordinary-admission-repair-evidence/run.py','--binary-dir',b,'--output-dir',external/'admission']),
 ('recovery',[py,'/home/john-riley/projects/lang/target/cgx2-private-recovery-invoke.py','run.py','--binary-dir',b,'--matrix-report',out/'matrix/report.json','--output-dir',out/'recovery','--standalone-root',external])]:run(name,cmd)
sys.path.insert(0,str(here))
from integrity import verify_inputs
expected=json.loads((out/'verification/inputs.json').read_text());_,errors=verify_inputs(b,expected);report['final_integrity_errors']=errors
save();print('product pass complete; raw failures require audit',flush=True)
