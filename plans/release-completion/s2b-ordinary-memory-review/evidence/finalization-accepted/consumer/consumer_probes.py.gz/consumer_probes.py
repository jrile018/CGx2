"""Independent consumer probes; no Cargo, builds, or edits to reviewed source."""
import copy,json,pathlib,sys,unittest
from unittest.mock import patch
ROOT=pathlib.Path("/home/john-riley/.codex/worktrees/9929/lang")
OUT=pathlib.Path("/home/john-riley/projects/lang/target/finalization-delivery-review-20261024/consumer")
sys.path.insert(0,str(ROOT/"crates/cgx2-syntax/ordinary-parity-repair-evidence"))
import common,finalize
from common import Journal
from validation import sentinel_status
results=[]
for case in ("schema_and_streams_removed","row_removed","executable_removed","signal"):
 j=Journal(OUT/("probe-"+case))
 row=j.run("actual-command",[sys.executable,"-c","print(42)"])
 if case=="schema_and_streams_removed":
  j.report.pop("command_record_schema")
  j.report["commands"]=[{k:row[k] for k in ("name","reason","exit","signal")}]
 elif case=="row_removed": j.report["commands"]=[]
 elif case=="executable_removed": row.pop("executable_input")
 else: row["reason"]="signal";row["exit"]=-15;row["signal"]=15
 j.required_commands=set()
 status=j.finish()
 results.append(dict(case=case,status=status,complete=j.report["complete"],errors=j.report["coverage_errors"]))
 assert status==1 and j.report["complete"] is False
for case in ("valid","duplicate","mixed","prose"):
 j=Journal(OUT/("sentinel-"+case));p=j.output/"sentinel";p.write_bytes(b"prior")
 stderr={"valid":"CGE006: unsupported\n","duplicate":"CGE006: unsupported\n"*2,"mixed":"CGXC005: failed\nCGE006: unsupported\n","prose":"CGXC005: mentions CGE006\n"}[case]
 row=j.run("diagnostic",[sys.executable,"-c",f"import sys;sys.stderr.write({stderr!r});sys.exit(1)"])
 result=sentinel_status(row,p,b"prior","CGE006")
 results.append(dict(case="sentinel-"+case,result=result))
 assert result==(case=="valid",True)
 j.check("expectation",result==(case=="valid",True));assert j.finish()==0
original_run=Journal.run
for case in ("incomplete","missing","control"):
 scratch=OUT/("driver-"+case)
 def fake_run(self,name,argv,**kwargs):
  row=original_run(self,name,[sys.executable,"-c","pass"])
  child=scratch/name;child.mkdir(parents=True,exist_ok=True)
  if not (case=="missing" and name=="auto"):
   (child/"report.json").write_text(json.dumps({"complete":not(case=="incomplete" and name=="auto"),"passed":1,"failed":0,"exceptions":[],"coverage_errors":[]}))
  return row
 args=["finalize.py","--coordinator-dir",str(OUT),"--build-source-commit","ded3768480c745ce544d33c56aea44d4fc0bfa5a","--reviewed-base","9f0804feac1a3c549ed879a8738e0152b370ed4a","--scratch-dir",str(scratch),"--standalone-root",str(OUT)]
 with patch.object(Journal,"run",fake_run),patch.object(finalize,"audit",return_value=True),patch.object(sys,"argv",args):
  status=finalize.main()
 report=json.loads((scratch/"driver/report.json").read_text())
 results.append(dict(case="child-"+case,status=status,complete=report["complete"],errors=report["coverage_errors"]))
 assert status==(0 if case=="control" else 1)
 assert report["complete"]==(case=="control")
(OUT/"consumer-probes.result.json").write_text(json.dumps(results,indent=2)+"\n")
print(json.dumps({"probes":len(results),"passed":len(results)}))
