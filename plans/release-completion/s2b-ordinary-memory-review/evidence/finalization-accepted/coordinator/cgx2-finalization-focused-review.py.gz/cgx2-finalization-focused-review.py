from pathlib import Path
import os,sys,json,gzip,hashlib,resource
root=Path('/home/john-riley/.codex/worktrees/wave21-coordinator-review/lang')
out=Path('/home/john-riley/projects/lang/target/finalization-delivery-review-20261024/integration')
out.mkdir(exist_ok=False)
prior=Path('/home/john-riley/projects/lang/target/ordinary-finalization-combined-20261024')
here=root/'crates/cgx2-syntax/ordinary-parity-repair-evidence'
external=Path('/home/john-riley/.codex/visualizations/2026/10/23/01a167e4-6669-7803-b925-af52f00fe0f7/ordinary-finalization-focused-20261024')
external.mkdir(exist_ok=False)
(out/'tmp').mkdir()
sys.path.insert(0,str(root/'crates/cgx2-syntax/owned-result-runner-evidence'))
from supervisor import supervise,evidence
env={**os.environ,**json.loads((prior/'coordinator-invocation.json').read_text())['environment'],'TMPDIR':str(out/'tmp'),'CARGO_TARGET_DIR':str(out/'cargo')}
report={'purpose':'Coordinator focused integration of harness-only delivery; exact unchanged ded3768 compiler, no rebuild','checks':[],'external_root':str(external)}
def save(): (out/'integration.json').write_text(json.dumps(report,indent=2)+'\n')
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,)*2)
 resource.setrlimit(resource.RLIMIT_CPU,(1800,)*2)
 resource.setrlimit(resource.RLIMIT_FSIZE,(512*1024**2,)*2)
def run(name,argv):
 row={'name':name,'argv':list(map(str,argv)),'cwd':str(root),'reason':'pending'};report['checks'].append(row);save();print('start',name,flush=True)
 row.update(evidence(supervise(row['argv'],cwd=root,env=env,limits=limits,cap=8*1024**2,timeout=1800)))
 save();print('finish',name,row.get('reason'),row.get('exit'),flush=True)
 if row.get('reason')!='exit' or row.get('exit')!=0: raise SystemExit(1)
py=sys.executable
run('freeze',[py,here/'freeze.py','--verification-dir',prior/'verification','--build-invocation',prior/'coordinator-invocation.json','--build-source-commit','ded3768480c745ce544d33c56aea44d4fc0bfa5a','--output-dir',out/'verification'])
b=out/'verification/frozen'
run('auto',[py,here/'auto.py','--binary-dir',b,'--output-dir',out/'auto','--standalone-root',external])
run('package',[py,here/'package_parity.py','--binary-dir',b,'--historical-product',prior/'historical/product','--output-dir',out/'package','--standalone-root',external])
archive=here/'finalization-evidence/run-3/attempts/matrix/report.json.gz'
raw=gzip.decompress(archive.read_bytes());matrix=out/'audited-worker-matrix.json';matrix.write_bytes(raw)
report['reused_matrix']={'archive':str(archive),'compressed_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'sha256':hashlib.sha256(raw).hexdigest(),'scope':'Worker fresh main964/1 independently audited; exact compiler/harness snapshot unchanged; dependency filename remains failed'};save()
run('review',[py,here/'review.py','--binary-dir',b,'--matrix-report',matrix,'--output-dir',out/'review'])
sys.path.insert(0,str(here))
from integrity import verify_inputs
_,errors=verify_inputs(b,json.loads((out/'verification/inputs.json').read_text()))
report['final_integrity_errors']=errors;save()
if errors:raise SystemExit(1)
print('focused integration complete',flush=True)
