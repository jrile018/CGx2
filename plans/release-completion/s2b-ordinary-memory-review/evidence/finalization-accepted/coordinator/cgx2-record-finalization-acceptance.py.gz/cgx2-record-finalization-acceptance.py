from pathlib import Path
import os,json,gzip,hashlib,sys,subprocess,datetime
root=Path('/home/john-riley/.codex/worktrees/wave21-coordinator-review/lang')
scratch=Path('/home/john-riley/projects/lang/target/finalization-delivery-review-20261024')
here=root/'crates/cgx2-syntax/ordinary-parity-repair-evidence'
out=root/'plans/release-completion/s2b-ordinary-memory-review/evidence/finalization-accepted'
out.mkdir(exist_ok=False)
sys.path.insert(0,str(here))
from validation import inventory_errors
from integrity import verify_inputs
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=[];summaries={};artifacts=0;commands=0
for name in ('verification','auto','package','review'):
 p=scratch/'integration'/name/'report.json';d=json.loads(p.read_text());req=d['required_inventory']
 errors=inventory_errors(d,set(req['commands']),set(req['checks']))
 assert not errors and d['complete'] and not d['failed'] and not d['exceptions'],(name,errors)
 commands+=len(d['commands'])
 for c in d['commands']:
  for stream in ('stdout','stderr'):
   raw=c[stream].encode();assert hashlib.sha256(raw).hexdigest()==c[stream+'_sha256'];assert len(raw)==c[stream+'_bytes']
 for field in ('artifacts','standalone_artifacts'):
  for tag,a in d.get(field,{}).items():
   assert sha(a['path'])==a['sha256'],tag;artifacts+=1
   if a.get('source'):assert sha(a['source'])==a['source_sha256']
 summaries[name]={k:d[k] for k in ('passed','failed','complete','coverage_errors','exceptions')}
frozen=scratch/'integration/verification/frozen'
_,errors=verify_inputs(frozen,json.loads((frozen.parent/'inputs.json').read_text()));assert not errors,errors
ext=Path(json.loads((scratch/'integration/integration.json').read_text())['external_root'])
clean_env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
for p in (ext,ext/'auto',ext/'package'):
 if p.is_dir():
  result=subprocess.run(['git','rev-parse','--is-inside-work-tree'],cwd=p,env=clean_env,capture_output=True,text=True)
  assert result.returncode==128,(p,result.stdout,result.stderr)
manifest=[]
def archive(p,relative):
 raw=p.read_bytes();z=gzip.compress(raw,mtime=0);dest=out/(str(relative)+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z)
 assert gzip.decompress(dest.read_bytes())==raw
 manifest.append({'archive':str(dest.relative_to(out)),'source':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'compressed_bytes':len(z),'compressed_sha256':hashlib.sha256(z).hexdigest()})
for directory in ('consumer','runtime','integration'):
 for p in sorted((scratch/directory).rglob('*')):
  if p.is_symlink() or not p.is_file():continue
  relative=p.relative_to(scratch)
  if any(part in ('frozen','cargo','tmp','scratch','__pycache__') for part in relative.parts):continue
  if p.suffix in ('.py','.md','.json','.txt','.log','.cg','.rs','.toml'):archive(p,relative)
for p in sorted(ext.rglob('*.rs')):archive(p,Path('external-source')/p.relative_to(ext))
for name in ('cgx2-finalization-focused-review.py','cgx2-record-finalization-acceptance.py','finalization-focused-driver.log'):
 p=Path('/home/john-riley/projects/lang/target')/name;archive(p,Path('coordinator')/name)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
acceptance={'delivery':'4c4f07eb9d69a41ef0ba2d68d116274c59b79d28','integrated_commit':'1e283aa972c49ef0cd9d087f7807f3d61402c691','bounded_harness_accepted':True,'ordinary_memory_accepted':False,'release_accepted':False,'compiler_build_commit':'ded3768480c745ce544d33c56aea44d4fc0bfa5a','compiler_snapshot_sha256':'b20762f59667ba168f4d1dddd4b06d8c9fd045668bfe994fe7ecf744ddf57d6c','harness_snapshot_sha256':'fb6abc3d6a75b5de83f01b1f5ebd11af868c78259a57a7b38d8ba90586863e66','independent_review':{'selftests':77,'additional_production_probes':11,'evidence_audit_checks':46,'delivery_blockers':[]},'coordinator_fresh':summaries,'coordinator_command_count':commands,'coordinator_artifact_observations':artifacts,'coordinator_integrity_errors':errors,'archive_count':len(manifest),'audited_worker_results':{'main':'964/1, exact dependency filename remains failed','historical':'135/1; all18 commands executed; managed670/8 raw; original owned-result523/1 expected negative separate','auto':'34/0','package':'45/0','review':'21/0','quality':'11/0','prior_evidence_files_unchanged':766,'finalization_archive_files':2068},'reused_exact_compiler_evidence':{'workspace':'1383 passed,0 failed,6 ignored','quality':'all-target/all-feature Clippy -D warnings, fmt and build pass','recovery':'515/0','nominal':'243/0','admission':'196/0','separate_legacy_reconciliation':'133/0','original_failed_recovery':'463 checks then exception/nonzero, preserved'},'limitations':['Static dependency filename remains failed; historical stale reserve expectations remain red with separate reconciliation.','Exporter limitation on deliberately malformed synthetic rows remains documented; opaque archive preserves reviewer and malformed inputs.','Reviewer script setup/schema/symlink failures preserved, corrected and distinguished from delivery defects.','Full source aggregates, conversions, authenticated transfer summaries, S3/S4 and all R01-R15 remain required. No rebuild, performance measurement, main merge or release.']}
(out/'acceptance.json').write_text(json.dumps(acceptance,indent=2)+'\n')
state=root/'plans/release-completion/thread-state.json';d=json.loads(state.read_text());d['checked_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
row=d['s2b_ordinary_memory_finalization'][0];row.update(status='reviewed-bounded-repair',commit=acceptance['delivery'],integrated_commit=acceptance['integrated_commit'],afterCursor='3432b942-dd7e-4416-9037-bc13a42be060:5',acceptance_note='Exact-diagnostic, abnormal/missing observation finalization and compiler/harness provenance accepted after77selftests,11independent probes,46evidence checks; coordinator fresh Auto34/0 package45/0 review21/0 and exact candidate freeze6/0. Full ownership/transfer/v3 and R01-R15 remain open. See finalization-accepted/acceptance.json.')
state.write_text(json.dumps(d,indent=2)+'\n')
summary='Harness4c4f07e accepted/integrated1e283aa after independent77selftests/11production probes/46evidence checks and coordinator fresh Auto34/0, package45/0, review21/0, freeze6/0. All inventories, command streams and source/artifact identities pass. Exact ded3768 compiler reused; prior1383Rust/0failed/6ignored and quality, recovery515/0, nominal243/0, admission196/0 evidence remains attributable to that build. Fresh worker main964/1 and historical135/1+nested670/8 remain red; separate133/0 reserve reconciliation remains separate. All766prior evidence files unchanged and2068new worker archive files verified. Reviewer failed attempts preserved. See evidence/finalization-accepted/acceptance.json and its hash-verified archives. Full ordinary-memory, source conversions, authenticated transfer summaries, S3/S4 and R01-R15 stay required; no main merge/release.'
review=root/'plans/release-completion/s2b-ordinary-memory-review/README.md';review.write_text(review.read_text()+'\n## Harness finalization accepted\n\n'+summary+'\n')
readme=root/'plans/release-completion/README.md';text=readme.read_text();start=text.index('Status:');end=text.index('\n',start);text=text[:start]+'Status: ordinary-memory bounded API, admission/nominal, runtime recovery and evidence finalization repairs reviewed and integrated. Fresh coordinator Auto/package/review checks pass on the exact verified compiler. General aggregate ownership and exact dependency source attribution are the next source producer; source conversions and complete transfer authentication follow its accepted interfaces. Full R01–R15, S3/S4 and external acceptance remain open. Main unmerged. See [current review](s2b-ordinary-memory-review/README.md).'+text[end:];readme.write_text(text+'\n### Harness finalization reviewed\n\n'+summary+'\n')
dispatch=root/'plans/release-completion/dispatch.md';dispatch.write_text(dispatch.read_text()+'\n## Harness finalization reviewed and integrated\n\n'+summary+'\n\nThe next sole source frontier is aggregate ownership A; conversions B and all consumers wait for accepted source/storage/summary interfaces. The concrete reviewed plan and dispatch outcome follow before any new chat is counted running.\n')
print(json.dumps({'archives':len(manifest),'commands':commands,'artifact_observations':artifacts,'summaries':summaries}))
