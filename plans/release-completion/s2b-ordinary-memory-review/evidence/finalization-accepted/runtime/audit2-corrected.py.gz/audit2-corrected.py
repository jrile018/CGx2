import pathlib,json,gzip,hashlib,subprocess,re,collections,os,ast
ROOT=pathlib.Path("/home/john-riley/.codex/worktrees/9929/lang");HERE=ROOT/"crates/cgx2-syntax/ordinary-parity-repair-evidence";E=HERE/"finalization-evidence";OUT=pathlib.Path("/home/john-riley/projects/lang/target/finalization-delivery-review-20261024/runtime")
report={"checks":[]}
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open("rb") as f:
  for b in iter(lambda:f.read(1048576),b""):h.update(b)
 return h.hexdigest()
def read(p):
 p=pathlib.Path(p);b=p.read_bytes();return json.loads(gzip.decompress(b) if p.suffix==".gz" else b)
def check(n,b,d=None):report["checks"].append({"name":n,"passed":bool(b),"details":d})
def git(*a,cwd=ROOT):return subprocess.run(["git",*a],cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
inputs=read(E/"run-3/attempts/freeze/inputs.json.gz");c=read(E/"run-3/attempts/freeze/candidate.json.gz");a=read(E/"acceptance.json")
frozen=ROOT/"target/ordinary-harness-finalization/run-3/freeze/frozen"
actual={"."}|{str(p.relative_to(frozen)) for p in frozen.rglob("*")};bad=[]
for rel,v in inputs["artifacts"].items():
 p=frozen/rel
 if v["kind"]=="directory":
  if not p.is_dir():bad.append(rel+":type")
 elif v["kind"]=="file":
  if not p.is_file() or p.stat().st_size!=v["bytes"] or digest(p)!=v["sha256"]:bad.append(rel+":bytes")
 else:bad.append(rel+":unsupported-type")
check("frozen_artifact_tree",not bad and actual==set(inputs["artifacts"]),{"entries":len(actual),"bad":bad,"extra":sorted(actual-set(inputs["artifacts"]))})
deps=[p for p in actual if p.startswith("deps/")];check("frozen_dependency_membership",len(deps)==1368,{"dependencies":len(deps)})
b=c["build"];refs=b["original_references"];orig=read(pathlib.Path(b["original_frozen_directory"]).parent/"frozen.json");prior=pathlib.Path(b["original_frozen_directory"])
bad=[]
for name,h in dict(orig["binary_sha256"],**orig["probe_library_sha256"]).items():
 if digest(prior/name)!=h or digest(frozen/name)!=h:bad.append(name)
check("original_canonical_build_bytes",not bad and len(orig["binary_sha256"])==7 and len(orig["probe_library_sha256"])==5,{"bad":bad})
verify=read(pathlib.Path(b["build_invocation_path"]).parent/"verification/report.json");cmds=verify["commands"]
results={}
for r in cmds:
 ts=re.findall(r"test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored",r.get("stdout","")+r.get("stderr",""))
 results[r["name"]]={"exit":r["exit"],"reason":r["reason"],"argv":r["argv"],"test_totals":[sum(int(t[i]) for t in ts) for i in range(3)]}
report["supplied_build_commands"]=results
workspace=next(x for x in results.values() if x["test_totals"][0]>1000)
check("supplied_workspace_1383_0_6",workspace["test_totals"]==[1383,0,6] and workspace["exit"]==0,workspace["test_totals"])
check("supplied_build_normal_offline_locked",all(x["exit"]==0 and x["reason"]=="exit" for x in results.values()) and all("--offline" in x["argv"] and "--locked" in x["argv"] for x in results.values() if x["argv"][0]=="cargo" and x["argv"][1]!="fmt"))
# Exact names and required observations, derived from saved final reports.
inv=[];commands=[];native=0;standalone=0;modernc=[];bad=[]
for name in ["audit","freeze","matrix","auto","package","review","historical","quality","driver"]:
 d=read(E/f"run-3/attempts/{name}/report.json.gz");needed=d["required_inventory"]
 cn=[r["name"] for r in d["commands"]];kn=[r["name"] for r in d["checks"]]
 valid=len(cn)==len(set(cn)) and len(kn)==len(set(kn)) and set(needed["commands"])<=set(cn) and set(needed["checks"])<=set(kn)
 inv.append({"name":name,"required_commands":len(needed["commands"]),"actual_commands":len(cn),"required_checks":len(needed["checks"]),"actual_checks":len(kn),"valid":valid})
 commands.extend((name,r) for r in d["commands"])
 if name in ["matrix","auto","package"]:
  for label,v in d.get("native_artifacts",{}).items():
   native+=1
   if digest(v["path"])!=v["sha256"]:bad.append(name+":"+label+":native")
  for label,v in d.get("standalone_artifacts",{}).items():
   standalone+=1
   if digest(v["source"])!=v["source_sha256"] or digest(v["binary"])!=v["binary_sha256"]:bad.append(name+":"+label+":standalone")
  modernc.extend((name,r) for r in d["commands"] if "standalone" in r["name"] and (r["name"].endswith("-build") or r["name"].endswith("-run")))
check("final_command_check_inventories",all(r["valid"] for r in inv),inv)
check("modern_generated_hashes",not bad and native==105 and standalone==35,{"native":native,"standalone":standalone,"bad":bad})
cwds=sorted({r["cwd"] for _,r in modernc});outs=[]
for cwd in cwds:
 g=git("rev-parse","--is-inside-work-tree",cwd=cwd);outs.append({"cwd":cwd,"exit":g.returncode,"stderr":g.stderr.decode()})
check("actual_external_standalone_cwds",len(modernc)==70 and len(cwds)==3 and all(x["exit"]==128 for x in outs),{"commands":len(modernc),"cwds":outs})
bad=[name+":"+r["name"] for name,r in commands if r.get("reason")!="exit" or type(r.get("exit")) is not int or r.get("signal") is not None or r.get("overflow_stream") is not None]
check("final_commands_normal_termination",not bad,{"commands":len(commands),"bad":bad})
# Test source identity unchanged; count from real retained unittest results.
q=read(E/"run-3/attempts/quality/report.json.gz");testpaths=[]
for r in q["commands"]:
 for arg in r["argv"]:
  if str(arg).endswith(".py") and ("test_" in pathlib.Path(arg).name):
   p=pathlib.Path(arg);p=p if p.is_absolute() else ROOT/p
   testpaths.append((r["name"],p))
report["test_argvs"]=[{"name":r["name"],"argv":r["argv"]} for r in q["commands"] if "selftests" in r["name"]]
bad=[]
for n,p in testpaths:
 if "adversarial" in n:continue
 g=git("show","9f0804f:"+str(p.relative_to(ROOT)))
 if g.returncode or sha(g.stdout)!=digest(p):bad.append(str(p))
check("unchanged_selftest_sources",not bad,{"files":len(testpaths),"bad":bad})
# Supplied focused results remain separate from fresh run counts.
suproot=pathlib.Path(b["build_invocation_path"]).parent
for name,rel,wanted in [("supplied_recovery","recovery-reconciled/report.json",(515,0)),("supplied_legacy_reconciliation","legacy-reconciliation/report.json",(133,0))]:
 p=suproot/rel
 if p.exists():
  d=read(p);check(name,(d["passed"],d["failed"])==wanted,{"path":str(p),"passed":d["passed"],"failed":d["failed"]})
 else:report.setdefault("unlocated_supplied_reports",[]).append(str(p))
# Validate archive of coordinator supplied attempts independently.
coord=ROOT/"plans/release-completion/s2b-ordinary-memory-review/evidence/finalization-combined";cm=read(coord/"manifest.json");report["coordinator_manifest_type"]=type(cm).__name__
bad=[];num=0
for v in cm:
 rel=v["archive"]
 p=coord/rel;raw=p.read_bytes();decomp=gzip.decompress(raw) if rel.endswith(".gz") else raw
 if sha(decomp)!=v["sha256"] or len(decomp)!=v["bytes"]:bad.append(rel)
 if sha(raw)!=v["compressed_sha256"] or len(raw)!=v["compressed_bytes"]:bad.append(rel+":gzip")
 num+=rel.endswith(".gz")
check("coordinator_archives",not bad and num==536,{"archives":num,"bad":bad})
report["passed"]=sum(c["passed"] for c in report["checks"]);report["failed"]=len(report["checks"])-report["passed"];(OUT/"audit2.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps({"passed":report["passed"],"failed":report["failed"],"failures":[c for c in report["checks"] if not c["passed"]],"unlocated":report.get("unlocated_supplied_reports"),"tests":report["test_argvs"]}))
