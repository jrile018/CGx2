import pathlib,json,gzip,hashlib,re,subprocess
ROOT=pathlib.Path("/home/john-riley/.codex/worktrees/9929/lang");H=ROOT/"crates/cgx2-syntax/ordinary-parity-repair-evidence";E=H/"finalization-evidence";O=pathlib.Path("/home/john-riley/projects/lang/target/finalization-delivery-review-20261024/runtime")
report={"checks":[]}
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
 p=pathlib.Path(p);b=p.read_bytes();return json.loads(gzip.decompress(b) if p.suffix==".gz" else b)
def check(n,ok,d=None):report["checks"].append({"name":n,"passed":bool(ok),"details":d})
audit=read(E/"run-3/attempts/audit/report.json.gz");bad=[];commands=0;old={}
for r in audit["retained_reports"]:
 p=H/r["path"];d=read(p);old[r["path"]]=d;commands+=len(d["commands"])
 if sha(p.read_bytes())!=r["sha256"] or d["complete"]!=r["original_complete"] or d["passed"]!=r["original_passed"] or d["failed"]!=r["original_failed"]:bad.append(r["path"])
check("hardening_report_identity_counts",not bad and commands==422 and len(old)==19,{"reports":len(old),"commands":commands,"bad":bad})
rows=[];bad=[]
for item in audit["retained_sentinel_observations"]:
 d=old[item["report"]];r=next(r for r in d["commands"] if r["name"]==item["name"]);code="CGE006" if r["name"] in ("package-value-python","package-error-python") else "CGT095"
 m=re.fullmatch(r"(CG[A-Z]+[0-9]{3}): [^\r\n]+\n?",r["stderr"])
 valid=r["reason"]=="exit" and type(r["exit"])is int and r["exit"]==1 and r["signal"]is None and r["stdout"]=="" and m is not None and m[1]==code and pathlib.Path(item["actual_sentinel_path"]).read_bytes()==b"prior artifact\n"
 for st in ["stdout","stderr"]:
  valid=valid and len(r[st].encode())==r[st+"_bytes"] and sha(r[st].encode())==r[st+"_sha256"]
 rows.append({"name":r["name"],"code":code,"valid":valid})
 if not valid:bad.append(r["name"])
check("fourteen_actual_diagnostics_sentinels",len(rows)==14 and not bad,rows)
d=read(E/"run-3/attempts/historical/product/product.json.gz");reg=[r for r in d["commands"] if r["name"].startswith("regression-")];mismatch=[]
for r in reg:
 expected=1 if r["name"]=="regression-owned-result-original" else 0
 if r["exit"]!=expected or r["reason"]!="exit" or r["signal"]is not None:mismatch.append(r["name"])
check("eighteen_historical_regressions_preserved",len(reg)==18 and mismatch==["regression-managed-product"],{"count":len(reg),"expected_exit_matches":len(reg)-len(mismatch),"mismatches":mismatch})
sup=pathlib.Path("/home/john-riley/projects/lang/target/ordinary-finalization-combined-20261024")
d=read(sup/"recovery/report.json");check("supplied_recovery_original_exception_retained",d["passed"]==463 and bool(d["exceptions"]),{"passed":d["passed"],"failed":d["failed"],"complete":d["complete"],"exceptions":d["exceptions"]})
oldattempts=[]
for rel in ["run-1/attempts/audit/report.json.gz","run-1/attempts/driver/report.json.gz","run-2/attempts/driver/report.json.gz","setup-and-audits-opaque-1/attempts/independent-final-audit-1/report.json.gz","setup-and-audits-opaque-1/attempts/independent-final-audit-2/report.json.gz","export-gates/attempts/gate-1/report.json.gz"]:
 p=E/rel
 if p.exists():
  d=read(p);oldattempts.append({"path":rel,"passed":d["passed"],"failed":d["failed"],"complete":d["complete"],"exceptions":d.get("exceptions")})
report["retained_attempts"]=oldattempts
check("failed_independent_audit_then_corrected_retained",any(x["passed"]==46 and x["failed"]==5 for x in oldattempts) and any(x["passed"]==51 and x["failed"]==0 for x in oldattempts))
c=read(E/"run-3/attempts/freeze/candidate.json.gz");obs=c["observing_harness"];paths=[line[3:] for line in obs["status"].splitlines() if line.startswith(" M ")]
diff=subprocess.check_output(["git","diff","9f0804f","4c4f07e","--",*paths],cwd=ROOT)
check("actual_observing_tracked_dirty_diff",sha(diff)==obs["tracked_diff_sha256"],{"paths":len(paths),"sha256":sha(diff),"expected":obs["tracked_diff_sha256"]})
report["passed"]=sum(x["passed"] for x in report["checks"]);report["failed"]=len(report["checks"])-report["passed"];(O/"audit3.json").write_text(json.dumps(report,indent=2)+"\n")
summary={"commit":"4c4f07eb9d69a41ef0ba2d68d116274c59b79d28","phase_reports":["audit.json","audit2-final.json","audit3.json"],"checks_passed":0,"checks_failed":0,"delivery_blockers":[],"remaining_product_failures":["dependency-negative-exact-file","historical managed-product: eight unreached reserve expectations; original report remains failed","owned-result-original523/1 explicitly expected historical negative"],"limitations":["Read-only evidence audit; no Cargo, product reruns or project source edits.","Independent audit attempt1 failed on list-shaped coordinator manifest; attempt2 used non-following symlink enumeration and incorrect cargo-identity/artifact schema assumptions. Those audit attempts remain preserved. Corrected final audit uses actual schemas and follows recorded dependency symlink."]}
for rel in summary["phase_reports"]:
 q=read(O/rel);summary["checks_passed"]+=q["passed"];summary["checks_failed"]+=q["failed"];summary["delivery_blockers"] += [x for x in q["checks"] if not x["passed"]]
summary["verdict"]="accept bounded evidence delivery" if not summary["delivery_blockers"] else "review blockers";(O/"review-summary.json").write_text(json.dumps(summary,indent=2)+"\n");print(json.dumps(summary))
