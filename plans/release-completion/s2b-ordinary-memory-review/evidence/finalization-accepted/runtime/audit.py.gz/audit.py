import pathlib,json,gzip,hashlib,subprocess,collections,re
ROOT=pathlib.Path("/home/john-riley/.codex/worktrees/9929/lang")
HERE=ROOT/"crates/cgx2-syntax/ordinary-parity-repair-evidence"
E=HERE/"finalization-evidence"
OUT=pathlib.Path("/home/john-riley/projects/lang/target/finalization-delivery-review-20261024/runtime")
COMMIT="4c4f07eb9d69a41ef0ba2d68d116274c59b79d28";BASE="9f0804feac1a3c549ed879a8738e0152b370ed4a"
report={"commit":COMMIT,"checks":[]}
def sha(data):return hashlib.sha256(data).hexdigest()
def file_sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open("rb") as f:
  for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
 return h.hexdigest()
def check(name,ok,details=None):
 report["checks"].append({"name":name,"passed":bool(ok),"details":details})
def git(*args):return subprocess.check_output(["git",*args],cwd=ROOT)
def read(p):
 b=pathlib.Path(p).read_bytes()
 return json.loads(gzip.decompress(b) if str(p).endswith(".gz") else b)
m=read(E/"manifest.json");a=read(E/"acceptance.json")
changed=git("diff","--name-only",BASE,COMMIT).decode().splitlines()
prefix="crates/cgx2-syntax/ordinary-parity-repair-evidence/"
bad=[p for p in changed if not (p=="crates/cgx2-syntax/S2B-ORDINARY-HARNESS-FINALIZATION.md" or p.startswith(prefix+"finalization-evidence/") or (p.startswith(prefix) and "/" not in p[len(prefix):] and p.endswith(".py")))]
check("exclusive_ownership",len(changed)==2085 and not bad,{"changed":len(changed),"unowned":bad})
check("clean_checkout",not git("status","--porcelain").strip(),git("status","--porcelain").decode())
actual={str(p.relative_to(E)) for p in E.rglob("*") if p.is_file()}
check("root_manifest_membership",actual==set(m["files"])|{"manifest.json"},{"actual":len(actual),"listed":len(m["files"])})
bad=[];gz=0
for p,v in m["files"].items():
 b=(E/p).read_bytes()
 if len(b)!=v["bytes"] or sha(b)!=v["sha256"]:bad.append(p+":compressed")
 if p.endswith(".gz"):
  gz+=1;r=gzip.decompress(b)
  if len(r)!=v["raw_bytes"] or sha(r)!=v["raw_sha256"]:bad.append(p+":raw")
check("archive_bytes_sha256",not bad,{"archives":gz,"metadata_including_root":len(actual)-gz,"bad":bad})
check("archive_counts",gz==2053 and len(actual)-gz==15 and len(actual)==2068)
inner=0;bad=[]
for p in E.glob("*/manifest.json"):
 for rel,v in read(p)["files"].items():
  b=(p.parent/rel).read_bytes();raw=gzip.decompress(b) if rel.endswith(".gz") else b
  if len(raw)!=v["bytes"] or sha(raw)!=v["sha256"]:bad.append(str(p)+":"+rel+":raw")
  if "gzip" in v and (len(b)!=v["gzip"]["bytes"] or sha(b)!=v["gzip"]["sha256"]):bad.append(str(p)+":"+rel+":gzip")
  inner+=1
check("inner_manifest_verification",not bad and inner==1848,{"entries":inner,"bad":bad})
old=[p for dirname in ["evidence","hardening-evidence"] for p in (HERE/dirname).rglob("*") if p.is_file()]
queries=[BASE+":"+str(p.relative_to(ROOT)) for p in old]
def blob_hashes(queries):
 data=git("cat-file","--batch") if False else subprocess.check_output(["git","cat-file","--batch"],input=("\n".join(queries)+"\n").encode(),cwd=ROOT)
 pos=0;out=[]
 for q in queries:
  end=data.index(b"\n",pos);head=data[pos:end].split();size=int(head[-1]);start=end+1;out.append(sha(data[start:start+size]));pos=start+size+1
 return out
old_hashes=blob_hashes(queries);bad=[str(p.relative_to(ROOT)) for p,h in zip(old,old_hashes) if file_sha(p)!=h]
check("prior_evidence_immutable",len(old)==766 and not bad,{"files":len(old),"bad":bad})
c=read(E/"run-3/attempts/freeze/candidate.json.gz");inputs=read(E/"run-3/attempts/freeze/inputs.json.gz")
build=c["build"];obs=c["observing_harness"]
for key,files,expected in [("compiler",build["compiler"],a["compiler_snapshot_sha256"]),("harness",obs["harness"],a["observing_harness_snapshot_sha256"])]:
 currentroot=ROOT if key=="compiler" else HERE
 bad=[p for p,h in files.items() if file_sha(currentroot/p)!=h]
 computed=sha(json.dumps(files,sort_keys=True,separators=(",",":")).encode())
 check(key+"_snapshot",computed==expected and not bad,{"count":len(files),"snapshot":computed,"bad":bad})
compiler=build["compiler"];gh=blob_hashes([build["source_commit"]+":"+p for p in compiler]);bad=[p for (p,h),g in zip(compiler.items(),gh) if h!=g]
check("compiler_matches_build_git_objects",not bad and len(compiler)==214,{"source_commit":build["source_commit"],"bad":bad})
check("build_harness_separate_identity",build["source_commit"]==a["compiler_build_commit"]=="ded3768480c745ce544d33c56aea44d4fc0bfa5a" and obs["head"]==BASE and build["compiler"]==obs["compiler"])
check("candidate_hash",file_sha(E/"run-3/attempts/freeze/candidate.json.gz")!=a["candidate_json_sha256"] and sha(gzip.decompress((E/"run-3/attempts/freeze/candidate.json.gz").read_bytes()))==a["candidate_json_sha256"])
bad=[p for p,h in build["original_references"].items() if file_sha(p)!=h]
check("original_build_references",not bad,{"count":len(build["original_references"]),"bad":bad})
for name in ["compiler","harness","toolchain","helpers"]:
 bad=[p for p,v in inputs[name].items() if file_sha(p)!=v["sha256"] or pathlib.Path(p).stat().st_size!=v["bytes"]]
 check("frozen_"+name+"_inputs",not bad,{"count":len(inputs[name]),"bad":bad})
# Locate frozen artifact tree through final audit report's saved command arguments.
freeze=read(E/"run-3/attempts/freeze/report.json.gz")
driver=read(E/"run-3/attempts/driver/report.json.gz")
report["freeze_identity"]= {k:len(v) for k,v in inputs.items()}
report["driver_commands"]=[{"name":r["name"],"argv":r.get("argv"),"cwd":r.get("cwd")} for r in driver["commands"]]
# Verify raw completed observations; intentional repro subdirectories are not production reports.
counts={};stream_count=0;stream_bad=[]
for name in ["audit","freeze","matrix","auto","package","review","historical","quality","driver"]:
 d=read(E/f"run-3/attempts/{name}/report.json.gz")
 cs=d["checks"];passed=sum(x["passed"] is True for x in cs);failed=len(cs)-passed
 counts[name]={"passed":passed,"failed":failed,"complete":d["complete"],"commands":len(d["commands"]),"failures":[x["name"] for x in cs if not x["passed"]],"coverage_errors":d.get("coverage_errors"),"exceptions":d["exceptions"]}
 check(name+"_actual_counts",passed==d["passed"]==a["fresh_results"][name]["passed"] and failed==d["failed"]==a["fresh_results"][name]["failed"] and d["complete"] and not d["exceptions"] and not d.get("coverage_errors"))
 for row in d["commands"]:
  for stream in ["stdout","stderr"]:
   if all(k in row for k in [stream,stream+"_bytes",stream+"_sha256"]):
    b=row[stream].encode();stream_count+=1
    if len(b)!=row[stream+"_bytes"] or sha(b)!=row[stream+"_sha256"]:stream_bad.append(name+":"+row["name"]+":"+stream)
   else:stream_bad.append(name+":"+row["name"]+":"+stream+":missing")
check("final_command_stream_bytes_sha256",not stream_bad,{"streams":stream_count,"bad":stream_bad})
report["counts"]=counts
# Inventory and actual selftest counts, without running tests.
q=read(E/"run-3/attempts/quality/report.json.gz")
report["quality_commands"]=[{"name":r["name"],"exit":r.get("exit"),"reason":r.get("reason"),"test_counts":re.findall(r"Ran (\d+) tests?",r.get("stdout","")+r.get("stderr",""))} for r in q["commands"]]
for p in (E/"run-3/attempts/historical").rglob("*.json.gz"):
 try:d=read(p)
 except Exception:continue
 if d.get("passed") in [135,670,523]:
  report.setdefault("historical_raw",[]).append({"path":str(p.relative_to(E)),"passed":d["passed"],"failed":d["failed"],"failures":[x.get("name",x.get("label")) for x in d.get("checks",[]) if not x.get("passed",True)]})
report["passed"]=sum(r["passed"] for r in report["checks"]);report["failed"]=len(report["checks"])-report["passed"]
OUT.mkdir(parents=True,exist_ok=True);(OUT/"audit.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({"passed":report["passed"],"failed":report["failed"],"failures":[x for x in report["checks"] if not x["passed"]],"counts":counts,"quality":report["quality_commands"],"historical":report.get("historical_raw")}))